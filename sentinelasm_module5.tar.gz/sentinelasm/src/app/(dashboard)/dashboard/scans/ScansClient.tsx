"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ScanLine, Plus, RefreshCw, XCircle, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { cn, timeAgo } from "@/lib/utils";

interface ScanStats { running: number; queued: number; completed: number }
interface Domain    { id: string; domain: string }
interface ScansClientProps { stats: ScanStats; domains: Domain[]; orgId: string }

const STAGE_LABELS = [
  "Subdomain Discovery","Port Scan","Tech Fingerprint",
  "Cloud Enum","GitHub Scan","Leak Scanner","CVE Matching","Risk Scoring","Report Gen",
];

const STATUS_STYLES: Record<string, { icon: React.ElementType; label: string; color: string; bg: string }> = {
  RUNNING:   { icon: RefreshCw,    label: "Running",   color: "#3B82F6", bg: "rgba(59,130,246,0.1)" },
  QUEUED:    { icon: Clock,        label: "Queued",    color: "#9CA3AF", bg: "rgba(107,114,128,0.1)" },
  COMPLETED: { icon: CheckCircle2, label: "Completed", color: "#10B981", bg: "rgba(16,185,129,0.1)" },
  FAILED:    { icon: AlertCircle,  label: "Failed",    color: "#EF4444", bg: "rgba(239,68,68,0.1)" },
  CANCELLED: { icon: XCircle,      label: "Cancelled", color: "#6B7280", bg: "rgba(107,114,128,0.1)" },
};

const DEMO_RUNNING = [
  {
    id: "s1", domain: "acmecorp.com", status: "RUNNING",
    progress: 67, currentStage: 6,
    startedMinsAgo: 14, etaMins: 6,
    assetsFound: 243, totalAssets: 291,
  },
  {
    id: "s2", domain: "api.acmecorp.com", status: "RUNNING",
    progress: 31, currentStage: 1,
    startedMinsAgo: 4,  etaMins: 12,
    assetsFound: 14,  totalAssets: 47,
  },
  {
    id: "s3", domain: "staging.acmecorp.com", status: "QUEUED",
    progress: 0, currentStage: -1,
    startedMinsAgo: 0, etaMins: 0,
    assetsFound: 0, totalAssets: 0,
  },
];

const DEMO_HISTORY = [
  { id: "h1", domain: "acmecorp.com",         status: "RUNNING",   startedAt: new Date(Date.now()-14*60*1000), duration: null, triggeredBy: "Scheduled",    assets: 291, findings: 23 },
  { id: "h2", domain: "acmecorp.com",         status: "COMPLETED", startedAt: new Date(Date.now()-1*24*60*60*1000), duration: 287, triggeredBy: "Scheduled", assets: 287, findings: 21 },
  { id: "h3", domain: "acmecorp.com",         status: "COMPLETED", startedAt: new Date(Date.now()-2*24*60*60*1000), duration: 312, triggeredBy: "Scheduled", assets: 281, findings: 19 },
  { id: "h4", domain: "acmecorp.com",         status: "COMPLETED", startedAt: new Date(Date.now()-3*24*60*60*1000+15*3600*1000), duration: 238, triggeredBy: "Ali Raza", assets: 280, findings: 22 },
  { id: "h5", domain: "api.acmecorp.com",     status: "FAILED",    startedAt: new Date(Date.now()-3*24*60*60*1000+12*3600*1000), duration: 83,  triggeredBy: "API Key", assets: 47, findings: 8 },
  { id: "h6", domain: "staging.acmecorp.com", status: "COMPLETED", startedAt: new Date(Date.now()-5*24*60*60*1000), duration: 145, triggeredBy: "Scheduled", assets: 38, findings: 4 },
];

function ProgressBar({ progress, status }: { progress: number; status: string }) {
  const [displayed, setDisplayed] = useState(0);
  useEffect(() => {
    const t = setTimeout(() => setDisplayed(progress), 300);
    return () => clearTimeout(t);
  }, [progress]);

  return (
    <div className="h-1 overflow-hidden rounded-full bg-[#1C2333]">
      <div
        className={cn("h-full rounded-full transition-all duration-700 ease-out",
          status === "COMPLETED" ? "bg-[#10B981]" : "bg-[#3B82F6]"
        )}
        style={{ width: `${displayed}%` }}
      />
    </div>
  );
}

function NewScanModal({ domains, onClose }: { domains: Domain[]; onClose: () => void }) {
  const [domain,     setDomain]     = useState("");
  const [customDomain, setCustom]   = useState("");
  const [scanning,   setScanning]   = useState(false);
  const [opts, setOpts] = useState({ ports: true, cloud: true, github: true });
  const router = useRouter();

  const handleSubmit = async () => {
    const target = domain === "custom" ? customDomain : domain;
    if (!target) { toast.error("Enter a domain to scan"); return; }
    setScanning(true);
    try {
      const res = await fetch("/api/scans", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ domain: target, scanPorts: opts.ports, scanCloud: opts.cloud, scanGithub: opts.github }),
      });
      if (!res.ok) { const j = await res.json(); toast.error(j.error ?? "Failed to start scan"); return; }
      toast.success(`Scan started for ${target}`);
      router.refresh();
      onClose();
    } catch { toast.error("Network error"); } finally { setScanning(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-2xl border border-[#1F2937] bg-[#111827] p-6 shadow-xl">
        <h2 className="mb-5 text-base font-semibold text-[#F9FAFB]">Start New Scan</h2>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Target Domain</label>
            <select
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]"
            >
              <option value="">Select a monitored domain…</option>
              {domains.map(d => <option key={d.id} value={d.domain}>{d.domain}</option>)}
              <option value="custom">Enter custom domain…</option>
            </select>
            {domain === "custom" && (
              <input
                type="text"
                value={customDomain}
                onChange={(e) => setCustom(e.target.value)}
                placeholder="example.com"
                className="mt-2 w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]"
              />
            )}
          </div>
          <div>
            <p className="mb-2 text-xs font-medium text-[#9CA3AF]">Scan Modules</p>
            {[["ports","Port Scanning"],["cloud","Cloud Enum"],["github","GitHub Scan"]].map(([k,l]) => (
              <label key={k} className="flex cursor-pointer items-center gap-2.5 py-1.5">
                <div
                  onClick={() => setOpts(o => ({ ...o, [k]: !o[k as keyof typeof o] }))}
                  className={cn("h-4 w-8 rounded-full border transition-colors",
                    opts[k as keyof typeof opts] ? "border-[#3B82F6] bg-[#3B82F6]" : "border-[#374151] bg-[#1C2333]"
                  )}
                >
                  <div className={cn("m-0.5 h-3 w-3 rounded-full bg-white transition-transform",
                    opts[k as keyof typeof opts] ? "translate-x-4" : "translate-x-0"
                  )} />
                </div>
                <span className="text-sm text-[#D1D5DB]">{l}</span>
              </label>
            ))}
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 rounded-lg border border-[#1F2937] py-2 text-sm font-medium text-[#9CA3AF] transition-colors hover:border-[#374151] hover:text-[#F9FAFB]">Cancel</button>
            <button
              onClick={handleSubmit}
              disabled={scanning}
              className="flex-1 rounded-lg bg-[#3B82F6] py-2 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
            >
              {scanning ? "Starting…" : "Start Scan"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function ScansClient({ stats, domains }: ScansClientProps) {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="animate-fade-in space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Scans</h1>
          <p className="mt-1 text-sm text-[#6B7280]">
            {stats.running} running · {stats.queued} queued · Next scheduled tonight at 03:00
          </p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
        >
          <Plus className="h-3.5 w-3.5" /> New Scan
        </button>
      </div>

      {/* Active scans */}
      <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
        <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
          <div>
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Active Scans</h2>
            <p className="text-xs text-[#6B7280]">{stats.running + stats.queued} active · Real-time progress</p>
          </div>
          <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(16,185,129,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#10B981]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#10B981] animate-pulse" />LIVE
          </span>
        </div>
        <div className="space-y-3 p-4">
          {DEMO_RUNNING.map((scan) => (
            <div key={scan.id} className="rounded-lg border border-[#1F2937] bg-[#0D1117] p-4">
              <div className="mb-3 flex items-start justify-between gap-4">
                <div>
                  <span className="font-mono text-sm font-semibold text-[#F9FAFB]">{scan.domain}</span>
                  <p className="mt-0.5 text-xs text-[#6B7280]">
                    {scan.status === "QUEUED"
                      ? "Waiting for available worker…"
                      : `${STAGE_LABELS[scan.currentStage]} — ${scan.progress}% complete`}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {scan.status === "RUNNING" && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(59,130,246,0.1)] px-2.5 py-1 text-[11px] font-semibold text-[#3B82F6]">
                      <RefreshCw className="h-3 w-3 animate-spin" /> Running
                    </span>
                  )}
                  {scan.status === "QUEUED" && (
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-[rgba(107,114,128,0.1)] px-2.5 py-1 text-[11px] font-semibold text-[#9CA3AF]">
                      <Clock className="h-3 w-3" /> Queued
                    </span>
                  )}
                  {scan.status === "RUNNING" && (
                    <button className="rounded px-2 py-1 text-[11px] font-medium text-[#EF4444] transition-colors hover:bg-[rgba(239,68,68,0.1)]">
                      ■ Cancel
                    </button>
                  )}
                </div>
              </div>

              <ProgressBar progress={scan.progress} status={scan.status} />

              <div className="mt-2 flex justify-between text-[11px] text-[#6B7280]">
                <span>
                  {scan.startedMinsAgo > 0
                    ? `Started ${scan.startedMinsAgo} min ago${scan.etaMins > 0 ? ` · ~${scan.etaMins} min remaining` : ""}`
                    : "Queued 2 min ago"}
                </span>
                {scan.totalAssets > 0 && (
                  <span className="font-tabular">{scan.assetsFound} / {scan.totalAssets} assets</span>
                )}
              </div>

              {scan.status === "RUNNING" && (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {STAGE_LABELS.map((stage, i) => (
                    <span
                      key={stage}
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-semibold",
                        i < scan.currentStage  ? "bg-[rgba(16,185,129,0.1)] text-[#10B981]" :
                        i === scan.currentStage ? "bg-[rgba(59,130,246,0.1)] text-[#3B82F6]" :
                                                  "border border-[#1F2937] bg-transparent text-[#6B7280]"
                      )}
                    >
                      {i < scan.currentStage ? "✓ " : i === scan.currentStage ? "⟳ " : ""}
                      {stage}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Scan history */}
      <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
        <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
          <h2 className="text-sm font-semibold text-[#F9FAFB]">Scan History</h2>
          <select className="h-7 rounded-lg border border-[#1F2937] bg-[#0D1117] px-2 text-xs text-[#9CA3AF] outline-none">
            <option>Last 30 days</option>
            <option>Last 90 days</option>
            <option>All time</option>
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1F2937]">
                {["Domain","Started","Duration","Triggered By","Assets","Findings","Status",""].map((h,i) => (
                  <th key={i} className="whitespace-nowrap px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {DEMO_HISTORY.map((scan) => {
                const s = STATUS_STYLES[scan.status] ?? STATUS_STYLES["QUEUED"]!;
                const Icon = s.icon;
                return (
                  <tr key={scan.id} className="border-b border-[#1F2937] transition-colors hover:bg-[#141E2E] last:border-0">
                    <td className="px-4 py-3"><span className="font-mono text-xs text-[#F9FAFB]">{scan.domain}</span></td>
                    <td className="px-4 py-3"><span className="text-xs text-[#6B7280]">{timeAgo(scan.startedAt)}</span></td>
                    <td className="px-4 py-3">
                      <span className="font-tabular text-xs text-[#9CA3AF]">
                        {scan.duration ? `${Math.floor(scan.duration/60)}m ${scan.duration%60}s` : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3"><span className="text-xs text-[#9CA3AF]">{scan.triggeredBy}</span></td>
                    <td className="px-4 py-3"><span className="font-tabular text-xs text-[#F9FAFB]">{scan.assets || "—"}</span></td>
                    <td className="px-4 py-3"><span className="font-tabular text-xs font-semibold text-[#F9FAFB]">{scan.findings || "—"}</span></td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-semibold"
                        style={{ background: s.bg, color: s.color }}>
                        <Icon className={cn("h-3 w-3", scan.status === "RUNNING" && "animate-spin")} />
                        {s.label}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {scan.status === "FAILED" ? (
                        <button className="text-xs font-medium text-[#3B82F6] hover:text-[#60A5FA]">Retry</button>
                      ) : scan.status === "COMPLETED" ? (
                        <button className="text-xs font-medium text-[#3B82F6] hover:text-[#60A5FA]">View Report</button>
                      ) : scan.status === "RUNNING" ? (
                        <button className="text-xs font-medium text-[#6B7280] hover:text-[#9CA3AF]">View Logs</button>
                      ) : null}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && <NewScanModal domains={domains} onClose={() => setShowModal(false)} />}
    </div>
  );
}
