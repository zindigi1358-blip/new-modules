"use client";

import { useState } from "react";
import { FileText, Download, Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn, formatDate, formatBytes } from "@/lib/utils";
import type { Report } from "@prisma/client";

interface ReportsClientProps {
  reports: Report[];
  domains: { id: string; domain: string }[];
}

const REPORT_TYPES = [
  { value: "FULL_PENTEST",     label: "Full Pentest Report",   desc: "All modules — executive + technical",  color: "#EF4444" },
  { value: "EXECUTIVE_SUMMARY",label: "Executive Summary",     desc: "Non-technical language",               color: "#3B82F6" },
  { value: "RISK_ONLY",        label: "Risk Report",           desc: "CVEs + risk scores only",              color: "#F59E0B" },
  { value: "COMPLIANCE",       label: "Compliance Report",     desc: "SOC2 / ISO 27001 aligned",             color: "#10B981" },
];

const DEMO_REPORTS = [
  { id:"r1", title:"acmecorp.com — Full Pentest Report", reportType:"FULL_PENTEST",      createdAt:new Date(Date.now()-2*60*60*1000), fileSizeBytes:249000, clientName:"Acme Corp" },
  { id:"r2", title:"acmecorp.com — Executive Summary",   reportType:"EXECUTIVE_SUMMARY", createdAt:new Date(Date.now()-1*24*3600*1000), fileSizeBytes:89000, clientName:"Acme Corp" },
  { id:"r3", title:"api.acmecorp.com — Risk Report",     reportType:"RISK_ONLY",         createdAt:new Date(Date.now()-2*24*3600*1000), fileSizeBytes:112000, clientName:"Acme Corp" },
  { id:"r4", title:"Monthly Digest — June 2026",         reportType:"EXECUTIVE_SUMMARY", createdAt:new Date(Date.now()-7*24*3600*1000), fileSizeBytes:195000, clientName:"Acme Corp" },
];

const TYPE_COLORS: Record<string, string> = {
  FULL_PENTEST:      "#EF4444",
  EXECUTIVE_SUMMARY: "#3B82F6",
  RISK_ONLY:         "#F59E0B",
  COMPLIANCE:        "#10B981",
};

export function ReportsClient({ domains }: ReportsClientProps) {
  const [selectedType, setSelectedType] = useState("FULL_PENTEST");
  const [clientName,   setClientName]   = useState("");
  const [assessor,     setAssessor]     = useState("");
  const [generating,   setGenerating]   = useState(false);

  const handleGenerate = async () => {
    if (!clientName.trim()) { toast.error("Enter a client name"); return; }
    setGenerating(true);
    await new Promise(r => setTimeout(r, 2500));
    toast.success("Report generated and ready to download");
    setGenerating(false);
  };

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Reports</h1>
          <p className="mt-1 text-sm text-[#6B7280]">Generate professional penetration testing reports</p>
        </div>
      </div>

      <div className="grid grid-cols-[1fr_320px] gap-5">
        {/* Generator */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="border-b border-[#1F2937] px-5 py-4">
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Generate New Report</h2>
            <p className="text-xs text-[#6B7280]">Consumes outputs from Modules 1, 2.5, and 3</p>
          </div>
          <div className="space-y-5 p-5">
            {/* Report type */}
            <div>
              <p className="mb-2.5 text-xs font-medium text-[#9CA3AF]">Report Type</p>
              <div className="grid grid-cols-2 gap-2.5">
                {REPORT_TYPES.map((t) => (
                  <label
                    key={t.value}
                    onClick={() => setSelectedType(t.value)}
                    className={cn(
                      "flex cursor-pointer items-center gap-3 rounded-lg border p-3 transition-all",
                      selectedType === t.value
                        ? "border-[rgba(59,130,246,0.4)] bg-[rgba(59,130,246,0.06)]"
                        : "border-[#1F2937] hover:border-[#374151]"
                    )}
                  >
                    <div className={cn(
                      "flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full border-2",
                      selectedType === t.value ? "border-[#3B82F6]" : "border-[#374151]"
                    )}>
                      {selectedType === t.value && <div className="h-2 w-2 rounded-full bg-[#3B82F6]" />}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-[#F9FAFB]">{t.label}</p>
                      <p className="text-[10px] text-[#6B7280]">{t.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Client name */}
            <div>
              <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Client Name *</label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Acme Corp"
                className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6]"
              />
            </div>

            {/* Assessor */}
            <div>
              <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Prepared By (Assessor)</label>
              <input
                type="text"
                value={assessor}
                onChange={(e) => setAssessor(e.target.value)}
                placeholder="Your Security Firm Name"
                className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6]"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={generating}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#3B82F6] py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
            >
              {generating ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Generating PDF…</>
              ) : (
                <><FileText className="h-4 w-4" /> Generate PDF Report</>
              )}
            </button>

            <p className="text-center text-[11px] text-[#6B7280]">
              Report includes executive summary, technical findings, remediation roadmap, and CVE appendix.
              Powered by Module 4.
            </p>
          </div>
        </div>

        {/* Recent reports */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="border-b border-[#1F2937] px-5 py-4">
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Recent Reports</h2>
          </div>
          <div className="divide-y divide-[#1F2937]">
            {DEMO_REPORTS.map((r) => (
              <div key={r.id} className="flex cursor-pointer items-center gap-3 px-4 py-3.5 transition-colors hover:bg-[#141E2E]">
                <div
                  className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg"
                  style={{ background: `${TYPE_COLORS[r.reportType]}18` }}
                >
                  <FileText className="h-4 w-4" style={{ color: TYPE_COLORS[r.reportType] }} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[13px] font-medium text-[#F9FAFB]">{r.title}</p>
                  <p className="text-[11px] text-[#6B7280]">
                    {formatDate(r.createdAt)} · {formatBytes(r.fileSizeBytes ?? 0)}
                  </p>
                </div>
                <button
                  className="flex-shrink-0 rounded-lg border border-[#1F2937] px-2.5 py-1.5 text-[11px] font-medium text-[#9CA3AF] transition-colors hover:border-[#374151] hover:text-[#F9FAFB]"
                  title="Download PDF"
                >
                  <Download className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
