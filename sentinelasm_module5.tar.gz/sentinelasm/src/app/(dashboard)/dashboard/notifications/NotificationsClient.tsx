"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Save, TestTube2, Bell, Mail, MessageSquare, Webhook, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { AlertConfig } from "@prisma/client";

interface NotificationsClientProps {
  configs: AlertConfig[];
}

function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      onClick={onToggle}
      className={cn(
        "relative h-5 w-9 rounded-full border transition-all",
        on ? "border-[#3B82F6] bg-[#3B82F6]" : "border-[#374151] bg-[#1C2333]"
      )}
    >
      <span className={cn(
        "absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-transform",
        on ? "left-[18px]" : "left-0.5"
      )} />
    </button>
  );
}

function SeverityToggle({ label, color, on, onToggle }: { label: string; color: string; on: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between py-3.5 border-b border-[#1F2937] last:border-0">
      <div className="flex items-center gap-3">
        <span className={cn(
          "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-bold",
        )} style={{ background: `${color}18`, color }}>
          {label}
        </span>
        <span className="text-sm text-[#9CA3AF]">
          {label === "CRITICAL" ? "Alert immediately via all channels" :
           label === "HIGH"     ? "Alert within 1 hour" :
           label === "MEDIUM"   ? "Include in daily digest" :
                                  "Weekly digest only"}
        </span>
      </div>
      <Toggle on={on} onToggle={onToggle} />
    </div>
  );
}

export function NotificationsClient({ configs }: NotificationsClientProps) {
  const [discord,    setDiscord]    = useState({ enabled: true,  url: "https://discord.com/api/webhooks/1234567890/xxxx_demo_token" });
  const [slack,      setSlack]      = useState({ enabled: true,  url: "https://hooks.slack.com/services/T00/B00/xxxx_demo" });
  const [email,      setEmail]      = useState({ enabled: true,  recipients: "ali.raza@acmecorp.com, soc@acmecorp.com" });
  const [customWh,   setCustomWh]   = useState({ enabled: false, url: "" });
  const [severities, setSeverities] = useState({ CRITICAL: true, HIGH: true, MEDIUM: true, LOW: false });
  const [schedule,   setSchedule]   = useState({ daily: true, weekly: true, scanDone: true, newAsset: true });
  const [testing,    setTesting]    = useState<string | null>(null);
  const [saving,     setSaving]     = useState(false);

  const handleTest = async (channel: string) => {
    setTesting(channel);
    await new Promise(r => setTimeout(r, 1400));
    toast.success(`Test alert sent to ${channel}`);
    setTesting(null);
  };

  const handleSave = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    toast.success("Notification preferences saved");
    setSaving(false);
  };

  return (
    <div className="animate-fade-in space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Notifications</h1>
          <p className="mt-1 text-sm text-[#6B7280]">Configure alerts across Discord, Slack, email, and custom webhooks</p>
        </div>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
        >
          {saving ? <><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />Saving…</> : <><Save className="h-3.5 w-3.5" />Save Preferences</>}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {/* Left col — channels */}
        <div className="space-y-4">
          {/* Discord */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[rgba(88,101,242,0.15)]">
                  <MessageSquare className="h-4 w-4 text-[#5865F2]" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#F9FAFB]">Discord</p>
                  <p className="text-xs text-[#6B7280]">Rich embeds with severity colors</p>
                </div>
              </div>
              <Toggle on={discord.enabled} onToggle={() => setDiscord(d => ({ ...d, enabled: !d.enabled }))} />
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Webhook URL</label>
                <input
                  type="url"
                  value={discord.url}
                  onChange={(e) => setDiscord(d => ({ ...d, url: e.target.value }))}
                  placeholder="https://discord.com/api/webhooks/…"
                  disabled={!discord.enabled}
                  className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6] disabled:opacity-40"
                />
              </div>
              <button
                onClick={() => handleTest("Discord")}
                disabled={!discord.enabled || testing === "Discord"}
                className="flex h-7 items-center gap-1.5 rounded-lg border border-[#1F2937] px-3 text-xs font-medium text-[#9CA3AF] transition-colors hover:border-[#374151] hover:text-[#F9FAFB] disabled:opacity-40"
              >
                {testing === "Discord" ? <span className="h-3 w-3 animate-spin rounded-full border border-[#9CA3AF] border-t-transparent" /> : <TestTube2 className="h-3 w-3" />}
                Send Test Alert
              </button>
            </div>
          </div>

          {/* Slack */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[rgba(74,21,75,0.2)]">
                  <MessageSquare className="h-4 w-4 text-[#E01E5A]" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#F9FAFB]">Slack</p>
                  <p className="text-xs text-[#6B7280]">Incoming webhook integration</p>
                </div>
              </div>
              <Toggle on={slack.enabled} onToggle={() => setSlack(s => ({ ...s, enabled: !s.enabled }))} />
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Webhook URL</label>
                <input
                  type="url"
                  value={slack.url}
                  onChange={(e) => setSlack(s => ({ ...s, url: e.target.value }))}
                  placeholder="https://hooks.slack.com/services/…"
                  disabled={!slack.enabled}
                  className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6] disabled:opacity-40"
                />
              </div>
              <button
                onClick={() => handleTest("Slack")}
                disabled={!slack.enabled || testing === "Slack"}
                className="flex h-7 items-center gap-1.5 rounded-lg border border-[#1F2937] px-3 text-xs font-medium text-[#9CA3AF] transition-colors hover:border-[#374151] hover:text-[#F9FAFB] disabled:opacity-40"
              >
                {testing === "Slack" ? <span className="h-3 w-3 animate-spin rounded-full border border-[#9CA3AF] border-t-transparent" /> : <TestTube2 className="h-3 w-3" />}
                Send Test Alert
              </button>
            </div>
          </div>

          {/* Email */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[rgba(59,130,246,0.1)]">
                  <Mail className="h-4 w-4 text-[#3B82F6]" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#F9FAFB]">Email</p>
                  <p className="text-xs text-[#6B7280]">Instant alerts + daily digest</p>
                </div>
              </div>
              <Toggle on={email.enabled} onToggle={() => setEmail(e => ({ ...e, enabled: !e.enabled }))} />
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Recipients (comma-separated)</label>
                <input
                  type="text"
                  value={email.recipients}
                  onChange={(e) => setEmail(em => ({ ...em, recipients: e.target.value }))}
                  placeholder="security@company.com, soc@company.com"
                  disabled={!email.enabled}
                  className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6] disabled:opacity-40"
                />
              </div>
              <button
                onClick={() => handleTest("Email")}
                disabled={!email.enabled || testing === "Email"}
                className="flex h-7 items-center gap-1.5 rounded-lg border border-[#1F2937] px-3 text-xs font-medium text-[#9CA3AF] transition-colors hover:border-[#374151] hover:text-[#F9FAFB] disabled:opacity-40"
              >
                {testing === "Email" ? <span className="h-3 w-3 animate-spin rounded-full border border-[#9CA3AF] border-t-transparent" /> : <TestTube2 className="h-3 w-3" />}
                Send Test Email
              </button>
            </div>
          </div>

          {/* Custom Webhook */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[rgba(107,114,128,0.1)]">
                  <Webhook className="h-4 w-4 text-[#9CA3AF]" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-[#F9FAFB]">Custom Webhook</p>
                  <p className="text-xs text-[#6B7280]">Generic JSON to any endpoint</p>
                </div>
              </div>
              <Toggle on={customWh.enabled} onToggle={() => setCustomWh(w => ({ ...w, enabled: !w.enabled }))} />
            </div>
            {customWh.enabled && (
              <div className="p-5">
                <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Endpoint URL</label>
                <input
                  type="url"
                  value={customWh.url}
                  onChange={(e) => setCustomWh(w => ({ ...w, url: e.target.value }))}
                  placeholder="https://your-server.com/webhook"
                  className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6]"
                />
              </div>
            )}
          </div>
        </div>

        {/* Right col — severity thresholds + schedule */}
        <div className="space-y-4">
          {/* Severity thresholds */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="border-b border-[#1F2937] px-5 py-4">
              <h2 className="text-sm font-semibold text-[#F9FAFB]">Alert Severity Thresholds</h2>
              <p className="text-xs text-[#6B7280]">Which findings trigger immediate alerts</p>
            </div>
            <div className="px-5">
              {(["CRITICAL","HIGH","MEDIUM","LOW"] as const).map((sev) => {
                const colors: Record<string, string> = {
                  CRITICAL: "#EF4444", HIGH: "#F59E0B", MEDIUM: "#60A5FA", LOW: "#10B981"
                };
                return (
                  <SeverityToggle
                    key={sev}
                    label={sev}
                    color={colors[sev]!}
                    on={severities[sev]}
                    onToggle={() => setSeverities(s => ({ ...s, [sev]: !s[sev] }))}
                  />
                );
              })}
            </div>
          </div>

          {/* Digest schedule */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="border-b border-[#1F2937] px-5 py-4">
              <h2 className="text-sm font-semibold text-[#F9FAFB]">Digest Schedule</h2>
              <p className="text-xs text-[#6B7280]">Scheduled summaries and event triggers</p>
            </div>
            <div className="px-5">
              {[
                { key: "daily",    label: "Daily Digest",         desc: "Every morning at 08:00" },
                { key: "weekly",   label: "Weekly Report",        desc: "Every Monday at 08:00" },
                { key: "scanDone", label: "Scan Completions",     desc: "When each scan finishes" },
                { key: "newAsset", label: "New Asset Discovered", desc: "Alert on new subdomains and IPs" },
              ].map(({ key, label, desc }) => (
                <div key={key} className="flex items-center justify-between border-b border-[#1F2937] py-3.5 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-[#F9FAFB]">{label}</p>
                    <p className="text-xs text-[#6B7280]">{desc}</p>
                  </div>
                  <Toggle
                    on={schedule[key as keyof typeof schedule]}
                    onToggle={() => setSchedule(s => ({ ...s, [key]: !s[key as keyof typeof schedule] }))}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* KEV instant alert callout */}
          <div className="rounded-xl border border-[rgba(239,68,68,0.3)] bg-[rgba(239,68,68,0.05)] p-4">
            <div className="flex items-start gap-3">
              <Bell className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#EF4444]" />
              <div>
                <p className="text-sm font-semibold text-[#F9FAFB]">KEV Instant Alerts — Always On</p>
                <p className="mt-1 text-xs leading-relaxed text-[#9CA3AF]">
                  Findings in the CISA Known Exploited Vulnerabilities catalog are always alerted
                  immediately regardless of severity threshold settings — these are under active attack
                  in the wild and require same-day response.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
