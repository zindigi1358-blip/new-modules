"use client";

import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { Globe, Download, Plus, Search, ChevronLeft, ChevronRight } from "lucide-react";
import { cn, timeAgo } from "@/lib/utils";
import { SeverityBadge } from "@/components/ui/Badge";
import type { FindingSeverity } from "@/types";

interface AssetStats {
  totalAssets: number; aliveAssets: number; cloudAssets: number;
  publicBuckets: number; riskyPorts: number; ipCount: number;
}

interface AssetsClientProps {
  stats: AssetStats;
  orgId: string;
}

const RISK_LEVELS: { label: string; value: FindingSeverity | ""; color: string }[] = [
  { label: "All", value: "", color: "" },
  { label: "Critical", value: "CRITICAL", color: "#EF4444" },
  { label: "High",     value: "HIGH",     color: "#F59E0B" },
  { label: "Medium",   value: "MEDIUM",   color: "#60A5FA" },
  { label: "Low",      value: "LOW",      color: "#10B981" },
];

// Demo assets — replaced with real API data when backend connected
const DEMO_ASSETS = [
  { id: "1", subdomain: "admin.acmecorp.com",   isAlive: true,  httpStatus: 200,  httpsStatus: 301, ipAddress: "104.21.44.12", openPorts: [80,443,3306], technologies: ["WordPress 5.8","PHP 7.4","jQuery 3.5"], riskLevel: "CRITICAL" as FindingSeverity, lastSeenAt: new Date(Date.now() - 2*60*1000) },
  { id: "2", subdomain: "api.acmecorp.com",     isAlive: true,  httpStatus: null, httpsStatus: 200, ipAddress: "104.21.44.18", openPorts: [443,6379,27017], technologies: ["Express 4.17","Nginx 1.18","Node.js 14"], riskLevel: "CRITICAL" as FindingSeverity, lastSeenAt: new Date(Date.now() - 14*60*1000) },
  { id: "3", subdomain: "staging.acmecorp.com", isAlive: true,  httpStatus: 200,  httpsStatus: 200, ipAddress: "104.21.44.23", openPorts: [443,9200], technologies: ["Django 3.1","Python 3.8","Nginx 1.14"], riskLevel: "HIGH" as FindingSeverity, lastSeenAt: new Date(Date.now() - 14*60*1000) },
  { id: "4", subdomain: "dev.acmecorp.com",     isAlive: true,  httpStatus: 200,  httpsStatus: 200, ipAddress: "104.21.44.31", openPorts: [22,80,27017], technologies: ["Apache 2.4","MongoDB"], riskLevel: "CRITICAL" as FindingSeverity, lastSeenAt: new Date(Date.now() - 38*60*1000) },
  { id: "5", subdomain: "old.acmecorp.com",     isAlive: true,  httpStatus: 200,  httpsStatus: 200, ipAddress: "104.21.44.44", openPorts: [80,443,21], technologies: ["PHP 5.6.40","Apache 2.2"], riskLevel: "CRITICAL" as FindingSeverity, lastSeenAt: new Date(Date.now() - 60*60*1000) },
  { id: "6", subdomain: "mail.acmecorp.com",    isAlive: true,  httpStatus: null, httpsStatus: 200, ipAddress: "104.21.44.52", openPorts: [25,443,587,993], technologies: ["Roundcube 1.4"], riskLevel: "MEDIUM" as FindingSeverity, lastSeenAt: new Date(Date.now() - 60*60*1000) },
  { id: "7", subdomain: "www.acmecorp.com",     isAlive: true,  httpStatus: 301,  httpsStatus: 200, ipAddress: "104.21.44.8",  openPorts: [80,443], technologies: ["React 17","Next.js 11","Nginx 1.20"], riskLevel: "LOW" as FindingSeverity, lastSeenAt: new Date(Date.now() - 2*60*60*1000) },
  { id: "8", subdomain: "vpn.acmecorp.com",     isAlive: true,  httpStatus: null, httpsStatus: 200, ipAddress: "104.21.44.61", openPorts: [443,1194], technologies: ["OpenVPN 2.4"], riskLevel: "MEDIUM" as FindingSeverity, lastSeenAt: new Date(Date.now() - 2*60*60*1000) },
  { id: "9", subdomain: "monitor.acmecorp.com", isAlive: true,  httpStatus: null, httpsStatus: 200, ipAddress: "104.21.44.71", openPorts: [443,3000], technologies: ["Grafana 7.3"], riskLevel: "HIGH" as FindingSeverity, lastSeenAt: new Date(Date.now() - 3*60*60*1000) },
  { id:"10", subdomain: "backup.acmecorp.com",  isAlive: true,  httpStatus: 200,  httpsStatus: 200, ipAddress: "104.21.44.82", openPorts: [21,22,80,5900], technologies: ["Apache 2.4.18"], riskLevel: "HIGH" as FindingSeverity, lastSeenAt: new Date(Date.now() - 3*60*60*1000) },
];

export function AssetsClient({ stats }: AssetsClientProps) {
  const [search,      setSearch]      = useState("");
  const [riskFilter,  setRiskFilter]  = useState<string>("");
  const [statusFilter,setStatusFilter]= useState<string>("all");
  const [page,        setPage]        = useState(1);
  const pageSize = 25;

  const filtered = DEMO_ASSETS.filter((a) => {
    if (search && !a.subdomain.toLowerCase().includes(search.toLowerCase()) &&
        !a.ipAddress?.toLowerCase().includes(search.toLowerCase()) &&
        !a.technologies.some(t => t.toLowerCase().includes(search.toLowerCase()))) return false;
    if (riskFilter && a.riskLevel !== riskFilter) return false;
    if (statusFilter === "alive" && !a.isAlive) return false;
    if (statusFilter === "dead"  &&  a.isAlive) return false;
    return true;
  });

  const statCards = [
    { label: "Subdomains",   value: stats.totalAssets,  color: "#3B82F6" },
    { label: "Alive",        value: stats.aliveAssets,  color: "#10B981" },
    { label: "IP Addresses", value: stats.ipCount,      color: "#9CA3AF" },
    { label: "Cloud Assets", value: stats.cloudAssets,  color: "#9CA3AF" },
    { label: "Public!",      value: stats.publicBuckets,color: "#EF4444" },
  ];

  return (
    <div className="animate-fade-in space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Assets</h1>
          <p className="mt-1 text-sm text-[#6B7280]">
            {stats.totalAssets.toLocaleString()} assets discovered across monitored domains
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex h-8 items-center gap-1.5 rounded-lg border border-[#1F2937] bg-[#111827] px-3 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151]">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
          <button className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]">
            <Plus className="h-3.5 w-3.5" /> Add Domain
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-5 gap-3">
        {statCards.map((s) => (
          <div key={s.label} className="relative overflow-hidden rounded-xl border border-[#1F2937] bg-[#111827] p-4">
            <div className="absolute inset-x-0 top-0 h-0.5" style={{ background: s.color }} />
            <p className="text-[11px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]">{s.label}</p>
            <p className="mt-1 font-tabular text-2xl font-bold" style={{ color: s.color }}>
              {s.value.toLocaleString()}
            </p>
          </div>
        ))}
      </div>

      {/* Table card */}
      <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[#1F2937] px-4 py-3">
          <div className="flex h-8 items-center gap-2 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 min-w-[220px] flex-1">
            <Search className="h-3.5 w-3.5 flex-shrink-0 text-[#6B7280]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Filter by subdomain, IP, technology…"
              className="flex-1 bg-transparent text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none"
            />
          </div>

          {["all","alive","at-risk","cloud"].map((f) => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              className={cn(
                "h-7 rounded-full border px-3 text-xs font-medium capitalize transition-colors",
                statusFilter === f
                  ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                  : "border-[#1F2937] text-[#6B7280] hover:border-[#374151] hover:text-[#9CA3AF]"
              )}
            >
              {f === "at-risk" ? "At Risk" : f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}

          <select
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            className="h-7 rounded-lg border border-[#1F2937] bg-[#0D1117] px-2 text-xs text-[#9CA3AF] outline-none"
          >
            <option value="">All Risk Levels</option>
            {RISK_LEVELS.filter(r => r.value).map(r => (
              <option key={r.value} value={r.value}>{r.label}</option>
            ))}
          </select>

          <select className="h-7 rounded-lg border border-[#1F2937] bg-[#0D1117] px-2 text-xs text-[#9CA3AF] outline-none">
            <option>All Technologies</option>
            <option>Nginx</option><option>Apache</option>
            <option>WordPress</option><option>Node.js</option>
          </select>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full" role="grid">
            <thead>
              <tr className="border-b border-[#1F2937]">
                {["Subdomain","Status","IP Address","Technologies","Open Ports","Risk","Last Seen"].map((h) => (
                  <th key={h} className="whitespace-nowrap px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-16 text-center">
                    <Globe className="mx-auto mb-3 h-10 w-10 text-[#374151]" />
                    <p className="text-sm font-medium text-[#6B7280]">No assets match your filters</p>
                  </td>
                </tr>
              ) : (
                filtered.map((asset) => (
                  <tr key={asset.id} className="group cursor-pointer border-b border-[#1F2937] transition-colors hover:bg-[#141E2E] last:border-0">
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs font-semibold text-[#F9FAFB] group-hover:text-[#3B82F6] transition-colors">
                        {asset.subdomain}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <span className={cn("h-1.5 w-1.5 rounded-full", asset.isAlive ? "bg-[#10B981]" : "bg-[#EF4444]")} />
                        <span className={cn("text-xs font-medium", asset.isAlive ? "text-[#10B981]" : "text-[#EF4444]")}>
                          {asset.isAlive ? "Alive" : "Dead"}
                        </span>
                        <span className="font-tabular text-xs text-[#6B7280]">
                          {asset.httpsStatus ?? asset.httpStatus ?? "—"}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-[#9CA3AF]">{asset.ipAddress}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-wrap gap-1">
                        {asset.technologies.slice(0, 3).map((t) => (
                          <span key={t} className={cn(
                            "rounded px-1.5 py-0.5 text-[10px] font-medium",
                            t.includes("5.6") || t.includes("2.2") || t.includes("2.4.18")
                              ? "bg-[rgba(239,68,68,0.1)] text-[#EF4444]"
                              : "bg-[#1C2333] text-[#9CA3AF]"
                          )}>
                            {t}
                          </span>
                        ))}
                        {asset.technologies.length > 3 && (
                          <span className="rounded px-1.5 py-0.5 text-[10px] text-[#6B7280]">
                            +{asset.technologies.length - 3}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-[#9CA3AF]">
                        {asset.openPorts.join(", ") || "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <SeverityBadge severity={asset.riskLevel} dot />
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs text-[#6B7280]">{timeAgo(asset.lastSeenAt)}</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#1F2937] px-4 py-3">
          <span className="text-xs text-[#6B7280]">
            Showing {Math.min(filtered.length, pageSize)} of {filtered.length} assets
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#1F2937] text-[#6B7280] transition-colors hover:border-[#374151] hover:text-[#F9FAFB] disabled:opacity-40"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            {[1, 2, 3].map(p => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={cn(
                  "flex h-7 w-7 items-center justify-center rounded border text-xs font-medium transition-colors",
                  page === p
                    ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                    : "border-[#1F2937] text-[#6B7280] hover:border-[#374151] hover:text-[#F9FAFB]"
                )}
              >
                {p}
              </button>
            ))}
            <button
              onClick={() => setPage(p => p + 1)}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#1F2937] text-[#6B7280] transition-colors hover:border-[#374151] hover:text-[#F9FAFB]"
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
