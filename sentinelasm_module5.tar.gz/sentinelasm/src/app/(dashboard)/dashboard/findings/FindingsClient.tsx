"use client";

import { useState } from "react";
import { Search, AlertTriangle, ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";
import { SeverityBadge, CvssPill } from "@/components/ui/Badge";
import type { FindingSeverity } from "@/types";

interface FindingsClientProps {
  totalFindings: number;
  bySeverity:    Record<string, number>;
  kevCount:      number;
}

const DEMO_FINDINGS = [
  { id:"f1", title:"AWS Access Key Exposed in GitHub", asset:"github.com/acmecorp/infra",  severity:"CRITICAL" as FindingSeverity, cvss:9.9, score:96, isKev:false, category:"Credentials", status:"OPEN",        assignee:null        },
  { id:"f2", title:"Exposed .git Directory — Full Source Reconstruction", asset:"dev.acmecorp.com/.git/config", severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:91, isKev:false, category:"Exposure", status:"OPEN",        assignee:null        },
  { id:"f3", title:"PHP 5.6.40 — Remote Code Execution (CVE-2019-11043)",asset:"old.acmecorp.com",   severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:88, isKev:true,  category:"CVE",         status:"OPEN",        assignee:"Ali Raza"  },
  { id:"f4", title:"MongoDB Port 27017 Exposed — No Authentication",     asset:"api.acmecorp.com",  severity:"CRITICAL" as FindingSeverity, cvss:9.1, score:88, isKev:false, category:"Exposure",    status:"OPEN",        assignee:null        },
  { id:"f5", title:"S3 Bucket Publicly Readable",                        asset:"acmecorp-backups.s3.amazonaws.com", severity:"CRITICAL" as FindingSeverity, cvss:8.6, score:85, isKev:false, category:"Cloud",  status:"OPEN",        assignee:null        },
  { id:"f6", title:"WordPress 5.8 — SQL Injection (CVE-2022-21661)",     asset:"admin.acmecorp.com", severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:91, isKev:false, category:"CVE",         status:"OPEN",        assignee:null        },
  { id:"f7", title:"Exposed .env File with DB Credentials",              asset:"staging.acmecorp.com/.env", severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:88, isKev:false, category:"Exposure",status:"OPEN",        assignee:null        },
  { id:"f8", title:"Express.js Open Redirect (CVE-2022-24999)",          asset:"api.acmecorp.com",  severity:"HIGH"     as FindingSeverity, cvss:7.5, score:73, isKev:false, category:"CVE",         status:"OPEN",        assignee:null        },
  { id:"f9", title:"Admin Panel Exposed to Public Internet",             asset:"admin.acmecorp.com", severity:"HIGH"    as FindingSeverity, cvss:7.2, score:68, isKev:false, category:"Config",       status:"IN_PROGRESS", assignee:"Ali Raza"  },
  { id:"fa", title:"Django 3.1.4 — SQL Injection (CVE-2022-28346)",      asset:"staging.acmecorp.com", severity:"HIGH" as FindingSeverity, cvss:9.8, score:70, isKev:false, category:"CVE",          status:"OPEN",        assignee:null        },
  { id:"fb", title:"Grafana 7.3.1 — Unauthenticated Snapshot API",      asset:"monitor.acmecorp.com", severity:"HIGH" as FindingSeverity, cvss:8.8, score:67, isKev:false, category:"CVE",           status:"OPEN",        assignee:null        },
  { id:"fc", title:"Backup SQL Dump Exposed",                            asset:"backup.acmecorp.com/backup.sql", severity:"HIGH" as FindingSeverity, cvss:8.6, score:64, isKev:false, category:"Exposure", status:"OPEN", assignee:null    },
  { id:"fd", title:"Next.js 11 — Open Redirect (CVE-2022-21721)",       asset:"www.acmecorp.com",   severity:"MEDIUM"   as FindingSeverity, cvss:7.2, score:48, isKev:false, category:"CVE",         status:"OPEN",        assignee:null        },
  { id:"fe", title:"Missing HSTS Header",                                asset:"admin.acmecorp.com", severity:"MEDIUM"  as FindingSeverity, cvss:5.4, score:32, isKev:false, category:"Config",       status:"OPEN",        assignee:null        },
  { id:"ff", title:"TLS Certificate Expiring in 12 Days",                asset:"mail.acmecorp.com",  severity:"MEDIUM"  as FindingSeverity, cvss:0,   score:28, isKev:false, category:"Config",       status:"OPEN",        assignee:null        },
  { id:"fg", title:"Roundcube XSS (CVE-2021-44025)",                    asset:"mail.acmecorp.com",  severity:"LOW"     as FindingSeverity, cvss:4.3, score:22, isKev:false, category:"CVE",         status:"OPEN",        assignee:null        },
];

const STATUS_BADGE: Record<string, { label: string; color: string; bg: string }> = {
  OPEN:          { label: "Open",         color: "#EF4444", bg: "rgba(239,68,68,0.1)"  },
  IN_PROGRESS:   { label: "In Progress",  color: "#3B82F6", bg: "rgba(59,130,246,0.1)" },
  RESOLVED:      { label: "Resolved",     color: "#10B981", bg: "rgba(16,185,129,0.1)" },
  ACCEPTED_RISK: { label: "Accepted",     color: "#9CA3AF", bg: "rgba(107,114,128,0.1)"},
  FALSE_POSITIVE:{ label: "False +",      color: "#6B7280", bg: "rgba(107,114,128,0.1)"},
};

export function FindingsClient({ totalFindings, bySeverity, kevCount }: FindingsClientProps) {
  const [search,    setSearch]    = useState("");
  const [sevFilter, setSevFilter] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [kevOnly,   setKevOnly]   = useState(false);
  const [page,      setPage]      = useState(1);
  const [selected,  setSelected]  = useState<string[]>([]);
  const pageSize = 25;

  const filtered = DEMO_FINDINGS.filter((f) => {
    if (kevOnly && !f.isKev) return false;
    if (sevFilter && f.severity !== sevFilter) return false;
    if (catFilter && f.category !== catFilter) return false;
    if (search && !f.title.toLowerCase().includes(search.toLowerCase()) &&
        !f.asset.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const severityTabs = [
    { label: "All",      value: "",         count: totalFindings },
    { label: "Critical", value: "CRITICAL",  count: bySeverity["CRITICAL"] ?? 0 },
    { label: "High",     value: "HIGH",      count: bySeverity["HIGH"]     ?? 0 },
    { label: "Medium",   value: "MEDIUM",    count: bySeverity["MEDIUM"]   ?? 0 },
    { label: "Low",      value: "LOW",       count: bySeverity["LOW"]      ?? 0 },
  ];

  const allChecked = filtered.length > 0 && selected.length === filtered.length;
  const toggleAll = () => setSelected(allChecked ? [] : filtered.map(f => f.id));
  const toggleOne = (id: string) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);

  return (
    <div className="animate-fade-in space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Findings</h1>
          <p className="mt-1 text-sm text-[#6B7280]">
            {totalFindings} total · {bySeverity["CRITICAL"] ?? 0} critical · {bySeverity["HIGH"] ?? 0} high
            {kevCount > 0 && <> · <span className="text-[#EF4444] font-medium">{kevCount} actively exploited (KEV)</span></>}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selected.length > 0 && (
            <button className="h-8 rounded-lg border border-[#1F2937] bg-[#111827] px-3 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151]">
              Bulk Actions ({selected.length})
            </button>
          )}
          <button className="h-8 rounded-lg border border-[#1F2937] bg-[#111827] px-3 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151]">
            Export
          </button>
        </div>
      </div>

      {/* Severity tabs */}
      <div className="flex items-center gap-1 border-b border-[#1F2937] pb-0">
        {severityTabs.map((tab) => (
          <button
            key={tab.value}
            onClick={() => { setSevFilter(tab.value); setPage(1); }}
            className={cn(
              "flex items-center gap-1.5 border-b-2 px-3 pb-3 text-sm font-medium transition-colors",
              sevFilter === tab.value
                ? "border-[#3B82F6] text-[#3B82F6]"
                : "border-transparent text-[#6B7280] hover:text-[#9CA3AF]"
            )}
          >
            {tab.label}
            {tab.count > 0 && (
              <span className={cn("rounded-full px-1.5 py-0.5 text-[10px] font-bold",
                sevFilter === tab.value
                  ? "bg-[rgba(59,130,246,0.2)] text-[#3B82F6]"
                  : "bg-[#1C2333] text-[#6B7280]"
              )}>
                {tab.count}
              </span>
            )}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2 pb-3">
          <button
            onClick={() => setKevOnly(!kevOnly)}
            className={cn("h-7 rounded-full border px-3 text-xs font-medium transition-colors",
              kevOnly ? "border-[rgba(239,68,68,0.3)] bg-[rgba(239,68,68,0.1)] text-[#EF4444]"
                      : "border-[#1F2937] text-[#6B7280] hover:border-[#374151]"
            )}
          >
            ☠ KEV Only
          </button>
        </div>
      </div>

      {/* Table card */}
      <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-[#1F2937] px-4 py-3">
          <div className="flex h-8 min-w-[240px] flex-1 items-center gap-2 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3">
            <Search className="h-3.5 w-3.5 flex-shrink-0 text-[#6B7280]" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search findings, CVEs, assets…"
              className="flex-1 bg-transparent text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none"
            />
          </div>
          <select
            value={catFilter}
            onChange={(e) => setCatFilter(e.target.value)}
            className="h-8 rounded-lg border border-[#1F2937] bg-[#0D1117] px-2 text-xs text-[#9CA3AF] outline-none"
          >
            <option value="">All Categories</option>
            {["Exposure","CVE","Config","Credentials","Cloud"].map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <select className="h-8 rounded-lg border border-[#1F2937] bg-[#0D1117] px-2 text-xs text-[#9CA3AF] outline-none">
            <option>Sort: Risk Score ↓</option>
            <option>Sort: CVSS ↓</option>
            <option>Sort: Newest</option>
            <option>Sort: Oldest</option>
          </select>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full" role="grid">
            <thead>
              <tr className="border-b border-[#1F2937]">
                <th className="w-10 px-4 py-2.5">
                  <input type="checkbox" checked={allChecked} onChange={toggleAll}
                    className="h-3.5 w-3.5 rounded border-[#374151] bg-[#0D1117] accent-[#3B82F6]" />
                </th>
                {["Finding","Severity","CVSS","Risk Score","Asset","Category","Status","Assigned"].map(h => (
                  <th key={h} className="whitespace-nowrap px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-16 text-center">
                    <AlertTriangle className="mx-auto mb-3 h-10 w-10 text-[#374151]" />
                    <p className="text-sm text-[#6B7280]">No findings match your filters</p>
                  </td>
                </tr>
              ) : (
                filtered.slice((page-1)*pageSize, page*pageSize).map((f) => {
                  const st = STATUS_BADGE[f.status] ?? STATUS_BADGE["OPEN"]!;
                  return (
                    <tr key={f.id}
                      className="group cursor-pointer border-b border-[#1F2937] transition-colors hover:bg-[#141E2E] last:border-0">
                      <td className="px-4 py-3">
                        <input type="checkbox"
                          checked={selected.includes(f.id)}
                          onChange={() => toggleOne(f.id)}
                          className="h-3.5 w-3.5 rounded border-[#374151] bg-[#0D1117] accent-[#3B82F6]"
                          onClick={(e) => e.stopPropagation()}
                        />
                      </td>
                      <td className="max-w-[280px] px-3 py-3">
                        <div className="flex items-start gap-2">
                          <div>
                            <p className="text-[13px] font-medium leading-snug text-[#F9FAFB] transition-colors group-hover:text-[#3B82F6]">
                              {f.title}
                              {f.isKev && <span className="ml-1.5 text-[#EF4444]" title="CISA Known Exploited Vulnerability">☠</span>}
                            </p>
                            <p className="mt-0.5 font-mono text-[11px] text-[#6B7280]">{f.asset}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3"><SeverityBadge severity={f.severity} dot /></td>
                      <td className="px-3 py-3"><CvssPill score={f.cvss} /></td>
                      <td className="px-3 py-3">
                        <div className="flex items-center gap-2">
                          <span className="font-tabular text-sm font-bold" style={{ color: f.score >= 85 ? "#EF4444" : f.score >= 65 ? "#F59E0B" : "#10B981" }}>
                            {f.score}
                          </span>
                          <div className="h-1 w-14 overflow-hidden rounded-full bg-[#1C2333]">
                            <div className="h-full rounded-full" style={{
                              width: `${f.score}%`,
                              background: f.score >= 85 ? "#EF4444" : f.score >= 65 ? "#F59E0B" : "#10B981",
                              opacity: 0.7,
                            }} />
                          </div>
                        </div>
                      </td>
                      <td className="max-w-[160px] px-3 py-3">
                        <span className="block truncate font-mono text-[11px] text-[#9CA3AF]">{f.asset.split("/")[0]}</span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="rounded bg-[#1C2333] px-1.5 py-0.5 text-[11px] text-[#9CA3AF]">{f.category}</span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold"
                          style={{ background: st.bg, color: st.color }}>
                          <span className="h-1.5 w-1.5 rounded-full bg-current" />
                          {st.label}
                        </span>
                      </td>
                      <td className="px-3 py-3">
                        <span className="text-xs text-[#6B7280]">{f.assignee ?? "—"}</span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#1F2937] px-4 py-3">
          <span className="text-xs text-[#6B7280]">
            Showing {Math.min(filtered.length, pageSize)} of {filtered.length} findings
          </span>
          <div className="flex items-center gap-1">
            <button onClick={() => setPage(p => Math.max(1,p-1))} disabled={page===1}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#1F2937] text-[#6B7280] disabled:opacity-40 hover:border-[#374151] hover:text-[#F9FAFB]">
              <ChevronLeft className="h-3.5 w-3.5" />
            </button>
            {Array.from({ length: Math.min(3, Math.ceil(filtered.length/pageSize)) }, (_,i) => i+1).map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={cn("flex h-7 w-7 items-center justify-center rounded border text-xs font-medium transition-colors",
                  page===p ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                           : "border-[#1F2937] text-[#6B7280] hover:border-[#374151] hover:text-[#F9FAFB]"
                )}>
                {p}
              </button>
            ))}
            <button onClick={() => setPage(p => p+1)}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#1F2937] text-[#6B7280] hover:border-[#374151] hover:text-[#F9FAFB]">
              <ChevronRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
