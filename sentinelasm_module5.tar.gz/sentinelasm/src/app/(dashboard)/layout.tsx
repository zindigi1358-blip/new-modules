import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { Sidebar } from "@/components/layout/Sidebar";
import { Topbar } from "@/components/layout/Topbar";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Auth guard — redirect unauthenticated users to login
  const session = await getSession();
  if (!session) redirect("/login");

  // Fetch unread notification count for topbar badge
  const unreadCount = await db.notification.count({
    where: {
      organizationId: session.orgId,
      isRead:         false,
    },
  });

  return (
    <div className="flex h-screen overflow-hidden bg-[#080B12]">
      {/* Sidebar */}
      <Sidebar
        session={session}
        orgName={session.orgName}
        orgPlan="Professional"
      />

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Topbar
          orgName={session.orgName}
          unreadCount={unreadCount}
        />

        {/* Page content */}
        <main
          id="main-content"
          className="flex-1 overflow-y-auto bg-[#080B12]"
          tabIndex={-1}
        >
          <div className="mx-auto max-w-[1400px] p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
