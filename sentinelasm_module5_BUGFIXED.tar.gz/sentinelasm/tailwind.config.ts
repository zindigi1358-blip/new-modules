import type { Config } from "tailwindcss";

const config: Config = {
  darkMode:  ["class"],
  content:   ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        /* ── Brand ─────────────────────────────── */
        accent:   { DEFAULT: "#3B82F6", dim: "#1D4ED8", muted: "rgba(59,130,246,0.1)" },
        /* ── Severity ──────────────────────────── */
        critical: { DEFAULT: "#EF4444", muted: "rgba(239,68,68,0.1)"   },
        high:     { DEFAULT: "#F59E0B", muted: "rgba(245,158,11,0.1)"  },
        medium:   { DEFAULT: "#60A5FA", muted: "rgba(96,165,250,0.1)"  },
        low:      { DEFAULT: "#10B981", muted: "rgba(16,185,129,0.1)"  },
        /* ── Semantic ──────────────────────────── */
        success:  "#10B981",
        warning:  "#F59E0B",
        error:    "#EF4444",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "-apple-system", "sans-serif"],
        mono: ["JetBrains Mono", "Fira Code", "Menlo", "monospace"],
      },
      fontSize: {
        "2xs": ["0.625rem", { lineHeight: "0.875rem" }],
      },
      borderRadius: {
        DEFAULT: "0.5rem",
        sm:      "0.375rem",
        md:      "0.5rem",
        lg:      "0.75rem",
        xl:      "1rem",
        "2xl":   "1.25rem",
      },
      boxShadow: {
        card:    "0 1px 3px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.3)",
        modal:   "0 20px 60px rgba(0,0,0,0.6)",
        glow:    "0 0 40px rgba(59,130,246,0.25)",
        "glow-red": "0 0 30px rgba(239,68,68,0.2)",
      },
      keyframes: {
        "fade-in": {
          from: { opacity: "0", transform: "translateY(4px)" },
          to:   { opacity: "1", transform: "translateY(0)"   },
        },
        "slide-in-right": {
          from: { transform: "translateX(100%)" },
          to:   { transform: "translateX(0)"    },
        },
        "pulse-dot": {
          "0%, 100%": { opacity: "1"   },
          "50%":      { opacity: "0.4" },
        },
        shimmer: {
          "0%":   { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0"  },
        },
      },
      animation: {
        "fade-in":        "fade-in 0.2s ease-out",
        "slide-in-right": "slide-in-right 0.22s ease-out",
        "pulse-dot":      "pulse-dot 1.5s ease-in-out infinite",
        shimmer:          "shimmer 2s linear infinite",
      },
      backgroundImage: {
        shimmer: "linear-gradient(90deg, transparent, rgba(255,255,255,0.04), transparent)",
        "grid-dark": "radial-gradient(circle at 1px 1px, #3B82F6 1px, transparent 0)",
      },
    },
  },
  plugins: [],
};

export default config;
