import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createToken, setSessionCookie } from "@/lib/auth";
import {
  ok, badRequest, unauthorized, handleRouteError, checkRateLimit, tooManyRequests,
} from "@/lib/api";

const loginSchema = z.object({
  email:    z.string().email(),
  password: z.string().min(1),
});

export async function POST(req: NextRequest) {
  try {
    // Rate limit: 20 attempts per hour per IP
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const { allowed } = checkRateLimit(`auth:login:${ip}`, 20, 3600);
    if (!allowed) return tooManyRequests(3600);

    const body = await req.json();
    const { email, password } = loginSchema.parse(body);

    // Find user
    const user = await db.user.findUnique({
      where: { email: email.toLowerCase() },
      include: {
        memberships: {
          include: { organization: true },
          take:    1,
          orderBy: { joinedAt: "asc" },
        },
      },
    });

    // Constant-time comparison prevents timing attacks
    const dummyHash = "$2b$12$dummy.hash.for.timing.protection.purposes.only";
    const hash = user?.passwordHash ?? dummyHash;
    const valid = await bcrypt.compare(password, hash);

    if (!user || !valid) {
      return unauthorized("Invalid email or password");
    }

    const membership = user.memberships[0];
    if (!membership) {
      return unauthorized("No organization found for this account");
    }

    // Create session record
    const session = await db.session.create({
      data: {
        userId:    user.id,
        token:     crypto.randomUUID(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        ipAddress: ip,
        userAgent: req.headers.get("user-agent") ?? null,
      },
    });

    // Update last login
    await db.user.update({
      where: { id: user.id },
      data:  { lastLoginAt: new Date() },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        organizationId: membership.organizationId,
        userId:         user.id,
        action:         "LOGIN",
        ipAddress:      ip,
        userAgent:      req.headers.get("user-agent") ?? null,
      },
    });

    // Create JWT
    const token = await createToken({
      userId:    user.id,
      email:     user.email,
      name:      user.name,
      orgId:     membership.organizationId,
      orgSlug:   membership.organization.slug,
      orgName:   membership.organization.name,
      role:      membership.role,
      sessionId: session.id,
    });

    await setSessionCookie(token);

    return ok({ redirectTo: "/dashboard" });
  } catch (err) {
    return handleRouteError(err);
  }
}
