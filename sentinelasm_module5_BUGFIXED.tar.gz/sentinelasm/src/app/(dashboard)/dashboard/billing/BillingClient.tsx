"use client";

import { useState } from "react";
import { toast } from "sonner";
import { CreditCard, Check, Zap, Building2, Users, Download } from "lucide-react";
import { cn, formatDate } from "@/lib/utils";
import type { PlanTier } from "@/types";
import { PLAN_PRICES } from "@/types";

interface BillingClientProps {
  plan:            PlanTier;
  planExpiresAt:   Date | null;
  hasSubscription: boolean;
  limits: { maxAssets: number; maxScansMonth: number; maxMembers: number };
  usage:  { assets: number; scans: number; members: number };
}

const PLANS = [
  {
    tier:       "STARTER" as PlanTier,
    name:       "Starter",
    price:      99,
    icon:       Zap,
    iconColor:  "#9CA3AF",
    features:   ["500 assets","50 scans/month","5 team seats","API access","Email alerts"],
    missing:    ["Cloud enum","GitHub scan","PDF reports","SSO / SAML"],
  },
  {
    tier:       "PROFESSIONAL" as PlanTier,
    name:       "Professional",
    price:      199,
    icon:       CreditCard,
    iconColor:  "#3B82F6",
    features:   ["5,000 assets","500 scans/month","25 team seats","API access","All alert channels","Cloud enum","GitHub scan","PDF reports","Audit logs"],
    missing:    ["White-label PDF","SSO / SAML","SLA guarantee"],
    popular:    true,
  },
  {
    tier:       "BUSINESS" as PlanTier,
    name:       "Business",
    price:      499,
    icon:       Building2,
    iconColor:  "#8B5CF6",
    features:   ["Unlimited assets","Unlimited scans","100 team seats","Everything in Professional","White-label PDF","SSO / SAML","Priority support"],
    missing:    ["Dedicated infra","SLA guarantee"],
  },
  {
    tier:       "ENTERPRISE" as PlanTier,
    name:       "Enterprise",
    price:      0,
    icon:       Users,
    iconColor:  "#10B981",
    features:   ["Everything in Business","Dedicated infrastructure","Custom SLA","SCIM/OIDC","Custom contract","Onboarding engineer"],
    missing:    [],
    custom:     true,
  },
];

const DEMO_INVOICES = [
  { id:"inv1", date: new Date(Date.now()-0*30*86400*1000),  amount: 19900, plan:"Professional", status:"paid" },
  { id:"inv2", date: new Date(Date.now()-1*30*86400*1000),  amount: 19900, plan:"Professional", status:"paid" },
  { id:"inv3", date: new Date(Date.now()-2*30*86400*1000),  amount: 19900, plan:"Professional", status:"paid" },
  { id:"inv4", date: new Date(Date.now()-3*30*86400*1000),  amount:  9900, plan:"Starter",      status:"paid" },
];

function UsageBar({ used, max, label, color = "#3B82F6" }: { used: number; max: number; label: string; color?: string }) {
  const pct = max === 0 ? 0 : Math.min(100, (used / max) * 100);
  const warn = pct > 80;
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs">
        <span className="text-[var(--text-faint)]">{label}</span>
        <span className="font-tabular font-semibold text-[var(--text-primary)]">
          {used.toLocaleString()} / {max === 999999 || max === 9999 ? "∞" : max.toLocaleString()}
        </span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-[var(--bg-elevated)]">
        <div className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, background: warn ? "#F59E0B" : color }} />
      </div>
    </div>
  );
}

export function BillingClient({ plan, planExpiresAt, limits, usage }: BillingClientProps) {
  const [loading, setLoading] = useState<string | null>(null);

  const handleUpgrade = async (tier: PlanTier) => {
    if (tier === plan) return;
    setLoading(tier);
    try {
      const res = await fetch("/api/billing/checkout", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ plan: tier }),
      });
      const j = await res.json();
      if (!res.ok) { toast.error(j.error ?? "Failed to start checkout"); return; }
      if (j.data?.url) window.location.href = j.data.url;
    } catch { toast.error("Network error"); }
    finally { setLoading(null); }
  };

  const handleContactSales = () => {
    window.location.href = "mailto:sales@sentinelasm.io?subject=Enterprise%20Inquiry";
  };

  return (
    <div className="animate-fade-in space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">Billing</h1>
        <p className="mt-1 text-sm text-[var(--text-faint)]">Manage your subscription, usage, and invoices</p>
      </div>

      {/* Current plan + usage */}
      <div className="grid grid-cols-2 gap-5">
        <div className={cn(
          "rounded-xl border p-5",
          plan === "PROFESSIONAL" ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.05)]" : "border-[var(--border)] bg-[var(--bg-card)]"
        )}>
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[var(--text-faint)]">Current Plan</p>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-lg font-bold text-[var(--text-primary)]">
                  {plan.charAt(0) + plan.slice(1).toLowerCase()}
                </span>
                <span className="rounded-full bg-[rgba(59,130,246,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#3B82F6]">
                  Active
                </span>
              </div>
            </div>
            <div className="text-right">
              <p className="font-tabular text-2xl font-bold text-[var(--text-primary)]">
                ${PLAN_PRICES[plan]}<span className="text-sm font-normal text-[var(--text-faint)]">/mo</span>
              </p>
              {planExpiresAt && (
                <p className="text-xs text-[var(--text-faint)]">Renews {formatDate(planExpiresAt)}</p>
              )}
            </div>
          </div>
          <div className="space-y-3">
            <UsageBar used={usage.assets}  max={limits.maxAssets}     label="Assets"          color="#3B82F6" />
            <UsageBar used={usage.scans}   max={limits.maxScansMonth} label="Scans this month" color="#10B981" />
            <UsageBar used={usage.members} max={limits.maxMembers}    label="Team seats"       color="#8B5CF6" />
          </div>
        </div>

        {/* Invoice history */}
        <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
          <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-4">
            <h2 className="text-sm font-semibold text-[var(--text-primary)]">Invoice History</h2>
          </div>
          <div className="divide-y divide-[var(--border)]">
            {DEMO_INVOICES.map((inv) => (
              <div key={inv.id} className="flex items-center gap-3 px-5 py-3">
                <div className="flex-1">
                  <p className="text-sm font-medium text-[var(--text-primary)]">{formatDate(inv.date)}</p>
                  <p className="text-xs text-[var(--text-faint)]">{inv.plan} plan</p>
                </div>
                <p className="font-tabular text-sm font-semibold text-[var(--text-primary)]">
                  ${(inv.amount / 100).toFixed(2)}
                </p>
                <span className="rounded-full bg-[rgba(16,185,129,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#10B981]">
                  Paid
                </span>
                <button className="flex h-7 w-7 items-center justify-center rounded text-[var(--text-faint)] hover:text-[var(--text-primary)]">
                  <Download className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Plan comparison */}
      <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
        <div className="border-b border-[var(--border)] px-5 py-4">
          <h2 className="text-sm font-semibold text-[var(--text-primary)]">Available Plans</h2>
          <p className="text-xs text-[var(--text-faint)]">Upgrade or downgrade at any time — prorated billing</p>
        </div>
        <div className="grid grid-cols-4 gap-4 p-5">
          {PLANS.map((p) => {
            const isCurrent = p.tier === plan;
            const Icon = p.icon;
            return (
              <div key={p.tier} className={cn(
                "relative flex flex-col rounded-xl border p-5 transition-colors",
                isCurrent ? "border-[rgba(59,130,246,0.4)] bg-[rgba(59,130,246,0.05)]" : "border-[var(--border)]"
              )}>
                {p.popular && !isCurrent && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="rounded-full bg-[#3B82F6] px-3 py-0.5 text-[10px] font-bold text-white">
                      Most Popular
                    </span>
                  </div>
                )}
                {isCurrent && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="rounded-full bg-[rgba(59,130,246,0.2)] px-3 py-0.5 text-[10px] font-bold text-[#3B82F6] border border-[rgba(59,130,246,0.4)]">
                      Current Plan
                    </span>
                  </div>
                )}

                <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: `${p.iconColor}18` }}>
                  <Icon className="h-4.5 w-4.5" style={{ color: p.iconColor }} />
                </div>

                <p className="text-sm font-bold text-[var(--text-primary)]">{p.name}</p>

                <div className="mb-4 mt-1">
                  {p.custom ? (
                    <p className="font-tabular text-2xl font-bold text-[var(--text-primary)]">Custom</p>
                  ) : (
                    <p className="font-tabular text-2xl font-bold text-[var(--text-primary)]">
                      ${p.price}<span className="text-sm font-normal text-[var(--text-faint)]">/mo</span>
                    </p>
                  )}
                </div>

                <div className="flex-1 space-y-1.5 mb-4">
                  {p.features.map(f => (
                    <div key={f} className="flex items-start gap-2 text-xs">
                      <Check className="mt-0.5 h-3 w-3 flex-shrink-0 text-[#10B981]" />
                      <span className="text-[var(--text-secondary)]">{f}</span>
                    </div>
                  ))}
                  {p.missing.map(f => (
                    <div key={f} className="flex items-start gap-2 text-xs opacity-40">
                      <span className="mt-0.5 h-3 w-3 flex-shrink-0 text-center text-[var(--text-faint)]">×</span>
                      <span className="text-[var(--text-faint)]">{f}</span>
                    </div>
                  ))}
                </div>

                {isCurrent ? (
                  <button disabled className="w-full rounded-lg border border-[rgba(59,130,246,0.3)] py-2 text-xs font-semibold text-[#3B82F6] opacity-60">
                    Current Plan
                  </button>
                ) : p.custom ? (
                  <button
                    onClick={handleContactSales}
                    className="w-full rounded-lg bg-[#10B981] py-2 text-xs font-semibold text-white transition-colors hover:bg-[#059669]"
                  >
                    Contact Sales
                  </button>
                ) : (
                  <button
                    onClick={() => handleUpgrade(p.tier)}
                    disabled={loading === p.tier}
                    className={cn(
                      "w-full rounded-lg py-2 text-xs font-semibold transition-colors",
                      p.tier === "PROFESSIONAL"
                        ? "bg-[#3B82F6] text-white hover:bg-[#1D4ED8]"
                        : "border border-[var(--border-light)] text-[var(--text-secondary)] hover:border-[#9CA3AF] hover:text-[var(--text-primary)]",
                      "disabled:opacity-60"
                    )}
                  >
                    {loading === p.tier ? "Redirecting…" : PLAN_PRICES[p.tier] > PLAN_PRICES[plan] ? "Upgrade" : "Downgrade"}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
