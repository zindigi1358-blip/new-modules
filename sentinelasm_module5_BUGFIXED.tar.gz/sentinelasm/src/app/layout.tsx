import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import { ThemeProvider } from "@/components/providers/ThemeProvider";
import { QueryProvider } from "@/components/providers/QueryProvider";
import { Toaster } from "sonner";
import "@/styles/globals.css";

const inter = Inter({
  subsets:  ["latin"],
  variable: "--font-inter",
  display:  "swap",
});

export const metadata: Metadata = {
  title: {
    default:  "SentinelASM — Attack Surface Management",
    template: "%s | SentinelASM",
  },
  description:
    "Enterprise attack surface management platform. Continuously monitor, discover and secure your external attack surface.",
  robots: { index: false, follow: false }, // Private SaaS — never index
  icons: {
    icon: "/favicon.svg",
  },
};

export const viewport: Viewport = {
  themeColor:  [
    { media: "(prefers-color-scheme: dark)",  color: "#080B12" },
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
  ],
  width:       "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning className={inter.variable}>
      <body className="min-h-screen bg-[var(--bg-base)] font-sans antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange
        >
          <QueryProvider>
            {children}
            <Toaster
              position="bottom-right"
              theme="dark"
              toastOptions={{
                style: {
                  background: "#1C2333",
                  border:     "1px solid #1F2937",
                  color:      "#F9FAFB",
                  fontSize:   "13px",
                },
              }}
            />
          </QueryProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
