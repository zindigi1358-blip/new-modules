"use client";

import { useState, useCallback, useEffect } from "react";

// ─── Column Visibility ────────────────────────────────────────────────────────

export interface ColumnDef {
  key:      string;
  label:    string;
  default?: boolean; // visible by default?
}

/**
 * Persists column visibility in localStorage per table key.
 * Falls back gracefully if localStorage is unavailable.
 */
export function useColumnVisibility(tableKey: string, columns: ColumnDef[]) {
  const storageKey = `sentinel_cols_${tableKey}`;

  const getInitial = (): Record<string, boolean> => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) return JSON.parse(saved);
    } catch { /* ignore */ }
    // Default: all columns with default:true (or undefined) are visible
    return Object.fromEntries(columns.map(c => [c.key, c.default !== false]));
  };

  const [visible, setVisible] = useState<Record<string, boolean>>(getInitial);

  const toggle = useCallback((key: string) => {
    setVisible(prev => {
      const next = { ...prev, [key]: !prev[key] };
      try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  }, [storageKey]);

  const reset = useCallback(() => {
    const defaults = Object.fromEntries(columns.map(c => [c.key, c.default !== false]));
    try { localStorage.setItem(storageKey, JSON.stringify(defaults)); } catch { /* ignore */ }
    setVisible(defaults);
  }, [columns, storageKey]);

  const isVisible = useCallback((key: string) => visible[key] !== false, [visible]);

  return { visible, toggle, reset, isVisible };
}

// ─── Saved Filters ────────────────────────────────────────────────────────────

export interface SavedFilter {
  id:        string;
  name:      string;
  filters:   Record<string, string | boolean | string[]>;
  createdAt: number;
}

/**
 * Saves named filter presets per table in localStorage.
 */
export function useSavedFilters(tableKey: string) {
  const storageKey = `sentinel_filters_${tableKey}`;

  const load = (): SavedFilter[] => {
    try {
      const saved = localStorage.getItem(storageKey);
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  };

  const [savedFilters, setSavedFilters] = useState<SavedFilter[]>(load);

  const save = useCallback((name: string, filters: Record<string, string | boolean | string[]>) => {
    const newFilter: SavedFilter = {
      id:        crypto.randomUUID(),
      name,
      filters,
      createdAt: Date.now(),
    };
    setSavedFilters(prev => {
      const next = [...prev, newFilter];
      try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
    return newFilter;
  }, [storageKey]);

  const remove = useCallback((id: string) => {
    setSavedFilters(prev => {
      const next = prev.filter(f => f.id !== id);
      try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  }, [storageKey]);

  const rename = useCallback((id: string, name: string) => {
    setSavedFilters(prev => {
      const next = prev.map(f => f.id === id ? { ...f, name } : f);
      try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* ignore */ }
      return next;
    });
  }, [storageKey]);

  return { savedFilters, save, remove, rename };
}
