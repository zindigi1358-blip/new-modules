import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { verifyToken } from "@/lib/auth";

const PUBLIC_PATHS = [
  "/login",
  "/register",
  "/forgot-password",
  "/reset-password",
  "/accept-invitation",
  "/api/auth/login",
  "/api/auth/register",
  "/api/auth/forgot-password",
  "/api/auth/reset-password",
  "/api/auth/accept-invitation",
  "/api/auth/me",
  "/api/auth/logout",
  "/api/health",
  "/api/stripe/webhook",
];

const API_KEY_PATHS = ["/api/v1/"];

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Allow public paths
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  // Allow static assets and Next.js internals
  if (
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/fonts/")
  ) {
    return NextResponse.next();
  }

  // API key auth for v1 API routes
  if (API_KEY_PATHS.some((p) => pathname.startsWith(p))) {
    const authHeader = req.headers.get("authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json(
        { success: false, error: "API key required" },
        { status: 401 }
      );
    }
    // Full validation happens in route handlers — middleware just checks format
    return NextResponse.next();
  }

  // JWT auth for dashboard and internal API routes
  const cookieName = process.env.NEXT_PUBLIC_COOKIE_NAME ?? "sentinel_session";
  const token      = req.cookies.get(cookieName)?.value;

  if (!token) {
    // API routes return 401, page routes redirect to login
    if (pathname.startsWith("/api/")) {
      return NextResponse.json(
        { success: false, error: "Authentication required" },
        { status: 401 }
      );
    }
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("from", pathname);
    return NextResponse.redirect(loginUrl);
  }

  const session = await verifyToken(token);
  if (!session) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json(
        { success: false, error: "Session expired" },
        { status: 401 }
      );
    }
    const loginUrl = new URL("/login", req.url);
    return NextResponse.redirect(loginUrl);
  }

  // Inject session context into headers for route handlers
  const response = NextResponse.next();
  response.headers.set("x-user-id",   session.userId);
  response.headers.set("x-org-id",    session.orgId);
  response.headers.set("x-user-role", session.role);
  return response;
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};
