"use client";

import { useState, useRef, useEffect } from "react";
import { BookmarkPlus, Bookmark, Trash2, ChevronDown, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { SavedFilter } from "@/hooks/useTablePreferences";

interface SavedFiltersProps {
  savedFilters:   SavedFilter[];
  currentFilters: Record<string, string | boolean | string[]>;
  onSave:         (name: string, filters: Record<string, string | boolean | string[]>) => void;
  onLoad:         (filters: Record<string, string | boolean | string[]>) => void;
  onDelete:       (id: string) => void;
  /** Whether current filters match any saved preset */
  activeFilterId?: string;
}

export function SavedFilters({
  savedFilters,
  currentFilters,
  onSave,
  onLoad,
  onDelete,
  activeFilterId,
}: SavedFiltersProps) {
  const [open,     setOpen]     = useState(false);
  const [saving,   setSaving]   = useState(false);
  const [newName,  setNewName]  = useState("");
  const ref                     = useRef<HTMLDivElement>(null);
  const inputRef                = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setSaving(false);
        setNewName("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    if (saving) inputRef.current?.focus();
  }, [saving]);

  const handleSave = () => {
    const name = newName.trim();
    if (!name) return;
    onSave(name, currentFilters);
    setNewName("");
    setSaving(false);
    setOpen(false);
  };

  const hasActiveFilters = Object.values(currentFilters).some(v =>
    v !== "" && v !== false && !(Array.isArray(v) && v.length === 0)
  );

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          "flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-xs font-medium transition-colors",
          activeFilterId
            ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.08)] text-[#3B82F6]"
            : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
        )}
        aria-label="Saved filters"
        aria-expanded={open}
        aria-haspopup="listbox"
      >
        <Bookmark className="h-3.5 w-3.5" />
        Saved
        {savedFilters.length > 0 && (
          <span className="rounded-full bg-[var(--bg-elevated)] px-1.5 py-0.5 text-[9px] font-bold text-[var(--text-muted)]">
            {savedFilters.length}
          </span>
        )}
        <ChevronDown className={cn("h-3 w-3 transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div className="absolute right-0 top-full z-30 mt-1 w-60 overflow-hidden rounded-xl border border-[var(--border-light)] bg-[var(--bg-card)] shadow-xl">
          {/* Save current filters */}
          {hasActiveFilters && (
            <div className="border-b border-[var(--border)] p-2">
              {saving ? (
                <div className="flex gap-1.5">
                  <input
                    ref={inputRef}
                    type="text"
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === "Enter") handleSave();
                      if (e.key === "Escape") { setSaving(false); setNewName(""); }
                    }}
                    placeholder="Filter name…"
                    className="flex-1 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-2.5 py-1.5 text-xs text-[var(--text-primary)] placeholder-[var(--text-faint)] outline-none focus:border-[#3B82F6]"
                  />
                  <button
                    onClick={handleSave}
                    disabled={!newName.trim()}
                    className="rounded-lg bg-[#3B82F6] px-2.5 py-1.5 text-xs font-semibold text-white disabled:opacity-40 hover:bg-[#1D4ED8]"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setSaving(true)}
                  className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-xs font-medium text-[#3B82F6] transition-colors hover:bg-[rgba(59,130,246,0.08)]"
                >
                  <BookmarkPlus className="h-3.5 w-3.5" />
                  Save current filters
                </button>
              )}
            </div>
          )}

          {/* List of saved filters */}
          {savedFilters.length === 0 ? (
            <div className="flex flex-col items-center py-6 text-center">
              <Bookmark className="mb-2 h-6 w-6 text-[var(--text-faint)]" />
              <p className="text-xs text-[var(--text-muted)]">No saved filters yet</p>
              <p className="mt-0.5 text-[10px] text-[var(--text-faint)]">
                Apply filters then save them here
              </p>
            </div>
          ) : (
            <div className="max-h-52 overflow-y-auto py-1">
              {savedFilters.map(filter => (
                <div
                  key={filter.id}
                  className={cn(
                    "group flex items-center gap-2 px-3 py-2 transition-colors hover:bg-[var(--bg-elevated)]",
                    activeFilterId === filter.id && "bg-[rgba(59,130,246,0.06)]"
                  )}
                >
                  <button
                    onClick={() => { onLoad(filter.filters); setOpen(false); }}
                    className="flex flex-1 items-center gap-2 text-left"
                  >
                    {activeFilterId === filter.id && (
                      <Check className="h-3 w-3 flex-shrink-0 text-[#3B82F6]" />
                    )}
                    <span className={cn(
                      "text-sm transition-colors",
                      activeFilterId === filter.id
                        ? "font-medium text-[#3B82F6]"
                        : "text-[var(--text-primary)]"
                    )}>
                      {filter.name}
                    </span>
                  </button>
                  <button
                    onClick={e => { e.stopPropagation(); onDelete(filter.id); }}
                    className="hidden rounded p-0.5 text-[var(--text-faint)] transition-colors hover:bg-[rgba(239,68,68,0.1)] hover:text-[#EF4444] group-hover:block"
                    aria-label={`Delete filter "${filter.name}"`}
                  >
                    <Trash2 className="h-3 w-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
