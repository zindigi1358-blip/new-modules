"use client";

import { useState, useRef, useEffect } from "react";
import { Columns, RotateCcw, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ColumnDef } from "@/hooks/useTablePreferences";

interface ColumnToggleProps {
  columns:   ColumnDef[];
  visible:   Record<string, boolean>;
  onToggle:  (key: string) => void;
  onReset:   () => void;
}

export function ColumnToggle({ columns, visible, onToggle, onReset }: ColumnToggleProps) {
  const [open, setOpen] = useState(false);
  const ref             = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const hiddenCount = columns.filter(c => visible[c.key] === false).length;

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          "flex h-8 items-center gap-1.5 rounded-lg border px-2.5 text-xs font-medium transition-colors",
          hiddenCount > 0
            ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.08)] text-[#3B82F6]"
            : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
        )}
        aria-label="Toggle column visibility"
        aria-expanded={open}
        aria-haspopup="listbox"
      >
        <Columns className="h-3.5 w-3.5" />
        Columns
        {hiddenCount > 0 && (
          <span className="rounded-full bg-[#3B82F6] px-1.5 py-0.5 text-[9px] font-bold text-white">
            {hiddenCount} hidden
          </span>
        )}
      </button>

      {open && (
        <div
          className="absolute right-0 top-full z-30 mt-1 w-52 overflow-hidden rounded-xl border border-[var(--border-light)] bg-[var(--bg-card)] shadow-xl"
          role="listbox"
          aria-label="Column visibility"
        >
          <div className="border-b border-[var(--border)] px-3 py-2.5">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-[var(--text-muted)]">
              Toggle Columns
            </p>
          </div>
          <div className="max-h-64 overflow-y-auto py-1">
            {columns.map(col => {
              const isVisible = visible[col.key] !== false;
              return (
                <button
                  key={col.key}
                  onClick={() => onToggle(col.key)}
                  role="option"
                  aria-selected={isVisible}
                  className="flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm transition-colors hover:bg-[var(--bg-elevated)]"
                >
                  <div className={cn(
                    "flex h-4 w-4 flex-shrink-0 items-center justify-center rounded border transition-colors",
                    isVisible
                      ? "border-[#3B82F6] bg-[#3B82F6]"
                      : "border-[var(--border-light)] bg-transparent"
                  )}>
                    {isVisible && <Check className="h-2.5 w-2.5 text-white" />}
                  </div>
                  <span className={cn(
                    "transition-colors",
                    isVisible ? "text-[var(--text-primary)]" : "text-[var(--text-muted)]"
                  )}>
                    {col.label}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="border-t border-[var(--border)] p-2">
            <button
              onClick={() => { onReset(); setOpen(false); }}
              className="flex w-full items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-medium text-[var(--text-muted)] transition-colors hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]"
            >
              <RotateCcw className="h-3 w-3" />
              Reset to defaults
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
