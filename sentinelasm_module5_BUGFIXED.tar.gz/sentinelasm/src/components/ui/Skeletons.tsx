"use client";

import type { CSSProperties } from "react";
import { cn } from "@/lib/utils";

// ─── Base skeleton block ───────────────────────────────────────────────────────

function Skeleton({ className, style }: { className?: string; style?: CSSProperties }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded bg-[#1C2333]",
        className
      )}
      style={style}
      aria-hidden="true"
    />
  );
}

// ─── Metric card skeleton ──────────────────────────────────────────────────────

export function MetricCardSkeleton() {
  return (
    <div className="relative overflow-hidden rounded-xl border border-[#1F2937] bg-[#111827] p-5">
      <div className="absolute inset-x-0 top-0 h-0.5 bg-[#1C2333]" />
      <Skeleton className="mb-3 h-3 w-24" />
      <Skeleton className="h-8 w-16" />
      <div className="mt-3 flex items-center justify-between">
        <Skeleton className="h-3 w-20" />
        <Skeleton className="h-3 w-12" />
      </div>
      <div className="mt-3 h-1 rounded-full bg-[#1C2333]" />
    </div>
  );
}

// ─── Dashboard skeleton ────────────────────────────────────────────────────────

export function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-72" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-8 w-24" />
        </div>
      </div>

      {/* Score + metrics */}
      <div className="grid grid-cols-[200px_1fr] gap-4">
        <div className="rounded-xl border border-[#1F2937] bg-[#111827] p-6">
          <div className="flex flex-col items-center gap-4">
            <Skeleton className="h-[140px] w-[140px] rounded-full" />
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-3 w-24" />
          </div>
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-4 gap-3">
            {[...Array(4)].map((_, i) => <MetricCardSkeleton key={i} />)}
          </div>
          <div className="grid grid-cols-4 gap-3">
            {[...Array(4)].map((_, i) => <MetricCardSkeleton key={i} />)}
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-[1fr_320px] gap-4">
        <div className="rounded-xl border border-[#1F2937] bg-[#111827] p-5">
          <Skeleton className="mb-4 h-4 w-48" />
          <Skeleton className="h-[200px] w-full" />
        </div>
        <div className="rounded-xl border border-[#1F2937] bg-[#111827] p-5">
          <Skeleton className="mb-4 h-4 w-32" />
          <Skeleton className="h-[160px] w-full rounded-full" />
          <div className="mt-3 grid grid-cols-2 gap-2">
            {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-4" />)}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-[1fr_340px] gap-4">
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="border-b border-[#1F2937] p-4">
            <Skeleton className="h-4 w-56" />
          </div>
          <div className="divide-y divide-[#1F2937]">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4 px-4 py-3">
                <Skeleton className="h-4 w-48" />
                <Skeleton className="ml-auto h-5 w-12" />
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-5 w-16" />
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="border-b border-[#1F2937] p-4">
            <Skeleton className="h-4 w-36" />
          </div>
          <div className="divide-y divide-[#1F2937]">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="flex gap-3 px-5 py-3">
                <Skeleton className="h-7 w-7 flex-shrink-0 rounded-lg" />
                <div className="flex-1 space-y-1.5">
                  <Skeleton className="h-3.5 w-full" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Table skeleton ────────────────────────────────────────────────────────────

export function TableSkeleton({ rows = 8, cols = 6 }: { rows?: number; cols?: number }) {
  return (
    <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
      {/* Filter bar */}
      <div className="flex gap-3 border-b border-[#1F2937] px-4 py-3">
        <Skeleton className="h-8 w-64 flex-1" />
        <Skeleton className="h-8 w-20" />
        <Skeleton className="h-8 w-20" />
        <Skeleton className="h-8 w-32" />
      </div>
      {/* Table head */}
      <div className="flex gap-4 border-b border-[#1F2937] px-4 py-2.5">
        {[...Array(cols)].map((_, i) => (
          <Skeleton key={i} className="h-3" style={{ width: `${60 + i * 20}px` }} />
        ))}
      </div>
      {/* Rows */}
      {[...Array(rows)].map((_, i) => (
        <div key={i} className="flex items-center gap-4 border-b border-[#1F2937] px-4 py-3.5 last:border-0">
          {[...Array(cols)].map((_, j) => (
            <Skeleton key={j} className="h-4" style={{ width: `${50 + j * 25}px` }} />
          ))}
        </div>
      ))}
      {/* Footer */}
      <div className="flex items-center justify-between border-t border-[#1F2937] px-4 py-3">
        <Skeleton className="h-3 w-32" />
        <div className="flex gap-1">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-7 w-7" />)}
        </div>
      </div>
    </div>
  );
}

// ─── Assets page skeleton ──────────────────────────────────────────────────────

export function AssetsSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-4 w-56" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-8 w-28" />
          <Skeleton className="h-8 w-24" />
        </div>
      </div>
      <div className="grid grid-cols-5 gap-3">
        {[...Array(5)].map((_, i) => <MetricCardSkeleton key={i} />)}
      </div>
      <TableSkeleton rows={10} cols={7} />
    </div>
  );
}

// ─── Findings page skeleton ────────────────────────────────────────────────────

export function FindingsSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-28" />
          <Skeleton className="h-4 w-72" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-8 w-28" />
          <Skeleton className="h-8 w-20" />
        </div>
      </div>
      {/* Tabs */}
      <div className="flex gap-1 border-b border-[#1F2937] pb-0">
        {[...Array(5)].map((_, i) => (
          <Skeleton key={i} className="mb-0 h-9 w-24" />
        ))}
      </div>
      <TableSkeleton rows={12} cols={8} />
    </div>
  );
}

// ─── Scans page skeleton ───────────────────────────────────────────────────────

export function ScansSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-4 w-64" />
        </div>
        <Skeleton className="h-8 w-24" />
      </div>
      {/* Active scans */}
      <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
        <div className="border-b border-[#1F2937] p-4">
          <Skeleton className="h-4 w-32" />
        </div>
        <div className="space-y-3 p-4">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="rounded-lg border border-[#1F2937] bg-[#0D1117] p-4 space-y-3">
              <div className="flex justify-between">
                <div className="space-y-1.5">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-3 w-56" />
                </div>
                <Skeleton className="h-6 w-20" />
              </div>
              <Skeleton className="h-1 w-full" />
              <div className="flex justify-between">
                <Skeleton className="h-3 w-40" />
                <Skeleton className="h-3 w-20" />
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {[...Array(7)].map((_, j) => <Skeleton key={j} className="h-5 w-24 rounded-full" />)}
              </div>
            </div>
          ))}
        </div>
      </div>
      <TableSkeleton rows={5} cols={8} />
    </div>
  );
}

// ─── Settings skeleton ─────────────────────────────────────────────────────────

export function SettingsSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-28" />
          <Skeleton className="h-4 w-64" />
        </div>
        <Skeleton className="h-8 w-28" />
      </div>
      <div className="grid grid-cols-[200px_1fr] gap-5">
        <div className="h-[400px] rounded-xl border border-[#1F2937] bg-[#111827] p-2 space-y-1">
          {[...Array(9)].map((_, i) => <Skeleton key={i} className="h-8 w-full" />)}
        </div>
        <div className="space-y-4">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="rounded-xl border border-[#1F2937] bg-[#111827]">
              <div className="border-b border-[#1F2937] p-4"><Skeleton className="h-4 w-32" /></div>
              {[...Array(3)].map((_, j) => (
                <div key={j} className="flex justify-between border-b border-[#1F2937] px-5 py-4 last:border-0">
                  <div className="space-y-1.5">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-48" />
                  </div>
                  <Skeleton className="h-8 w-52" />
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Generic page skeleton ─────────────────────────────────────────────────────

export function PageSkeleton() {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-64" />
        </div>
        <Skeleton className="h-8 w-28" />
      </div>
      <div className="grid grid-cols-2 gap-5">
        <div className="rounded-xl border border-[#1F2937] bg-[#111827] p-5 space-y-4">
          <Skeleton className="h-4 w-40" />
          {[...Array(4)].map((_, i) => (
            <div key={i} className="space-y-1.5">
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-9 w-full" />
            </div>
          ))}
          <Skeleton className="h-10 w-full" />
        </div>
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="border-b border-[#1F2937] p-4"><Skeleton className="h-4 w-32" /></div>
          {[...Array(4)].map((_, i) => (
            <div key={i} className="flex items-center gap-3 border-b border-[#1F2937] px-4 py-3.5 last:border-0">
              <Skeleton className="h-9 w-9 flex-shrink-0 rounded-lg" />
              <div className="flex-1 space-y-1">
                <Skeleton className="h-3.5 w-40" />
                <Skeleton className="h-3 w-28" />
              </div>
              <Skeleton className="h-7 w-16" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
