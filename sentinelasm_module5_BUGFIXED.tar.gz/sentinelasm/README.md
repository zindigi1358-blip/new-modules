# SentinelASM — Module 5: Multi-Tenant SaaS Dashboard

A production-grade Next.js 15 dashboard for the SentinelASM automated Attack Surface Management platform. Consumes scan output from Modules 1–4 and presents it through a multi-tenant, role-based SaaS interface.

---

## Tech Stack

| Layer        | Technology |
|---|---|
| Framework    | Next.js 15 (App Router) |
| Language     | TypeScript 5 (strict) |
| Database     | PostgreSQL via Prisma ORM |
| Auth         | JWT (jose) + iron-session |
| UI           | Tailwind CSS 3, Framer Motion, Recharts |
| Forms        | React Hook Form + Zod |
| Server State | TanStack Query v5 |
| Billing      | Stripe Subscriptions |
| Real-time    | Server-Sent Events (SSE) |
| Deployment   | Docker + GitHub Actions |

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env — minimum required:
#   DATABASE_URL
#   JWT_SECRET        (min 32 chars)
#   SESSION_PASSWORD  (min 32 chars)

# 3. Database setup
npx prisma db push
npx prisma db seed

# 4. Start dev server
npm run dev
# → http://localhost:3000
```

### Demo credentials (after seed)

| Email | Password | Role |
|---|---|---|
| ali@acmecorp.com   | password123 | Analyst |
| sara@acmecorp.com  | password123 | Owner   |
| ahmed@acmecorp.com | password123 | Admin   |

---

## Project Structure

```
src/
├── app/
│   ├── (auth)/                 # Login, register, forgot/reset password, invite
│   ├── (dashboard)/
│   │   └── dashboard/
│   │       ├── page.tsx        # Dashboard home
│   │       ├── assets/         # Asset inventory
│   │       ├── scans/          # Scan management + live progress
│   │       ├── findings/       # Vulnerability findings
│   │       ├── reports/        # PDF report generation
│   │       ├── notifications/  # Alert channel config
│   │       ├── api-keys/       # API key management
│   │       ├── team/           # Team + invitations
│   │       ├── billing/        # Stripe subscription
│   │       └── settings/       # Profile, security, org, audit log
│   ├── api/
│   │   ├── auth/               # login, register, logout, me, forgot-password,
│   │   │                       #   reset-password, accept-invitation
│   │   ├── dashboard/stats/    # Composite security score + metrics
│   │   ├── assets/             # Asset CRUD with filtering
│   │   ├── findings/           # Finding CRUD + status updates
│   │   ├── scans/              # Scan management + SSE stream
│   │   ├── reports/            # Report generation (calls Module 4)
│   │   ├── notifications/      # Notification list + mark-read
│   │   ├── api-keys/           # API key creation + revocation
│   │   ├── team/               # Members + invitations
│   │   ├── alert-configs/      # Alert channel upsert
│   │   ├── organizations/      # List + switch + create
│   │   ├── audit-logs/         # Paginated audit log
│   │   ├── billing/checkout/   # Stripe checkout session
│   │   ├── stripe/webhook/     # Stripe subscription lifecycle
│   │   ├── settings/           # Profile + org settings
│   │   └── health/             # Health check for Docker
│   └── new-organization/       # Create additional org
├── components/
│   ├── layout/
│   │   ├── SidebarV2.tsx       # Collapsible sidebar with OrgSwitcher
│   │   ├── TopbarV2.tsx        # Breadcrumbs, search, notifications
│   │   ├── CommandPalette.tsx  # ⌘K command palette
│   │   ├── NotificationPanel.tsx
│   │   └── OrgSwitcher.tsx     # Multi-org switcher
│   ├── providers/
│   │   ├── QueryProvider.tsx
│   │   └── ThemeProvider.tsx
│   └── ui/
│       ├── Badge.tsx           # SeverityBadge, CvssPill
│       ├── FindingDrawer.tsx   # Finding detail slide-in panel
│       ├── AssetDrawer.tsx     # Asset detail slide-in panel
│       ├── Skeletons.tsx       # Loading skeletons for every page
│       ├── EmptyStates.tsx     # Empty states with CTAs
│       ├── PermissionGate.tsx  # Role-based UI gating
│       ├── ThemeToggle.tsx     # Light/dark toggle
│       ├── ColumnToggle.tsx    # Table column visibility
│       └── SavedFilters.tsx    # Named filter presets
├── hooks/
│   ├── index.ts                # All TanStack Query hooks
│   ├── useSession.ts           # Client-side session
│   ├── useScanStream.ts        # SSE scan progress hook
│   └── useTablePreferences.ts  # Column visibility + saved filters
├── lib/
│   ├── auth.ts                 # JWT, session, RBAC helpers
│   ├── api.ts                  # Response helpers (ok, badRequest…)
│   ├── db.ts                   # Prisma singleton
│   └── utils.ts                # cn, timeAgo, formatDate, etc.
├── styles/
│   └── globals.css             # CSS custom properties (dark + light)
└── types/
    └── index.ts                # Shared TypeScript types
```

---

## Environment Variables

See `.env.example` for full documentation. Minimum required:

```bash
DATABASE_URL="postgresql://..."
JWT_SECRET="min-32-chars"
SESSION_PASSWORD="min-32-chars"
```

Optional (app works without these):
- `STRIPE_*` — billing features
- `PYTHON_BACKEND_URL` — PDF report generation (Module 4)
- `SMTP_*` — email for password reset + invitations

---

## Database

```bash
# Apply schema
npx prisma db push

# Seed demo data
npx prisma db seed

# Open Prisma Studio
npx prisma studio

# Reset database
npx prisma db push --force-reset && npx prisma db seed
```

---

## Docker

```bash
# Development
docker compose up

# Production build
docker compose -f docker-compose.yml up --build -d

# View logs
docker compose logs -f dashboard
```

---

## RBAC (Role-Based Access Control)

| Permission             | Owner | Admin | Analyst | Viewer |
|---|:---:|:---:|:---:|:---:|
| View Dashboard         | ✅ | ✅ | ✅ | ✅ |
| Run Scans              | ✅ | ✅ | ✅ | ❌ |
| Manage Findings        | ✅ | ✅ | ✅ | ❌ |
| Generate Reports       | ✅ | ✅ | ✅ | ❌ |
| Manage API Keys        | ✅ | ✅ | ❌ | ❌ |
| Invite Members         | ✅ | ✅ | ❌ | ❌ |
| Change Roles           | ✅ | ❌ | ❌ | ❌ |
| Billing & Plans        | ✅ | ❌ | ❌ | ❌ |

---

## API Authentication

All API routes require a valid session cookie (set on login). External integrations use API keys:

```bash
curl https://your-domain.com/api/v1/assets \
  -H "Authorization: Bearer sk_live_your_key_here"
```

---

## Module Integration

This dashboard (Module 5) connects to the Python scan engine (Modules 1–4):

```
Module 1  →  Asset/subdomain discovery
Module 2  →  CVE scoring + KEV matching  
Module 3  →  Risk scoring engine
Module 4  →  PDF report generation
Module 5  →  This dashboard (consumes all above)
```

Set `PYTHON_BACKEND_URL` in `.env` to point to the running Python backend.

---

## Production Deployment

```bash
# Via Docker (recommended)
docker compose up -d

# Manual
npm run build
npm start

# Environment check
curl https://your-domain.com/api/health
```

---

## Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run type-check   # TypeScript check without emit
npm run lint         # ESLint
npm run db:push      # Apply schema to database
npm run db:seed      # Seed demo data
npm run db:studio    # Open Prisma Studio GUI
```
