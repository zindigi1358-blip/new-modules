"use client";

import { useSession } from "@/hooks/useSession";
import type { MemberRole } from "@/types";

const ROLE_HIERARCHY: Record<MemberRole, number> = {
  OWNER:   4,
  ADMIN:   3,
  ANALYST: 2,
  VIEWER:  1,
};

interface PermissionGateProps {
  /** Minimum role required to see the children */
  role:        MemberRole;
  /** What to render if access is denied (default: nothing) */
  fallback?:   React.ReactNode;
  children:    React.ReactNode;
}

/**
 * Wraps any UI element and only renders it if the current user has
 * at least the required role. Use this instead of scattering role
 * checks throughout components.
 *
 * @example
 * <PermissionGate role="ADMIN">
 *   <DeleteButton />
 * </PermissionGate>
 *
 * <PermissionGate role="OWNER" fallback={<UpgradeBanner />}>
 *   <BillingSettings />
 * </PermissionGate>
 */
export function PermissionGate({ role, fallback = null, children }: PermissionGateProps) {
  const { session } = useSession();

  if (!session) return <>{fallback}</>;

  const userLevel     = ROLE_HIERARCHY[session.role] ?? 0;
  const requiredLevel = ROLE_HIERARCHY[role]         ?? 99;

  if (userLevel < requiredLevel) return <>{fallback}</>;

  return <>{children}</>;
}

// ─── Convenience wrappers ──────────────────────────────────────────────────────

export function OwnerOnly({ children, fallback }: { children: React.ReactNode; fallback?: React.ReactNode }) {
  return <PermissionGate role="OWNER" fallback={fallback}>{children}</PermissionGate>;
}

export function AdminOnly({ children, fallback }: { children: React.ReactNode; fallback?: React.ReactNode }) {
  return <PermissionGate role="ADMIN" fallback={fallback}>{children}</PermissionGate>;
}

export function AnalystOnly({ children, fallback }: { children: React.ReactNode; fallback?: React.ReactNode }) {
  return <PermissionGate role="ANALYST" fallback={fallback}>{children}</PermissionGate>;
}

// ─── Hook version for imperative checks ───────────────────────────────────────

export function usePermission(requiredRole: MemberRole): boolean {
  const { session } = useSession();
  if (!session) return false;
  return (ROLE_HIERARCHY[session.role] ?? 0) >= (ROLE_HIERARCHY[requiredRole] ?? 99);
}
