"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X, Globe, Clock, Shield, AlertTriangle,
  ChevronRight, Server, Cloud, Wifi,
} from "lucide-react";
import { cn, timeAgo, formatDateTime } from "@/lib/utils";
import { SeverityBadge } from "@/components/ui/Badge";
import type { FindingSeverity } from "@/types";

interface AssetFinding {
  id:            string;
  title:         string;
  severity:      FindingSeverity;
  riskScore:     number;
  status:        string;
}

interface AssetDetail {
  id:            string;
  subdomain:     string | null;
  ipAddress:     string | null;
  url:           string | null;
  assetType:     string;
  isAlive:       boolean;
  httpStatus:    number | null;
  httpsStatus:   number | null;
  title:         string | null;
  openPorts:     number[];
  technologies:  string[];
  cloudProvider: string | null;
  cloudAssetType:string | null;
  isPublic:      boolean | null;
  firstSeenAt:   string | Date;
  lastSeenAt:    string | Date;
  findings?:     AssetFinding[];
}

interface AssetDrawerProps {
  asset:   AssetDetail | null;
  open:    boolean;
  onClose: () => void;
}

const PORT_SERVICES: Record<number, string> = {
  21:"FTP", 22:"SSH", 23:"Telnet", 25:"SMTP", 53:"DNS",
  80:"HTTP", 110:"POP3", 143:"IMAP", 443:"HTTPS", 587:"SMTP/TLS",
  993:"IMAPS", 995:"POP3S", 1194:"OpenVPN", 2375:"Docker API",
  3000:"Dev Server", 3306:"MySQL", 3389:"RDP", 5432:"PostgreSQL",
  5900:"VNC", 6379:"Redis", 8080:"HTTP Alt", 8443:"HTTPS Alt",
  9200:"Elasticsearch", 27017:"MongoDB",
};

const RISKY_PORTS = new Set([21, 23, 2375, 3389, 5900, 6379, 9200, 27017]);

function PortBadge({ port }: { port: number }) {
  const service = PORT_SERVICES[port] ?? "Unknown";
  const isRisky = RISKY_PORTS.has(port);
  return (
    <div className={cn(
      "flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5",
      isRisky
        ? "border-[rgba(239,68,68,0.3)] bg-[rgba(239,68,68,0.05)]"
        : "border-[#1F2937] bg-[#111827]"
    )}>
      <span className="font-tabular text-xs font-bold" style={{ color: isRisky ? "#EF4444" : "#F9FAFB" }}>
        {port}
      </span>
      <span className="text-[10px] text-[#6B7280]">{service}</span>
      {isRisky && <AlertTriangle className="h-3 w-3 text-[#EF4444]" />}
    </div>
  );
}

export function AssetDrawer({ asset, open, onClose }: AssetDrawerProps) {
  const [activeTab, setActiveTab] = useState<"overview"|"ports"|"findings">("overview");

  if (!asset) return null;

  const findings     = asset.findings ?? [];
  const riskyPorts   = asset.openPorts.filter(p => RISKY_PORTS.has(p));
  const safeFindings = findings.filter(f => f.status !== "RESOLVED");

  const TABS = [
    { id: "overview", label: "Overview" },
    { id: "ports",    label: `Ports (${asset.openPorts.length})` },
    { id: "findings", label: `Findings (${safeFindings.length})` },
  ] as const;

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40 bg-black/50"
            onClick={onClose} aria-hidden
          />

          <motion.aside
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
            className="fixed right-0 top-0 z-50 flex h-full w-[480px] flex-col border-l border-[#1F2937] bg-[#0D1117] shadow-2xl"
            role="dialog" aria-modal aria-label={`Asset: ${asset.subdomain ?? asset.ipAddress}`}
          >
            {/* Header */}
            <div className="flex-shrink-0 border-b border-[#1F2937] p-5">
              <div className="flex items-start gap-3">
                <div className={cn(
                  "flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl",
                  asset.assetType === "CLOUD_ASSET"
                    ? "bg-[rgba(59,130,246,0.1)]"
                    : "bg-[rgba(16,185,129,0.1)]"
                )}>
                  {asset.assetType === "CLOUD_ASSET"
                    ? <Cloud className="h-5 w-5 text-[#3B82F6]" />
                    : <Globe className="h-5 w-5 text-[#10B981]" />
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <h2 className="font-mono text-sm font-bold text-[#F9FAFB]">
                    {asset.subdomain ?? asset.ipAddress ?? asset.url ?? "Unknown Asset"}
                  </h2>
                  <div className="mt-1 flex flex-wrap items-center gap-2">
                    <span className={cn(
                      "flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold",
                      asset.isAlive
                        ? "bg-[rgba(16,185,129,0.1)] text-[#10B981]"
                        : "bg-[rgba(239,68,68,0.1)] text-[#EF4444]"
                    )}>
                      <span className={cn("h-1.5 w-1.5 rounded-full bg-current", asset.isAlive && "animate-pulse")} />
                      {asset.isAlive ? "Alive" : "Offline"}
                    </span>
                    {(asset.httpsStatus ?? asset.httpStatus) && (
                      <span className="font-tabular rounded bg-[#1C2333] px-2 py-0.5 text-[10px] text-[#9CA3AF]">
                        HTTP {asset.httpsStatus ?? asset.httpStatus}
                      </span>
                    )}
                    {asset.isPublic === true && (
                      <span className="rounded-full bg-[rgba(239,68,68,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#EF4444]">
                        PUBLIC
                      </span>
                    )}
                    {riskyPorts.length > 0 && (
                      <span className="flex items-center gap-1 rounded-full bg-[rgba(239,68,68,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#EF4444]">
                        <AlertTriangle className="h-3 w-3" /> {riskyPorts.length} risky port{riskyPorts.length > 1 ? "s" : ""}
                      </span>
                    )}
                  </div>
                </div>
                <button onClick={onClose}
                  className="flex h-7 w-7 items-center justify-center rounded-lg text-[#6B7280] hover:bg-[#1C2333] hover:text-[#F9FAFB]">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex flex-shrink-0 border-b border-[#1F2937] px-5">
              {TABS.map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "border-b-2 px-3 pb-3 pt-3 text-xs font-medium transition-colors",
                    activeTab === tab.id
                      ? "border-[#3B82F6] text-[#3B82F6]"
                      : "border-transparent text-[#6B7280] hover:text-[#9CA3AF]"
                  )}>
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5">

              {activeTab === "overview" && (
                <div className="space-y-5">
                  {/* Page title */}
                  {asset.title && (
                    <div>
                      <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.8px] text-[#6B7280]">Page Title</p>
                      <p className="text-sm text-[#D1D5DB]">"{asset.title}"</p>
                    </div>
                  )}

                  {/* Details */}
                  <div className="rounded-lg border border-[#1F2937] bg-[#111827]">
                    {[
                      asset.ipAddress  && { label: "IP Address",   value: <span className="font-mono text-xs">{asset.ipAddress}</span> },
                      asset.subdomain  && { label: "Subdomain",    value: <span className="font-mono text-xs">{asset.subdomain}</span> },
                      { label: "Asset Type",   value: asset.assetType.replace(/_/g, " ") },
                      asset.cloudProvider && { label: "Cloud Provider", value: `${asset.cloudProvider} / ${asset.cloudAssetType}` },
                      { label: "First Seen",   value: formatDateTime(asset.firstSeenAt) },
                      { label: "Last Seen",    value: timeAgo(asset.lastSeenAt) },
                    ].filter(Boolean).map((row: any, i: number) => (
                      <div key={i} className="flex items-center justify-between border-b border-[#1F2937] px-4 py-2.5 last:border-0">
                        <span className="text-xs text-[#6B7280]">{row.label}</span>
                        <div className="text-xs text-[#F9FAFB]">{row.value}</div>
                      </div>
                    ))}
                  </div>

                  {/* Technologies */}
                  {asset.technologies.length > 0 && (
                    <div>
                      <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.8px] text-[#6B7280]">Technologies Detected</p>
                      <div className="flex flex-wrap gap-1.5">
                        {asset.technologies.map(t => (
                          <span key={t} className={cn(
                            "rounded-lg border px-2.5 py-1 text-xs font-medium",
                            (t.includes("5.6") || t.includes("2.2") || t.includes("3.1."))
                              ? "border-[rgba(239,68,68,0.3)] bg-[rgba(239,68,68,0.05)] text-[#EF4444]"
                              : "border-[#1F2937] bg-[#111827] text-[#D1D5DB]"
                          )}>
                            {t}
                            {(t.includes("5.6") || t.includes("2.2")) && (
                              <span className="ml-1 text-[#EF4444]">⚠ EOL</span>
                            )}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === "ports" && (
                <div className="space-y-4">
                  {asset.openPorts.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <Wifi className="mb-3 h-10 w-10 text-[#374151]" />
                      <p className="text-sm text-[#6B7280]">No open ports detected</p>
                    </div>
                  ) : (
                    <>
                      {riskyPorts.length > 0 && (
                        <div className="rounded-lg border border-[rgba(239,68,68,0.2)] bg-[rgba(239,68,68,0.05)] p-3">
                          <p className="mb-1.5 text-xs font-semibold text-[#EF4444]">
                            ⚠ {riskyPorts.length} risky port{riskyPorts.length > 1 ? "s" : ""} detected
                          </p>
                          <p className="text-xs text-[#9CA3AF]">
                            Ports {riskyPorts.join(", ")} expose sensitive services to the internet.
                            These should be firewalled immediately.
                          </p>
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-2">
                        {asset.openPorts.map(port => (
                          <PortBadge key={port} port={port} />
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}

              {activeTab === "findings" && (
                <div className="space-y-2">
                  {safeFindings.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <Shield className="mb-3 h-10 w-10 text-[#10B981]" />
                      <p className="text-sm font-medium text-[#10B981]">No open findings</p>
                      <p className="mt-1 text-xs text-[#6B7280]">This asset has no unresolved security issues.</p>
                    </div>
                  ) : (
                    safeFindings.map(f => (
                      <div key={f.id} className="flex items-start gap-3 rounded-lg border border-[#1F2937] bg-[#111827] p-3">
                        <SeverityBadge severity={f.severity} dot />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-[#F9FAFB]">{f.title}</p>
                          <p className="mt-0.5 font-tabular text-[11px] text-[#6B7280]">
                            Score: <span className="text-[#F9FAFB]">{f.riskScore}</span>
                          </p>
                        </div>
                        <ChevronRight className="h-3.5 w-3.5 flex-shrink-0 text-[#6B7280]" />
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
