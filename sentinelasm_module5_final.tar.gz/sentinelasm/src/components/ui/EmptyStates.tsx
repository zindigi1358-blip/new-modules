"use client";

import Link from "next/link";
import {
  Globe, ScanLine, AlertTriangle, FileText, Bell,
  Key, Users, Shield, Search, Inbox, CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ─── Base empty state ──────────────────────────────────────────────────────────

interface EmptyStateProps {
  icon:        React.ElementType;
  iconColor?:  string;
  iconBg?:     string;
  title:       string;
  description: string;
  primaryCta?: { label: string; href?: string; onClick?: () => void };
  secondaryCta?:{ label: string; href?: string; onClick?: () => void };
  className?:  string;
}

export function EmptyState({
  icon: Icon,
  iconColor = "#6B7280",
  iconBg    = "#1C2333",
  title,
  description,
  primaryCta,
  secondaryCta,
  className,
}: EmptyStateProps) {
  return (
    <div className={cn(
      "flex flex-col items-center justify-center px-6 py-16 text-center",
      className
    )}>
      {/* Icon */}
      <div
        className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl"
        style={{ background: iconBg }}
      >
        <Icon className="h-7 w-7" style={{ color: iconColor }} aria-hidden />
      </div>

      {/* Text */}
      <h3 className="mb-2 text-base font-semibold text-[#F9FAFB]">{title}</h3>
      <p className="mb-6 max-w-sm text-sm leading-relaxed text-[#6B7280]">{description}</p>

      {/* CTAs */}
      {(primaryCta || secondaryCta) && (
        <div className="flex flex-wrap items-center justify-center gap-3">
          {primaryCta && (
            primaryCta.href ? (
              <Link
                href={primaryCta.href}
                className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-4 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
              >
                {primaryCta.label}
              </Link>
            ) : (
              <button
                onClick={primaryCta.onClick}
                className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-4 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
              >
                {primaryCta.label}
              </button>
            )
          )}
          {secondaryCta && (
            secondaryCta.href ? (
              <Link
                href={secondaryCta.href}
                className="flex h-8 items-center gap-1.5 rounded-lg border border-[#1F2937] px-4 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151] hover:text-[#F9FAFB]"
              >
                {secondaryCta.label}
              </Link>
            ) : (
              <button
                onClick={secondaryCta.onClick}
                className="flex h-8 items-center gap-1.5 rounded-lg border border-[#1F2937] px-4 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151] hover:text-[#F9FAFB]"
              >
                {secondaryCta.label}
              </button>
            )
          )}
        </div>
      )}
    </div>
  );
}

// ─── Context-specific empty states ────────────────────────────────────────────

export function NoAssetsEmpty({ onAddDomain }: { onAddDomain?: () => void }) {
  return (
    <EmptyState
      icon={Globe}
      iconColor="#3B82F6"
      iconBg="rgba(59,130,246,0.1)"
      title="No assets discovered yet"
      description="Add a domain and run your first scan to discover subdomains, cloud assets, and your full external attack surface."
      primaryCta={{ label: "Add Domain & Scan", onClick: onAddDomain, href: onAddDomain ? undefined : "/dashboard/scans/new" }}
      secondaryCta={{ label: "Learn how it works", href: "#" }}
    />
  );
}

export function NoScansEmpty({ onNewScan }: { onNewScan?: () => void }) {
  return (
    <EmptyState
      icon={ScanLine}
      iconColor="#10B981"
      iconBg="rgba(16,185,129,0.1)"
      title="No scans yet"
      description="Run your first scan to discover subdomains, enumerate cloud assets, detect exposed secrets, and match CVEs against your tech stack."
      primaryCta={{ label: "Start First Scan", onClick: onNewScan, href: onNewScan ? undefined : "/dashboard/scans/new" }}
      secondaryCta={{ label: "View scan settings", href: "/dashboard/settings" }}
    />
  );
}

export function NoFindingsEmpty({ hasFilters = false }: { hasFilters?: boolean }) {
  if (hasFilters) {
    return (
      <EmptyState
        icon={Search}
        iconColor="#9CA3AF"
        iconBg="#1C2333"
        title="No findings match your filters"
        description="Try adjusting your severity filter, search query, or category selection to see more results."
        primaryCta={{ label: "Clear all filters", href: "/dashboard/findings" }}
      />
    );
  }
  return (
    <EmptyState
      icon={CheckCircle2}
      iconColor="#10B981"
      iconBg="rgba(16,185,129,0.1)"
      title="No findings — great news!"
      description="Your attack surface is clean. Run a scan to check for new vulnerabilities, or review previously resolved findings."
      primaryCta={{ label: "Run a Scan", href: "/dashboard/scans/new" }}
      secondaryCta={{ label: "View resolved findings", href: "/dashboard/findings?status=RESOLVED" }}
    />
  );
}

export function NoReportsEmpty({ onGenerate }: { onGenerate?: () => void }) {
  return (
    <EmptyState
      icon={FileText}
      iconColor="#F59E0B"
      iconBg="rgba(245,158,11,0.1)"
      title="No reports generated yet"
      description="Generate a professional penetration testing report from your scan data. Reports include executive summary, technical findings, remediation roadmap, and CVE appendix."
      primaryCta={{ label: "Generate First Report", onClick: onGenerate }}
      secondaryCta={{ label: "Learn about report types", href: "#" }}
    />
  );
}

export function NoNotificationsEmpty() {
  return (
    <EmptyState
      icon={Inbox}
      iconColor="#6B7280"
      iconBg="#1C2333"
      title="All caught up!"
      description="No new notifications. When new findings, scan completions, or new assets are detected, they'll appear here."
    />
  );
}

export function NoApiKeysEmpty({ onCreate }: { onCreate?: () => void }) {
  return (
    <EmptyState
      icon={Key}
      iconColor="#3B82F6"
      iconBg="rgba(59,130,246,0.1)"
      title="No API keys yet"
      description="Create an API key to integrate SentinelASM into your CI/CD pipeline, monitoring stack, or custom security tooling."
      primaryCta={{ label: "Create API Key", onClick: onCreate }}
      secondaryCta={{ label: "View API docs", href: "#" }}
    />
  );
}

export function NoTeamMembersEmpty({ onInvite }: { onInvite?: () => void }) {
  return (
    <EmptyState
      icon={Users}
      iconColor="#8B5CF6"
      iconBg="rgba(139,92,246,0.1)"
      title="Just you here"
      description="Invite your security team to collaborate on findings, assign issues, and manage the attack surface together."
      primaryCta={{ label: "Invite First Member", onClick: onInvite }}
    />
  );
}

export function NoSearchResults({ query }: { query: string }) {
  return (
    <EmptyState
      icon={Search}
      iconColor="#6B7280"
      iconBg="#1C2333"
      title={`No results for "${query}"`}
      description="Try different search terms, or check the spelling of your query."
    />
  );
}

export function NoAuditLogsEmpty() {
  return (
    <EmptyState
      icon={Shield}
      iconColor="#6B7280"
      iconBg="#1C2333"
      title="No audit log entries yet"
      description="All actions performed in your organization will be recorded here — logins, scans, finding updates, and settings changes."
    />
  );
}
