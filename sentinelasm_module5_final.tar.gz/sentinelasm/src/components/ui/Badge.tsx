import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import type { FindingSeverity } from "@/types";

const badgeVariants = cva(
  "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold tracking-wide transition-colors",
  {
    variants: {
      variant: {
        critical: "bg-[rgba(239,68,68,0.1)] text-[#EF4444]",
        high:     "bg-[rgba(245,158,11,0.1)] text-[#F59E0B]",
        medium:   "bg-[rgba(245,158,11,0.1)] text-[#F59E0B]",
        low:      "bg-[rgba(16,185,129,0.1)] text-[#10B981]",
        info:     "bg-[rgba(107,114,128,0.1)] text-[#9CA3AF]",
        accent:   "bg-[rgba(59,130,246,0.1)] text-[#3B82F6]",
        success:  "bg-[rgba(16,185,129,0.1)] text-[#10B981]",
        neutral:  "bg-[#1C2333] text-[#9CA3AF] border border-[#1F2937]",
        outline:  "border border-[#374151] text-[#9CA3AF]",
      },
    },
    defaultVariants: {
      variant: "neutral",
    },
  }
);

type BadgeVariant = NonNullable<VariantProps<typeof badgeVariants>["variant"]>;

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant;
  dot?: boolean;
}

export function Badge({ className, variant, dot, children, ...props }: BadgeProps) {
  return (
    <span className={cn(badgeVariants({ variant }), className)} {...props}>
      {dot && (
        <span
          className="h-1.5 w-1.5 rounded-full bg-current"
          aria-hidden="true"
        />
      )}
      {children}
    </span>
  );
}

// Convenience: map FindingSeverity → Badge variant
export const SEVERITY_VARIANT: Record<FindingSeverity, BadgeVariant> = {
  CRITICAL: "critical",
  HIGH:     "high",
  MEDIUM:   "medium",
  LOW:      "low",
  INFO:     "info",
};

export function SeverityBadge({
  severity,
  dot = true,
  className,
}: {
  severity: FindingSeverity;
  dot?: boolean;
  className?: string;
}) {
  return (
    <Badge variant={SEVERITY_VARIANT[severity]} dot={dot} className={className}>
      {severity}
    </Badge>
  );
}

// CVSS score pill
export function CvssPill({ score, className }: { score: number; className?: string }) {
  const variant: BadgeVariant =
    score >= 9 ? "critical" :
    score >= 7 ? "high" :
    score >= 4 ? "medium" :
    score >  0 ? "low" :
                 "neutral";

  return (
    <span
      className={cn(
        "inline-flex items-center rounded px-1.5 py-0.5 font-mono text-xs font-bold",
        badgeVariants({ variant }),
        className
      )}
    >
      {score.toFixed(1)}
    </span>
  );
}
