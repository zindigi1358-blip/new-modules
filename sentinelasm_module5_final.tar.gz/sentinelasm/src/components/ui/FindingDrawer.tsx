"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X, ExternalLink, User, Clock, Shield, AlertTriangle,
  CheckCircle2, ChevronRight, Copy, Check, FileText,
  Zap, MessageSquare, Tag,
} from "lucide-react";
import { cn, timeAgo, formatDateTime, initials, avatarColor } from "@/lib/utils";
import { SeverityBadge, CvssPill } from "@/components/ui/Badge";
import type { FindingSeverity } from "@/types";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Cve {
  cve_id:  string;
  cvss:    number;
  summary: string;
  url:     string;
  sources: string[];
  kev?:    { date_added: string; required_action: string } | null;
}

interface FindingDetail {
  id:            string;
  title:         string;
  description:   string;
  severity:      FindingSeverity;
  status:        string;
  riskScore:     number;
  cvssScore:     number | null;
  cveIds:        string[];
  isKev:         boolean;
  category:      string;
  affectedAsset: string;
  evidence:      string | null;
  remediation:   string | null;
  assignedTo:    string | null;
  firstSeenAt:   string | Date;
  lastSeenAt:    string | Date;
  resolvedAt:    string | Date | null;
  asset?: {
    subdomain:    string | null;
    ipAddress:    string | null;
    openPorts:    number[];
    technologies: string[];
  } | null;
  assignee?: {
    id:       string;
    name:     string;
    avatarUrl:string | null;
  } | null;
}

interface FindingDrawerProps {
  finding:   FindingDetail | null;
  open:      boolean;
  onClose:   () => void;
  onStatusChange?: (id: string, status: string) => void;
}

// ─── Demo CVE data ─────────────────────────────────────────────────────────────

const DEMO_CVES: Record<string, Cve[]> = {
  CVE: [
    { cve_id: "CVE-2022-21661", cvss: 9.8, summary: "WordPress WP_Query SQL injection — unauthenticated attackers can inject SQL via crafted POST requests", url: "https://nvd.nist.gov/vuln/detail/CVE-2022-21661", sources: ["NVD","OSV.dev"], kev: null },
    { cve_id: "CVE-2021-29447", cvss: 7.1, summary: "WordPress XXE via crafted WAV file in Media Library exposes server files including /etc/passwd", url: "https://nvd.nist.gov/vuln/detail/CVE-2021-29447", sources: ["NVD"], kev: null },
  ],
};

const STATUS_OPTIONS = [
  { value: "OPEN",          label: "Open",          color: "#EF4444" },
  { value: "IN_PROGRESS",   label: "In Progress",   color: "#3B82F6" },
  { value: "RESOLVED",      label: "Resolved",      color: "#10B981" },
  { value: "ACCEPTED_RISK", label: "Accepted Risk", color: "#9CA3AF" },
  { value: "FALSE_POSITIVE",label: "False Positive",color: "#6B7280" },
];

// ─── Sub-components ────────────────────────────────────────────────────────────

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };
  return (
    <button onClick={copy} className="ml-1.5 text-[#6B7280] transition-colors hover:text-[#9CA3AF]">
      {copied ? <Check className="h-3 w-3 text-[#10B981]" /> : <Copy className="h-3 w-3" />}
    </button>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.8px] text-[#6B7280]">
      {children}
    </p>
  );
}

function InfoRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-[#1F2937] py-2.5 last:border-0">
      <span className="flex-shrink-0 text-xs text-[#6B7280]">{label}</span>
      <div className="text-right text-xs text-[#F9FAFB]">{children}</div>
    </div>
  );
}

// ─── Main Drawer ──────────────────────────────────────────────────────────────

export function FindingDrawer({ finding, open, onClose, onStatusChange }: FindingDrawerProps) {
  const [activeTab,  setActiveTab]  = useState<"overview"|"evidence"|"cves"|"remediation">("overview");
  const [statusOpen, setStatusOpen] = useState(false);
  const [comment,    setComment]    = useState("");

  if (!finding) return null;

  const cves    = DEMO_CVES[finding.category] ?? [];
  const score   = finding.riskScore;
  const scoreColor =
    score >= 85 ? "#EF4444" :
    score >= 65 ? "#F59E0B" :
    score >= 40 ? "#60A5FA" : "#10B981";

  const currentStatus = STATUS_OPTIONS.find(s => s.value === finding.status) ?? STATUS_OPTIONS[0]!;

  const TABS = [
    { id: "overview",    label: "Overview"    },
    { id: "evidence",    label: "Evidence"    },
    { id: "cves",        label: `CVEs (${cves.length})` },
    { id: "remediation", label: "Remediation" },
  ] as const;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40 bg-black/50"
            onClick={onClose}
            aria-hidden
          />

          {/* Drawer */}
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
            className="fixed right-0 top-0 z-50 flex h-full w-[520px] flex-col border-l border-[#1F2937] bg-[#0D1117] shadow-2xl"
            role="dialog"
            aria-modal
            aria-label={`Finding: ${finding.title}`}
          >
            {/* Header */}
            <div className="flex-shrink-0 border-b border-[#1F2937] p-5">
              <div className="mb-3 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="mb-1.5 flex flex-wrap items-center gap-2">
                    <SeverityBadge severity={finding.severity} dot />
                    {finding.isKev && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(239,68,68,0.15)] px-2 py-0.5 text-[10px] font-bold text-[#EF4444]">
                        ☠ CISA KEV
                      </span>
                    )}
                    <span className="rounded bg-[#1C2333] px-2 py-0.5 text-[10px] font-medium text-[#9CA3AF]">
                      {finding.category}
                    </span>
                  </div>
                  <h2 className="text-sm font-bold leading-snug text-[#F9FAFB]">
                    {finding.title}
                  </h2>
                  <p className="mt-1 font-mono text-[11px] text-[#6B7280]">
                    {finding.affectedAsset}
                    <CopyButton text={finding.affectedAsset} />
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg text-[#6B7280] transition-colors hover:bg-[#1C2333] hover:text-[#F9FAFB]"
                  aria-label="Close panel"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Score + status row */}
              <div className="flex items-center gap-3">
                {/* Risk score pill */}
                <div className="flex items-center gap-2 rounded-lg border border-[#1F2937] bg-[#111827] px-3 py-2">
                  <div className="relative h-8 w-8">
                    <svg width="32" height="32" viewBox="0 0 32 32" className="-rotate-90">
                      <circle cx="16" cy="16" r="12" fill="none" stroke="#1C2333" strokeWidth="3" />
                      <circle
                        cx="16" cy="16" r="12" fill="none"
                        stroke={scoreColor} strokeWidth="3" strokeLinecap="round"
                        strokeDasharray={`${75.4 * score / 100} 75.4`}
                      />
                    </svg>
                    <span className="absolute inset-0 flex items-center justify-center font-tabular text-[10px] font-bold" style={{ color: scoreColor }}>
                      {score}
                    </span>
                  </div>
                  <div>
                    <p className="text-[10px] text-[#6B7280]">Risk Score</p>
                    <p className="text-xs font-bold" style={{ color: scoreColor }}>{score}/100</p>
                  </div>
                </div>

                {/* CVSS */}
                {finding.cvssScore != null && finding.cvssScore > 0 && (
                  <div className="flex items-center gap-1.5 rounded-lg border border-[#1F2937] bg-[#111827] px-3 py-2">
                    <Shield className="h-3.5 w-3.5 text-[#6B7280]" />
                    <div>
                      <p className="text-[10px] text-[#6B7280]">CVSS</p>
                      <CvssPill score={finding.cvssScore} />
                    </div>
                  </div>
                )}

                {/* Status dropdown */}
                <div className="relative ml-auto">
                  <button
                    onClick={() => setStatusOpen(!statusOpen)}
                    className="flex items-center gap-1.5 rounded-lg border border-[#1F2937] bg-[#111827] px-3 py-2 text-xs font-semibold transition-colors hover:border-[#374151]"
                    style={{ color: currentStatus.color }}
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-current" />
                    {currentStatus.label}
                    <ChevronRight className="h-3 w-3 rotate-90 text-[#6B7280]" />
                  </button>
                  <AnimatePresence>
                    {statusOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: -4, scale: 0.97 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -4, scale: 0.97 }}
                        transition={{ duration: 0.1 }}
                        className="absolute right-0 top-full z-10 mt-1 w-44 overflow-hidden rounded-lg border border-[#374151] bg-[#1C2333] shadow-xl"
                      >
                        {STATUS_OPTIONS.map(opt => (
                          <button
                            key={opt.value}
                            onClick={() => {
                              onStatusChange?.(finding.id, opt.value);
                              setStatusOpen(false);
                            }}
                            className={cn(
                              "flex w-full items-center gap-2 px-3 py-2 text-left text-xs font-medium transition-colors hover:bg-[#374151]",
                              finding.status === opt.value ? "bg-[#374151]" : ""
                            )}
                            style={{ color: opt.color }}
                          >
                            <span className="h-1.5 w-1.5 rounded-full bg-current" />
                            {opt.label}
                            {finding.status === opt.value && <Check className="ml-auto h-3 w-3" />}
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex flex-shrink-0 border-b border-[#1F2937] px-5">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "border-b-2 px-3 pb-3 pt-3 text-xs font-medium transition-colors",
                    activeTab === tab.id
                      ? "border-[#3B82F6] text-[#3B82F6]"
                      : "border-transparent text-[#6B7280] hover:text-[#9CA3AF]"
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="flex-1 overflow-y-auto p-5">

              {/* ── OVERVIEW ── */}
              {activeTab === "overview" && (
                <div className="space-y-5">
                  {/* Description */}
                  <div>
                    <SectionLabel>Description</SectionLabel>
                    <p className="text-sm leading-relaxed text-[#D1D5DB]">
                      {finding.description || "No description available."}
                    </p>
                  </div>

                  {/* Metadata */}
                  <div className="rounded-lg border border-[#1F2937] bg-[#111827]">
                    <div className="px-4">
                      <InfoRow label="First Seen">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3 text-[#6B7280]" />
                          {formatDateTime(finding.firstSeenAt)}
                        </span>
                      </InfoRow>
                      <InfoRow label="Last Seen">
                        {timeAgo(finding.lastSeenAt)}
                      </InfoRow>
                      {finding.resolvedAt && (
                        <InfoRow label="Resolved At">
                          <span className="text-[#10B981]">{formatDateTime(finding.resolvedAt)}</span>
                        </InfoRow>
                      )}
                      <InfoRow label="Category">
                        <span className="rounded bg-[#1C2333] px-2 py-0.5 text-[11px] text-[#9CA3AF]">
                          {finding.category}
                        </span>
                      </InfoRow>
                      {finding.cvssScore != null && (
                        <InfoRow label="CVSS Score">
                          <CvssPill score={finding.cvssScore} />
                        </InfoRow>
                      )}
                      <InfoRow label="KEV Status">
                        {finding.isKev ? (
                          <span className="text-[#EF4444] font-semibold">☠ Actively Exploited</span>
                        ) : (
                          <span className="text-[#6B7280]">Not in KEV catalog</span>
                        )}
                      </InfoRow>
                    </div>
                  </div>

                  {/* Assigned to */}
                  <div>
                    <SectionLabel>Assigned To</SectionLabel>
                    {finding.assignee ? (
                      <div className="flex items-center gap-2">
                        <div className={cn("flex h-6 w-6 items-center justify-center rounded-full bg-gradient-to-br text-[10px] font-bold text-white", avatarColor(finding.assignee.id))}>
                          {initials(finding.assignee.name)}
                        </div>
                        <span className="text-sm text-[#F9FAFB]">{finding.assignee.name}</span>
                      </div>
                    ) : (
                      <button className="flex items-center gap-1.5 text-xs text-[#3B82F6] hover:text-[#60A5FA]">
                        <User className="h-3.5 w-3.5" /> Assign to someone
                      </button>
                    )}
                  </div>

                  {/* Affected asset details */}
                  {finding.asset && (
                    <div>
                      <SectionLabel>Affected Asset</SectionLabel>
                      <div className="rounded-lg border border-[#1F2937] bg-[#111827] px-4">
                        {finding.asset.subdomain && (
                          <InfoRow label="Subdomain">
                            <span className="font-mono text-[11px]">{finding.asset.subdomain}</span>
                          </InfoRow>
                        )}
                        {finding.asset.ipAddress && (
                          <InfoRow label="IP Address">
                            <span className="font-mono text-[11px]">{finding.asset.ipAddress}</span>
                          </InfoRow>
                        )}
                        {finding.asset.openPorts.length > 0 && (
                          <InfoRow label="Open Ports">
                            <span className="font-mono text-[11px]">{finding.asset.openPorts.join(", ")}</span>
                          </InfoRow>
                        )}
                        {finding.asset.technologies.length > 0 && (
                          <InfoRow label="Technologies">
                            <div className="flex flex-wrap justify-end gap-1">
                              {finding.asset.technologies.slice(0,4).map(t => (
                                <span key={t} className="rounded bg-[#1C2333] px-1.5 py-0.5 text-[10px] text-[#9CA3AF]">{t}</span>
                              ))}
                            </div>
                          </InfoRow>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ── EVIDENCE ── */}
              {activeTab === "evidence" && (
                <div className="space-y-4">
                  <div>
                    <SectionLabel>Evidence</SectionLabel>
                    {finding.evidence ? (
                      <div className="rounded-lg border border-[#1F2937] bg-[#080B12] p-4 font-mono text-xs leading-relaxed text-[#10B981]">
                        {finding.evidence}
                      </div>
                    ) : (
                      <p className="text-sm text-[#6B7280]">No evidence recorded for this finding.</p>
                    )}
                  </div>

                  {/* Proof of concept note */}
                  <div className="rounded-lg border border-[rgba(245,158,11,0.2)] bg-[rgba(245,158,11,0.05)] p-4">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#F59E0B]" />
                      <div>
                        <p className="text-xs font-semibold text-[#F59E0B]">Responsible Disclosure</p>
                        <p className="mt-1 text-xs leading-relaxed text-[#9CA3AF]">
                          This evidence was collected via automated scanning with authorization.
                          Do not use this information to exploit systems beyond the authorized scope.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* HTTP request/response mock for web findings */}
                  {finding.category === "Exposure" && (
                    <div>
                      <SectionLabel>HTTP Response Sample</SectionLabel>
                      <div className="rounded-lg border border-[#1F2937] bg-[#080B12] p-4 font-mono text-xs leading-loose text-[#9CA3AF]">
                        <span className="text-[#10B981]">GET</span>{" "}
                        <span className="text-[#60A5FA]">/{finding.affectedAsset.split("/").slice(1).join("/")}</span>{" "}
                        <span className="text-[#9CA3AF]">HTTP/1.1</span><br />
                        <span className="text-[#9CA3AF]">Host: {finding.affectedAsset.split("/")[0]}</span><br /><br />
                        <span className="text-[#10B981]">HTTP/1.1 200 OK</span><br />
                        <span className="text-[#9CA3AF]">Content-Type: text/plain; charset=utf-8</span><br />
                        <span className="text-[#9CA3AF]">Content-Length: 312</span><br /><br />
                        <span className="text-[#EF4444]">[sensitive content redacted]</span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* ── CVEs ── */}
              {activeTab === "cves" && (
                <div className="space-y-3">
                  {cves.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <Shield className="mb-3 h-10 w-10 text-[#374151]" />
                      <p className="text-sm font-medium text-[#6B7280]">No CVEs matched</p>
                      <p className="mt-1 text-xs text-[#4B5563]">
                        This finding is based on exposure context, not a specific CVE.
                      </p>
                    </div>
                  ) : (
                    cves.map(cve => (
                      <div key={cve.cve_id} className="rounded-lg border border-[#1F2937] bg-[#111827] p-4">
                        <div className="mb-2 flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <a
                              href={cve.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="font-mono text-sm font-bold text-[#3B82F6] hover:text-[#60A5FA]"
                            >
                              {cve.cve_id}
                            </a>
                            <ExternalLink className="h-3 w-3 text-[#6B7280]" />
                            {cve.kev && (
                              <span className="rounded-full bg-[rgba(239,68,68,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#EF4444]">
                                ☠ KEV
                              </span>
                            )}
                          </div>
                          <CvssPill score={cve.cvss} />
                        </div>
                        <p className="text-xs leading-relaxed text-[#9CA3AF]">{cve.summary}</p>
                        <div className="mt-2 flex flex-wrap gap-1">
                          {cve.sources.map(s => (
                            <span key={s} className="rounded bg-[#1C2333] px-1.5 py-0.5 text-[10px] text-[#6B7280]">{s}</span>
                          ))}
                        </div>
                        {cve.kev && (
                          <div className="mt-2 rounded-lg bg-[rgba(239,68,68,0.06)] p-2.5">
                            <p className="text-[11px] text-[#EF4444]">
                              <strong>Required Action:</strong> {cve.kev.required_action}
                            </p>
                            <p className="mt-0.5 text-[10px] text-[#6B7280]">Added to KEV: {cve.kev.date_added}</p>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* ── REMEDIATION ── */}
              {activeTab === "remediation" && (
                <div className="space-y-4">
                  {finding.remediation ? (
                    <>
                      <div>
                        <SectionLabel>Remediation Steps</SectionLabel>
                        <div className="space-y-2">
                          {finding.remediation.split(". ").filter(Boolean).map((step, i) => (
                            <div key={i} className="flex items-start gap-3 rounded-lg border border-[#1F2937] bg-[#111827] p-3">
                              <span className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full bg-[rgba(59,130,246,0.1)] text-[10px] font-bold text-[#3B82F6]">
                                {i + 1}
                              </span>
                              <p className="text-xs leading-relaxed text-[#D1D5DB]">{step}.</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="rounded-lg border border-[rgba(16,185,129,0.2)] bg-[rgba(16,185,129,0.04)] p-4">
                        <div className="flex items-start gap-2">
                          <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#10B981]" />
                          <div>
                            <p className="text-xs font-semibold text-[#10B981]">After remediation</p>
                            <p className="mt-1 text-xs text-[#9CA3AF]">
                              Run a fresh scan to confirm the issue is resolved, then mark this finding as "Resolved".
                            </p>
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <p className="text-sm text-[#6B7280]">No remediation guidance recorded.</p>
                  )}
                </div>
              )}
            </div>

            {/* Footer — comment box */}
            <div className="flex-shrink-0 border-t border-[#1F2937] p-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={comment}
                  onChange={e => setComment(e.target.value)}
                  placeholder="Add a note or comment…"
                  className="flex-1 rounded-lg border border-[#1F2937] bg-[#111827] px-3 py-2 text-xs text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6]"
                  onKeyDown={e => { if (e.key === "Enter" && comment.trim()) setComment(""); }}
                />
                <button
                  onClick={() => setComment("")}
                  disabled={!comment.trim()}
                  className="flex h-8 items-center gap-1 rounded-lg bg-[#3B82F6] px-3 text-xs font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-40"
                >
                  <MessageSquare className="h-3.5 w-3.5" /> Post
                </button>
              </div>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
