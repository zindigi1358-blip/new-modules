"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronDown, Plus } from "lucide-react";
import { cn, initials } from "@/lib/utils";
import { toast } from "sonner";

interface OrgOption {
  id:   string;
  name: string;
  slug: string;
  plan: string;
  role: string;
}

interface OrgSwitcherProps {
  currentOrgId:   string;
  currentOrgName: string;
  currentPlan:    string;
  collapsed?:     boolean;
}

export function OrgSwitcher({
  currentOrgId,
  currentOrgName,
  currentPlan,
  collapsed = false,
}: OrgSwitcherProps) {
  const router        = useRouter();
  const [open, setOpen]       = useState(false);
  const [orgs, setOrgs]       = useState<OrgOption[]>([]);
  const [loading, setLoading] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  // Fetch orgs when dropdown opens
  useEffect(() => {
    if (!open || orgs.length > 0) return;
    setLoading(true);
    fetch("/api/organizations")
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data?.data) setOrgs(data.data);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [open, orgs.length]);

  const switchOrg = async (orgId: string, orgSlug: string) => {
    if (orgId === currentOrgId) { setOpen(false); return; }
    try {
      const res = await fetch("/api/organizations/switch", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ organizationId: orgId }),
      });
      if (!res.ok) { toast.error("Failed to switch organization"); return; }
      setOpen(false);
      router.push("/dashboard");
      router.refresh();
    } catch {
      toast.error("Network error");
    }
  };

  const planColors: Record<string, string> = {
    STARTER:      "#9CA3AF",
    PROFESSIONAL: "#3B82F6",
    BUSINESS:     "#8B5CF6",
    ENTERPRISE:   "#10B981",
  };

  return (
    <div ref={ref} className="relative p-2.5">
      <button
        onClick={() => setOpen(!open)}
        className={cn(
          "flex w-full items-center gap-2.5 rounded-lg border border-[#1F2937]",
          "bg-[#1C2333] p-2 text-left transition-colors hover:border-[#374151]",
          collapsed && "justify-center"
        )}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Switch organization"
      >
        <div
          className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-[4px] text-xs font-bold text-white"
          style={{ background: "linear-gradient(135deg,#667eea,#764ba2)" }}
        >
          {initials(currentOrgName)}
        </div>

        {!collapsed && (
          <>
            <div className="flex min-w-0 flex-1 flex-col">
              <span className="truncate text-xs font-semibold text-[#F9FAFB]">
                {currentOrgName}
              </span>
              <span
                className="text-[10px] font-semibold uppercase tracking-wider"
                style={{ color: planColors[currentPlan] ?? "#9CA3AF" }}
              >
                {currentPlan}
              </span>
            </div>
            <ChevronDown
              className={cn(
                "h-3.5 w-3.5 flex-shrink-0 text-[#6B7280] transition-transform",
                open && "rotate-180"
              )}
            />
          </>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.97 }}
            animate={{ opacity: 1, y: 0,  scale: 1    }}
            exit={{   opacity: 0, y: -6, scale: 0.97 }}
            transition={{ duration: 0.12 }}
            className="absolute left-2.5 right-2.5 top-full z-50 mt-1 overflow-hidden rounded-xl border border-[#374151] bg-[#1C2333] shadow-2xl"
            role="listbox"
            aria-label="Organizations"
          >
            {/* Orgs list */}
            <div className="max-h-56 overflow-y-auto py-1">
              {loading ? (
                <div className="px-4 py-3 text-center text-xs text-[#6B7280]">Loading…</div>
              ) : orgs.length === 0 ? (
                /* Fallback: show current org */
                <OrgRow
                  name={currentOrgName}
                  plan={currentPlan}
                  role="OWNER"
                  active
                  onClick={() => setOpen(false)}
                  planColors={planColors}
                />
              ) : (
                orgs.map(org => (
                  <OrgRow
                    key={org.id}
                    name={org.name}
                    plan={org.plan}
                    role={org.role}
                    active={org.id === currentOrgId}
                    onClick={() => switchOrg(org.id, org.slug)}
                    planColors={planColors}
                  />
                ))
              )}
            </div>

            {/* Create new org */}
            <div className="border-t border-[#1F2937] p-1">
              <button
                onClick={() => { setOpen(false); router.push("/new-organization"); }}
                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-medium text-[#6B7280] transition-colors hover:bg-[#374151] hover:text-[#F9FAFB]"
              >
                <Plus className="h-3.5 w-3.5" />
                Create new organization
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function OrgRow({
  name, plan, role, active, onClick, planColors,
}: {
  name: string; plan: string; role: string;
  active: boolean; onClick: () => void;
  planColors: Record<string, string>;
}) {
  return (
    <button
      onClick={onClick}
      role="option"
      aria-selected={active}
      className={cn(
        "flex w-full items-center gap-2.5 px-3 py-2.5 text-left transition-colors",
        active ? "bg-[rgba(59,130,246,0.08)]" : "hover:bg-[#374151]"
      )}
    >
      <div
        className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded text-[10px] font-bold text-white"
        style={{ background: "linear-gradient(135deg,#667eea,#764ba2)" }}
      >
        {initials(name)}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-semibold text-[#F9FAFB]">{name}</p>
        <p
          className="text-[10px] font-medium uppercase tracking-wider"
          style={{ color: planColors[plan] ?? "#9CA3AF" }}
        >
          {plan} · {role}
        </p>
      </div>
      {active && <Check className="h-3.5 w-3.5 flex-shrink-0 text-[#3B82F6]" />}
    </button>
  );
}
