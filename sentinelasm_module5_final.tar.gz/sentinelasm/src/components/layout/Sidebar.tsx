"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Globe, ScanLine, AlertTriangle, FileText,
  Bell, Key, Users, CreditCard, Settings, ChevronLeft,
  Shield, LogOut, ChevronDown, HelpCircle, Building2,
} from "lucide-react";
import { cn, initials, avatarColor } from "@/lib/utils";
import type { SessionPayload } from "@/lib/auth";
import type { MemberRole } from "@/types";

// ─── Nav structure ────────────────────────────────────────────────────────────

interface NavItem {
  label:     string;
  href:      string;
  icon:      React.ElementType;
  badge?:    number | string;
  badgeType?: "error" | "info" | "success";
  roles?:    MemberRole[];
}

interface NavSection {
  label: string;
  items: NavItem[];
}

const NAV_SECTIONS: NavSection[] = [
  {
    label: "Overview",
    items: [
      { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    ],
  },
  {
    label: "Attack Surface",
    items: [
      { label: "Assets",   href: "/dashboard/assets",   icon: Globe,          badge: 847, badgeType: "info" },
      { label: "Scans",    href: "/dashboard/scans",    icon: ScanLine,       badge: 3,   badgeType: "success" },
      { label: "Findings", href: "/dashboard/findings", icon: AlertTriangle,  badge: 23,  badgeType: "error" },
      { label: "Reports",  href: "/dashboard/reports",  icon: FileText },
    ],
  },
  {
    label: "Configure",
    items: [
      { label: "Notifications", href: "/dashboard/notifications", icon: Bell },
      { label: "API Keys",      href: "/dashboard/api-keys",      icon: Key,
        roles: ["OWNER", "ADMIN"] as MemberRole[] },
    ],
  },
  {
    label: "Workspace",
    items: [
      { label: "Team",     href: "/dashboard/team",     icon: Users,
        roles: ["OWNER", "ADMIN"] as MemberRole[] },
      { label: "Billing",  href: "/dashboard/billing",  icon: CreditCard,
        roles: ["OWNER"] as MemberRole[] },
      { label: "Settings", href: "/dashboard/settings", icon: Settings },
    ],
  },
];

// ─── Props ────────────────────────────────────────────────────────────────────

interface SidebarProps {
  session: SessionPayload;
  orgName: string;
  orgPlan: string;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function Sidebar({ session, orgName, orgPlan }: SidebarProps) {
  const pathname             = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [orgMenuOpen, setOrgMenuOpen] = useState(false);

  const userInitials = initials(session.name);
  const avatarGradient = avatarColor(session.userId);

  const hasAccess = (roles?: MemberRole[]) => {
    if (!roles || roles.length === 0) return true;
    return roles.includes(session.role);
  };

  return (
    <motion.aside
      animate={{ width: collapsed ? 64 : 240 }}
      transition={{ duration: 0.2, ease: "easeInOut" }}
      className="relative flex h-full flex-shrink-0 flex-col border-r border-[#1F2937] bg-[#0D1117]"
      role="navigation"
      aria-label="Main navigation"
    >
      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className={cn(
          "absolute -right-3 top-[calc(var(--topbar-h)+20px)] z-30",
          "flex h-6 w-6 items-center justify-center rounded-full",
          "border border-[#1F2937] bg-[#1C2333] text-[#6B7280]",
          "transition-colors hover:border-[#3B82F6] hover:bg-[#3B82F6] hover:text-white",
          "focus-visible:outline-2 focus-visible:outline-[#3B82F6]"
        )}
        aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        aria-expanded={!collapsed}
      >
        <ChevronLeft
          className={cn("h-3 w-3 transition-transform duration-200", collapsed && "rotate-180")}
        />
      </button>

      {/* Logo */}
      <div className="flex h-[56px] flex-shrink-0 items-center gap-2.5 border-b border-[#1F2937] px-4">
        <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-[4px] bg-[#3B82F6]">
          <Shield className="h-4 w-4 text-white" aria-hidden />
        </div>
        <AnimatePresence>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              className="overflow-hidden whitespace-nowrap text-[15px] font-bold tracking-tight text-[#F9FAFB]"
            >
              Sentinel<span className="text-[#3B82F6]">ASM</span>
            </motion.span>
          )}
        </AnimatePresence>
      </div>

      {/* Org switcher */}
      <div className="flex-shrink-0 border-b border-[#1F2937] p-2.5">
        <button
          onClick={() => setOrgMenuOpen(!orgMenuOpen)}
          className={cn(
            "flex w-full items-center gap-2.5 rounded-lg border border-[#1F2937]",
            "bg-[#1C2333] p-2 text-left transition-colors hover:border-[#374151]",
            collapsed && "justify-center"
          )}
          aria-haspopup="true"
          aria-expanded={orgMenuOpen}
        >
          <div
            className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-[4px] text-xs font-bold text-white"
            style={{ background: "linear-gradient(135deg, #667eea, #764ba2)" }}
          >
            {initials(orgName)}
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex min-w-0 flex-1 flex-col"
              >
                <span className="truncate text-xs font-semibold text-[#F9FAFB]">{orgName}</span>
                <span className="text-[10px] font-medium uppercase tracking-wider text-[#6B7280]">
                  {orgPlan}
                </span>
              </motion.div>
            )}
          </AnimatePresence>
          {!collapsed && (
            <ChevronDown
              className={cn(
                "h-3.5 w-3.5 flex-shrink-0 text-[#6B7280] transition-transform",
                orgMenuOpen && "rotate-180"
              )}
            />
          )}
        </button>
      </div>

      {/* Nav items */}
      <nav className="flex flex-1 flex-col gap-px overflow-y-auto px-2.5 py-2" aria-label="Navigation sections">
        {NAV_SECTIONS.map((section) => {
          const visibleItems = section.items.filter((item) => hasAccess(item.roles));
          if (visibleItems.length === 0) return null;

          return (
            <div key={section.label} className="mb-1">
              {!collapsed && (
                <p className="mb-1 px-2 pt-2 text-[10px] font-semibold uppercase tracking-[0.7px] text-[#6B7280]">
                  {section.label}
                </p>
              )}
              {visibleItems.map((item) => {
                const isActive =
                  item.href === "/dashboard"
                    ? pathname === "/dashboard"
                    : pathname.startsWith(item.href);

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-2.5 rounded-md px-2.5 py-2 text-sm font-medium",
                      "transition-colors focus-visible:outline-2 focus-visible:outline-[#3B82F6]",
                      isActive
                        ? "bg-[rgba(59,130,246,0.08)] text-[#3B82F6]"
                        : "text-[#9CA3AF] hover:bg-[#1C2333] hover:text-[#F9FAFB]",
                      collapsed && "justify-center px-2"
                    )}
                    aria-current={isActive ? "page" : undefined}
                    title={collapsed ? item.label : undefined}
                  >
                    <item.icon className="h-[18px] w-[18px] flex-shrink-0" aria-hidden />
                    <AnimatePresence>
                      {!collapsed && (
                        <motion.span
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex-1 truncate"
                        >
                          {item.label}
                        </motion.span>
                      )}
                    </AnimatePresence>
                    {!collapsed && item.badge !== undefined && (
                      <span
                        className={cn(
                          "flex-shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold",
                          item.badgeType === "error"   && "bg-[#EF4444] text-white",
                          item.badgeType === "info"    && "bg-[#3B82F6] text-white",
                          item.badgeType === "success" && "bg-[#10B981] text-white",
                          !item.badgeType              && "bg-[#374151] text-[#9CA3AF]"
                        )}
                      >
                        {item.badge}
                      </span>
                    )}
                  </Link>
                );
              })}
            </div>
          );
        })}
      </nav>

      {/* Footer - user profile */}
      <div className="flex-shrink-0 border-t border-[#1F2937] p-2.5">
        <div
          className={cn(
            "flex cursor-pointer items-center gap-2.5 rounded-lg p-2",
            "transition-colors hover:bg-[#1C2333]",
            collapsed && "justify-center"
          )}
          role="button"
          tabIndex={0}
          aria-label="User profile menu"
        >
          <div
            className={cn(
              "flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full",
              "bg-gradient-to-br text-xs font-bold text-white",
              avatarGradient
            )}
            aria-hidden
          >
            {userInitials}
          </div>
          <AnimatePresence>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex min-w-0 flex-1 flex-col"
              >
                <span className="truncate text-xs font-semibold text-[#F9FAFB]">
                  {session.name}
                </span>
                <span className="text-[10px] font-medium capitalize text-[#6B7280]">
                  {session.role.toLowerCase()}
                </span>
              </motion.div>
            )}
          </AnimatePresence>
          {!collapsed && (
            <LogOut className="h-3.5 w-3.5 flex-shrink-0 text-[#6B7280]" />
          )}
        </div>
      </div>
    </motion.aside>
  );
}
