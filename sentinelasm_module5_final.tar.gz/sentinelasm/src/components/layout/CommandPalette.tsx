"use client";

import { useEffect, useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, LayoutDashboard, Globe, ScanLine, AlertTriangle,
  FileText, Bell, Key, Users, CreditCard, Settings,
  Plus, Download, Command,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ─── Command definition ───────────────────────────────────────────────────────

interface Cmd {
  id:       string;
  label:    string;
  section:  string;
  icon:     React.ElementType;
  href?:    string;
  action?:  () => void;
  kbd?:     string;
}

const COMMANDS: Cmd[] = [
  // Navigation
  { id: "nav-dashboard",      label: "Go to Dashboard",    section: "Navigation", icon: LayoutDashboard,  href: "/dashboard",                   kbd: "D" },
  { id: "nav-assets",         label: "Assets",             section: "Navigation", icon: Globe,            href: "/dashboard/assets" },
  { id: "nav-scans",          label: "Scans",              section: "Navigation", icon: ScanLine,         href: "/dashboard/scans" },
  { id: "nav-findings",       label: "Findings",           section: "Navigation", icon: AlertTriangle,    href: "/dashboard/findings",           kbd: "F" },
  { id: "nav-reports",        label: "Reports",            section: "Navigation", icon: FileText,         href: "/dashboard/reports" },
  { id: "nav-notifications",  label: "Notifications",      section: "Navigation", icon: Bell,             href: "/dashboard/notifications" },
  { id: "nav-api-keys",       label: "API Keys",           section: "Navigation", icon: Key,              href: "/dashboard/api-keys" },
  { id: "nav-team",           label: "Team",               section: "Navigation", icon: Users,            href: "/dashboard/team" },
  { id: "nav-billing",        label: "Billing",            section: "Navigation", icon: CreditCard,       href: "/dashboard/billing" },
  { id: "nav-settings",       label: "Settings",           section: "Navigation", icon: Settings,         href: "/dashboard/settings",           kbd: "⌘," },
  // Actions
  { id: "act-new-scan",       label: "New Scan",           section: "Actions",    icon: Plus,             href: "/dashboard/scans/new",          kbd: "⌘N" },
  { id: "act-gen-report",     label: "Generate PDF Report",section: "Actions",    icon: Download,         href: "/dashboard/reports/generate" },
  { id: "act-invite",         label: "Invite Team Member", section: "Actions",    icon: Users,            href: "/dashboard/team?invite=true" },
];

// ─── Props ────────────────────────────────────────────────────────────────────

interface CommandPaletteProps {
  open:    boolean;
  onClose: () => void;
}

// ─── Component ────────────────────────────────────────────────────────────────

export function CommandPalette({ open, onClose }: CommandPaletteProps) {
  const router                      = useRouter();
  const [query, setQuery]           = useState("");
  const [selectedIndex, setSelected] = useState(0);

  const filtered = query
    ? COMMANDS.filter((c) => c.label.toLowerCase().includes(query.toLowerCase()))
    : COMMANDS;

  const sections = [...new Set(filtered.map((c) => c.section))];

  const execute = useCallback(
    (cmd: Cmd) => {
      if (cmd.href)   router.push(cmd.href);
      if (cmd.action) cmd.action();
      onClose();
      setQuery("");
      setSelected(0);
    },
    [router, onClose]
  );

  // Keyboard shortcut to open
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        if (!open) {
          // trigger parent open — already handled in Topbar
        }
      }
      if (!open) return;
      if (e.key === "Escape") { onClose(); setQuery(""); }
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelected((i) => Math.min(i + 1, filtered.length - 1));
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelected((i) => Math.max(i - 1, 0));
      }
      if (e.key === "Enter") {
        const cmd = filtered[selectedIndex];
        if (cmd) execute(cmd);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, filtered, selectedIndex, execute, onClose]);

  // Reset selection when filter changes
  useEffect(() => { setSelected(0); }, [query]);

  // Global index for keyboard nav across sections
  let globalIndex = 0;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm"
            onClick={onClose}
            aria-hidden
          />

          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -8 }}
            animate={{ opacity: 1, scale: 1,    y: 0 }}
            exit={{ opacity: 0, scale: 0.96,    y: -8 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="fixed left-1/2 top-[15vh] z-50 w-[560px] -translate-x-1/2"
            role="dialog"
            aria-modal
            aria-label="Command palette"
          >
            <div className="overflow-hidden rounded-xl border border-[#374151] bg-[#1C2333] shadow-[0_20px_60px_rgba(0,0,0,0.6)]">
              {/* Search input */}
              <div className="flex items-center gap-3 border-b border-[#1F2937] px-4 py-3.5">
                <Search className="h-4 w-4 flex-shrink-0 text-[#6B7280]" aria-hidden />
                <input
                  autoFocus
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search or run a command…"
                  className="flex-1 bg-transparent text-sm text-[#F9FAFB] placeholder-[#6B7280] outline-none"
                  aria-label="Command search"
                  role="combobox"
                  aria-expanded="true"
                  aria-autocomplete="list"
                />
                <kbd className="rounded border border-[#374151] bg-[#111827] px-1.5 py-0.5 font-mono text-[10px] text-[#6B7280]">
                  ESC
                </kbd>
              </div>

              {/* Results */}
              <div
                className="max-h-[360px] overflow-y-auto p-2"
                role="listbox"
                aria-label="Command suggestions"
              >
                {filtered.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10 text-[#6B7280]">
                    <Command className="mb-2 h-8 w-8" aria-hidden />
                    <p className="text-sm">No commands found for "{query}"</p>
                  </div>
                ) : (
                  sections.map((section) => {
                    const sectionItems = filtered.filter((c) => c.section === section);
                    return (
                      <div key={section} className="mb-1">
                        <p className="mb-1 px-2 pt-2 text-[10px] font-semibold uppercase tracking-[0.7px] text-[#6B7280]">
                          {section}
                        </p>
                        {sectionItems.map((cmd) => {
                          const idx = globalIndex++;
                          const isSelected = idx === selectedIndex;
                          return (
                            <button
                              key={cmd.id}
                              onClick={() => execute(cmd)}
                              onMouseEnter={() => setSelected(idx)}
                              className={cn(
                                "flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left",
                                "transition-colors focus:outline-none",
                                isSelected
                                  ? "bg-[rgba(59,130,246,0.12)] text-[#3B82F6]"
                                  : "text-[#D1D5DB] hover:bg-[rgba(59,130,246,0.08)] hover:text-[#3B82F6]"
                              )}
                              role="option"
                              aria-selected={isSelected}
                            >
                              <div
                                className={cn(
                                  "flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md",
                                  isSelected
                                    ? "bg-[rgba(59,130,246,0.2)] text-[#3B82F6]"
                                    : "bg-[#111827] text-[#6B7280]"
                                )}
                              >
                                <cmd.icon className="h-4 w-4" aria-hidden />
                              </div>
                              <span className="flex-1 text-sm font-medium">{cmd.label}</span>
                              {cmd.kbd && (
                                <kbd className="rounded border border-[#374151] bg-[#111827] px-1.5 py-0.5 font-mono text-[10px] text-[#6B7280]">
                                  {cmd.kbd}
                                </kbd>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Footer hints */}
              <div className="flex items-center gap-4 border-t border-[#1F2937] px-4 py-2.5">
                {[
                  { keys: "↑↓", label: "navigate" },
                  { keys: "↵",  label: "select" },
                  { keys: "ESC", label: "close" },
                ].map(({ keys, label }) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <kbd className="rounded border border-[#374151] bg-[#111827] px-1 py-0.5 font-mono text-[10px] text-[#6B7280]">
                      {keys}
                    </kbd>
                    <span className="text-[11px] text-[#6B7280]">{label}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
