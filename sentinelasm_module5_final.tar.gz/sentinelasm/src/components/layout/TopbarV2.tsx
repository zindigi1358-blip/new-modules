"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Bell, Search, Plus, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { CommandPalette } from "@/components/layout/CommandPalette";
import { NotificationPanel } from "@/components/layout/NotificationPanel";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { useState } from "react";

const ROUTE_LABELS: Record<string, string> = {
  "/dashboard":               "Dashboard",
  "/dashboard/assets":        "Assets",
  "/dashboard/scans":         "Scans",
  "/dashboard/scans/new":     "New Scan",
  "/dashboard/findings":      "Findings",
  "/dashboard/reports":       "Reports",
  "/dashboard/reports/generate": "Generate Report",
  "/dashboard/notifications": "Notifications",
  "/dashboard/api-keys":      "API Keys",
  "/dashboard/team":          "Team",
  "/dashboard/billing":       "Billing",
  "/dashboard/settings":      "Settings",
};

function useBreadcrumbs() {
  const pathname = usePathname();
  const segments = pathname.split("/").filter(Boolean);
  const crumbs: { label: string; href: string }[] = [];
  let path = "";
  for (const segment of segments) {
    path += `/${segment}`;
    const label = ROUTE_LABELS[path];
    if (label) crumbs.push({ label, href: path });
  }
  return crumbs;
}

interface TopbarProps {
  orgName:      string;
  unreadCount?: number;
}

export function Topbar({ orgName, unreadCount = 0 }: TopbarProps) {
  const crumbs                    = useBreadcrumbs();
  const [cmdOpen,   setCmdOpen]   = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  return (
    <>
      <header
        className="flex h-[56px] flex-shrink-0 items-center gap-3 border-b border-[var(--border)] bg-[var(--bg-surface)] px-5"
        role="banner"
      >
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="flex min-w-0 flex-1 items-center gap-1.5">
          <span className="text-sm text-[var(--text-muted)]">{orgName}</span>
          {crumbs.map((crumb, i) => (
            <span key={crumb.href} className="flex items-center gap-1.5">
              <ChevronRight className="h-3.5 w-3.5 text-[var(--border-light)]" aria-hidden />
              {i === crumbs.length - 1 ? (
                <span
                  className="text-sm font-medium text-[var(--text-primary)]"
                  aria-current="page"
                >
                  {crumb.label}
                </span>
              ) : (
                <Link
                  href={crumb.href}
                  className="text-sm text-[var(--text-muted)] transition-colors hover:text-[var(--text-primary)]"
                >
                  {crumb.label}
                </Link>
              )}
            </span>
          ))}
        </nav>

        {/* Search */}
        <button
          onClick={() => setCmdOpen(true)}
          className={cn(
            "flex h-8 w-56 items-center gap-2 rounded-lg",
            "border border-[var(--border)] bg-[var(--bg-card)] px-3",
            "text-sm text-[var(--text-muted)] transition-all",
            "hover:border-[var(--border-light)] hover:text-[var(--text-secondary)]",
            "focus-visible:border-[#3B82F6] focus-visible:outline-none"
          )}
          aria-label="Open search (⌘K)"
        >
          <Search className="h-3.5 w-3.5 flex-shrink-0" aria-hidden />
          <span className="flex-1 text-left">Search assets, findings…</span>
          <kbd className="rounded border border-[var(--border)] bg-[var(--bg-elevated)] px-1 py-0.5 font-mono text-[10px] text-[var(--text-muted)]">
            ⌘K
          </kbd>
        </button>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <Link
            href="/dashboard/scans/new"
            className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] focus-visible:outline-2 focus-visible:outline-[#3B82F6]"
          >
            <Plus className="h-3.5 w-3.5" aria-hidden />
            New Scan
          </Link>

          <div className="mx-1 h-5 w-px bg-[var(--border)]" aria-hidden />

          {/* Theme toggle */}
          <ThemeToggle />

          {/* Notifications */}
          <button
            onClick={() => setNotifOpen(true)}
            className={cn(
              "relative flex h-8 w-8 items-center justify-center rounded-lg",
              "text-[var(--text-secondary)] transition-colors",
              "hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]",
              "focus-visible:outline-2 focus-visible:outline-[#3B82F6]"
            )}
            aria-label={`Notifications${unreadCount > 0 ? ` (${unreadCount} unread)` : ""}`}
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span
                className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full border-2 border-[var(--bg-surface)] bg-[#EF4444]"
                aria-hidden
              />
            )}
          </button>
        </div>
      </header>

      <CommandPalette open={cmdOpen}   onClose={() => setCmdOpen(false)} />
      <NotificationPanel open={notifOpen} onClose={() => setNotifOpen(false)} />
    </>
  );
}
