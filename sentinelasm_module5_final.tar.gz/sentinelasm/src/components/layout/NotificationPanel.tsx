"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X, Bell, CheckCheck } from "lucide-react";
import Link from "next/link";
import { cn, timeAgo } from "@/lib/utils";
import { SeverityBadge } from "@/components/ui/Badge";
import type { FindingSeverity } from "@/types";

interface NotificationItem {
  id:        string;
  title:     string;
  body:      string;
  severity:  FindingSeverity;
  isRead:    boolean;
  linkTo?:   string;
  createdAt: string;
}

// Demo data — in production this comes from /api/notifications
const DEMO_NOTIFICATIONS: NotificationItem[] = [
  {
    id:        "n1",
    title:     "AWS Access Key Leaked — GitHub",
    body:      "AWS_ACCESS_KEY found in github.com/acmecorp/infra · terraform/backend.tf. Rotate immediately.",
    severity:  "CRITICAL",
    isRead:    false,
    linkTo:    "/dashboard/findings",
    createdAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
  },
  {
    id:        "n2",
    title:     "Scan completed — api.acmecorp.com",
    body:      "Scan finished in 4m 47s — 3 new findings detected, 1 critical.",
    severity:  "INFO",
    isRead:    false,
    linkTo:    "/dashboard/scans",
    createdAt: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
  },
  {
    id:        "n3",
    title:     "New subdomain discovered",
    body:      "staging-v2.acmecorp.com discovered via certificate transparency logs.",
    severity:  "INFO",
    isRead:    false,
    linkTo:    "/dashboard/assets",
    createdAt: new Date(Date.now() - 38 * 60 * 1000).toISOString(),
  },
  {
    id:        "n4",
    title:     "TLS certificate expiring soon",
    body:      "mail.acmecorp.com certificate expires in 12 days. Renew to avoid disruption.",
    severity:  "HIGH",
    isRead:    false,
    linkTo:    "/dashboard/assets",
    createdAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
  },
  {
    id:        "n5",
    title:     "Weekly digest sent",
    body:      "Digest delivered to 3 team members — 22 findings summarized.",
    severity:  "INFO",
    isRead:    true,
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
  },
];

interface NotificationPanelProps {
  open:    boolean;
  onClose: () => void;
}

export function NotificationPanel({ open, onClose }: NotificationPanelProps) {
  const unread = DEMO_NOTIFICATIONS.filter((n) => !n.isRead).length;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40"
            onClick={onClose}
            aria-hidden
          />

          {/* Panel */}
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
            className="fixed right-0 top-[56px] z-50 flex h-[calc(100vh-56px)] w-[380px] flex-col border-l border-[#1F2937] bg-[#0D1117]"
            role="complementary"
            aria-label="Notifications"
          >
            {/* Header */}
            <div className="flex flex-shrink-0 items-center justify-between border-b border-[#1F2937] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <h2 className="text-sm font-semibold text-[#F9FAFB]">Notifications</h2>
                {unread > 0 && (
                  <span className="rounded-full bg-[#EF4444] px-1.5 py-0.5 text-[10px] font-bold text-white">
                    {unread}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <button
                  className="flex h-7 items-center gap-1 rounded px-2 text-[11px] font-medium text-[#6B7280] transition-colors hover:bg-[#1C2333] hover:text-[#F9FAFB]"
                  aria-label="Mark all notifications as read"
                >
                  <CheckCheck className="h-3.5 w-3.5" aria-hidden />
                  Mark all read
                </button>
                <button
                  onClick={onClose}
                  className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] transition-colors hover:bg-[#1C2333] hover:text-[#F9FAFB]"
                  aria-label="Close notifications"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto" role="list" aria-label="Notification list">
              {DEMO_NOTIFICATIONS.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-[#6B7280]">
                  <Bell className="mb-3 h-10 w-10 opacity-40" aria-hidden />
                  <p className="text-sm font-medium">No notifications</p>
                  <p className="mt-1 text-xs">You're all caught up.</p>
                </div>
              ) : (
                DEMO_NOTIFICATIONS.map((notif) => (
                  <NotificationItem key={notif.id} notif={notif} onClose={onClose} />
                ))
              )}
            </div>

            {/* Footer */}
            <div className="flex-shrink-0 border-t border-[#1F2937] p-3">
              <Link
                href="/dashboard/notifications"
                onClick={onClose}
                className="flex w-full items-center justify-center rounded-lg py-2 text-xs font-medium text-[#6B7280] transition-colors hover:bg-[#1C2333] hover:text-[#F9FAFB]"
              >
                Manage notification preferences →
              </Link>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function NotificationItem({
  notif,
  onClose,
}: {
  notif:   NotificationItem;
  onClose: () => void;
}) {
  const content = (
    <div
      className={cn(
        "border-b border-[#1F2937] px-5 py-3.5 transition-colors hover:bg-[#111827]",
        !notif.isRead && "border-l-2 border-l-[#3B82F6] pl-[18px]"
      )}
      role="listitem"
    >
      <div className="mb-1.5 flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <SeverityBadge severity={notif.severity} dot={false} />
          <span className="text-xs font-semibold text-[#F9FAFB] leading-snug">
            {notif.title}
          </span>
        </div>
        <span className="flex-shrink-0 text-[11px] text-[#6B7280]">
          {timeAgo(notif.createdAt)}
        </span>
      </div>
      <p className="text-xs leading-relaxed text-[#9CA3AF]">{notif.body}</p>
    </div>
  );

  if (notif.linkTo) {
    return (
      <Link href={notif.linkTo} onClick={onClose}>
        {content}
      </Link>
    );
  }

  return content;
}
