import type {
  Organization,
  User,
  OrganizationMember,
  Scan,
  Asset,
  Finding,
  Report,
  ApiKey,
  AlertConfig,
  Notification,
  AuditLog,
  MemberRole,
  PlanTier,
  ScanStatus,
  ScanModule,
  FindingSeverity,
  FindingStatus,
  AssetType,
  AlertChannel,
  ReportType,
  AuditAction,
} from "@prisma/client";

// Re-export Prisma enums for convenience
export type {
  MemberRole,
  PlanTier,
  ScanStatus,
  ScanModule,
  FindingSeverity,
  FindingStatus,
  AssetType,
  AlertChannel,
  ReportType,
  AuditAction,
};

// ─── DASHBOARD TYPES ─────────────────────────────────────────────────────────

export interface DashboardStats {
  securityScore:    number;
  scoreDelta:       number;  // +/- from last week
  totalAssets:      number;
  assetsDelta:      number;
  aliveSubdomains:  number;
  subdomainsDelta:  number;
  criticalFindings: number;
  criticalDelta:    number;
  highFindings:     number;
  openCves:         number;
  kevMatches:       number;
  credLeaks:        number;
  cloudAssets:      number;
  publicBuckets:    number;
  resolvedThisMonth: number;
}

export interface AttackSurfaceGrowthPoint {
  week:   string;
  assets: number;
  subs:   number;
}

export interface RiskDistribution {
  critical: number;
  high:     number;
  medium:   number;
  low:      number;
  info:     number;
}

// ─── ENRICHED TYPES ──────────────────────────────────────────────────────────

export type AssetWithFindings = Asset & {
  findings: Pick<Finding, "id" | "severity" | "status">[];
};

export type FindingWithAsset = Finding & {
  asset: Pick<Asset, "id" | "subdomain" | "ipAddress" | "assetType"> | null;
  assignee: Pick<User, "id" | "name" | "avatarUrl"> | null;
};

export type ScanWithStats = Scan & {
  _count: { findings: number };
};

export type MemberWithUser = OrganizationMember & {
  user: Pick<User, "id" | "name" | "email" | "avatarUrl" | "lastLoginAt">;
};

export type ApiKeyDisplay = Omit<ApiKey, "keyHash"> & {
  displayKey: string; // "sk_live_9xK2...mR8" — never the full key
};

export type AuditLogWithUser = AuditLog & {
  user: Pick<User, "id" | "name" | "email"> | null;
};

// ─── FORM TYPES ───────────────────────────────────────────────────────────────

export interface LoginFormData {
  email:    string;
  password: string;
}

export interface RegisterFormData {
  name:             string;
  email:            string;
  password:         string;
  confirmPassword:  string;
  organizationName: string;
}

export interface InviteMemberFormData {
  email: string;
  role:  MemberRole;
}

export interface CreateScanFormData {
  domain:     string;
  scanPorts:  boolean;
  scanCloud:  boolean;
  scanGithub: boolean;
}

export interface CreateApiKeyFormData {
  name:      string;
  scopes:    string[];
  expiresAt: string | null;
}

export interface GenerateReportFormData {
  reportType:   ReportType;
  clientName:   string;
  assessorName: string;
  scanId?:      string;
}

export interface AlertConfigFormData {
  channel:          AlertChannel;
  isEnabled:        boolean;
  minSeverity:      FindingSeverity;
  webhookUrl?:      string;
  emailRecipients?: string[];
  sendOnNewAsset:   boolean;
  sendOnScanDone:   boolean;
  sendOnFindings:   boolean;
  sendDailyDigest:  boolean;
  sendWeeklyReport: boolean;
}

// ─── API RESPONSE SHAPES ─────────────────────────────────────────────────────

export interface PaginatedResponse<T> {
  items:      T[];
  total:      number;
  page:       number;
  pageSize:   number;
  totalPages: number;
}

// ─── PLAN FEATURE FLAGS ────────────────────────────────────────────────────────

export interface PlanFeatures {
  maxAssets:         number;
  maxScansPerMonth:  number;
  maxMembers:        number;
  cloudEnum:         boolean;
  githubScan:        boolean;
  pdfReports:        boolean;
  whitelabelReports: boolean;
  sso:               boolean;
  apiAccess:         boolean;
  auditLogs:         boolean;
  prioritySupport:   boolean;
  slaGuarantee:      boolean;
}

export const PLAN_FEATURES: Record<PlanTier, PlanFeatures> = {
  STARTER: {
    maxAssets:         500,
    maxScansPerMonth:  50,
    maxMembers:        5,
    cloudEnum:         false,
    githubScan:        false,
    pdfReports:        false,
    whitelabelReports: false,
    sso:               false,
    apiAccess:         true,
    auditLogs:         false,
    prioritySupport:   false,
    slaGuarantee:      false,
  },
  PROFESSIONAL: {
    maxAssets:         5000,
    maxScansPerMonth:  500,
    maxMembers:        25,
    cloudEnum:         true,
    githubScan:        true,
    pdfReports:        true,
    whitelabelReports: false,
    sso:               false,
    apiAccess:         true,
    auditLogs:         true,
    prioritySupport:   false,
    slaGuarantee:      false,
  },
  BUSINESS: {
    maxAssets:         Infinity,
    maxScansPerMonth:  Infinity,
    maxMembers:        100,
    cloudEnum:         true,
    githubScan:        true,
    pdfReports:        true,
    whitelabelReports: true,
    sso:               true,
    apiAccess:         true,
    auditLogs:         true,
    prioritySupport:   true,
    slaGuarantee:      false,
  },
  ENTERPRISE: {
    maxAssets:         Infinity,
    maxScansPerMonth:  Infinity,
    maxMembers:        Infinity,
    cloudEnum:         true,
    githubScan:        true,
    pdfReports:        true,
    whitelabelReports: true,
    sso:               true,
    apiAccess:         true,
    auditLogs:         true,
    prioritySupport:   true,
    slaGuarantee:      true,
  },
};

export const PLAN_PRICES: Record<PlanTier, number> = {
  STARTER:      99,
  PROFESSIONAL: 199,
  BUSINESS:     499,
  ENTERPRISE:   0, // custom
};

// ─── UTILITY TYPES ────────────────────────────────────────────────────────────

export type DeepPartial<T> = {
  [K in keyof T]?: T[K] extends object ? DeepPartial<T[K]> : T[K];
};

export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;

export type SortDirection = "asc" | "desc";
export type SortOption<T extends string> = { field: T; direction: SortDirection };
