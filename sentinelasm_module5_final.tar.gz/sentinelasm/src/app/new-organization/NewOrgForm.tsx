"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { Loader2, Building2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const schema = z.object({
  name: z.string().min(2, "Organization name must be at least 2 characters").max(100),
});
type FormData = z.infer<typeof schema>;

export function NewOrgForm() {
  const router = useRouter();
  const { register, handleSubmit, formState: { errors, isSubmitting } } =
    useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    try {
      const res = await fetch("/api/organizations/create", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(data),
      });
      const json = await res.json();
      if (!res.ok) { toast.error(json.error ?? "Failed to create organization"); return; }
      // Switch to the new org
      await fetch("/api/organizations/switch", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ organizationId: json.data.id }),
      });
      toast.success(`"${data.name}" workspace created!`);
      router.push("/dashboard");
      router.refresh();
    } catch {
      toast.error("Network error. Please try again.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
      <div>
        <label htmlFor="name" className="mb-1.5 block text-xs font-medium text-[var(--text-secondary)]">
          Organization Name *
        </label>
        <div className="relative">
          <Building2 className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--text-muted)]" />
          <input
            {...register("name")}
            id="name"
            type="text"
            autoFocus
            placeholder="Acme Corp"
            aria-invalid={!!errors.name}
            className={cn(
              "w-full rounded-lg border bg-[var(--bg-base)] py-2.5 pl-9 pr-3",
              "text-sm text-[var(--text-primary)] placeholder-[var(--text-faint)]",
              "outline-none transition-colors",
              "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
              errors.name
                ? "border-[#EF4444]"
                : "border-[var(--border)] hover:border-[var(--border-light)]"
            )}
          />
        </div>
        {errors.name && (
          <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors.name.message}</p>
        )}
        <p className="mt-1.5 text-xs text-[var(--text-muted)]">
          This will be your workspace name. You can change it later in Settings.
        </p>
      </div>

      <div className="flex gap-3">
        <button
          type="button"
          onClick={() => router.back()}
          className="flex-1 rounded-lg border border-[var(--border)] py-2.5 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-[#3B82F6] py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
        >
          {isSubmitting ? (
            <><Loader2 className="h-4 w-4 animate-spin" /> Creating…</>
          ) : (
            "Create Organization"
          )}
        </button>
      </div>
    </form>
  );
}
