import type { Metadata } from "next";
import { Shield } from "lucide-react";
import { NewOrgForm } from "./NewOrgForm";

export const metadata: Metadata = { title: "Create Organization" };

export default function NewOrganizationPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[var(--bg-base)] px-4">
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.03]"
        aria-hidden
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #3B82F6 1px, transparent 0)`,
          backgroundSize:  "32px 32px",
        }}
      />
      <div className="relative w-full max-w-[440px]">
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[#3B82F6] shadow-[0_0_40px_rgba(59,130,246,0.3)]">
            <Shield className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[var(--text-primary)]">
            Create Organization
          </h1>
          <p className="mt-1 text-sm text-[var(--text-muted)]">
            Set up a new workspace for a client or team
          </p>
        </div>

        <div className="rounded-2xl border border-[var(--border)] bg-[var(--bg-surface)] p-8 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
          <NewOrgForm />
        </div>
      </div>
    </div>
  );
}
