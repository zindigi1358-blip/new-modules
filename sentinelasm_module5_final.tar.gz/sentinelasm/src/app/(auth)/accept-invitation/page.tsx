import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { Shield, Users, AlertTriangle } from "lucide-react";
import { AcceptInviteForm } from "./AcceptInviteForm";

export const metadata: Metadata = { title: "Accept Invitation" };

interface AcceptInvitationPageProps {
  searchParams: { token?: string };
}

export default async function AcceptInvitationPage({
  searchParams,
}: AcceptInvitationPageProps) {
  const token = searchParams.token;

  if (!token) redirect("/login");

  // Validate invitation
  const invitation = await db.invitation.findFirst({
    where: {
      token,
      acceptedAt: null,
      expiresAt:  { gt: new Date() },
    },
    include: {
      organization: { select: { id: true, name: true, plan: true } },
    },
  });

  if (!invitation) {
    return (
      <InviteShell>
        <div className="rounded-2xl border border-[#1F2937] bg-[#0D1117] p-8 text-center">
          <div className="mb-4 flex h-14 w-14 mx-auto items-center justify-center rounded-full bg-[rgba(239,68,68,0.1)]">
            <AlertTriangle className="h-7 w-7 text-[#EF4444]" />
          </div>
          <h2 className="mb-2 text-base font-semibold text-[#F9FAFB]">
            Invitation expired or invalid
          </h2>
          <p className="text-sm text-[#6B7280]">
            This invitation link has expired or already been used. Ask your admin to send a new one.
          </p>
        </div>
      </InviteShell>
    );
  }

  // Check if user already exists
  const existingUser = await db.user.findUnique({
    where: { email: invitation.email },
  });

  return (
    <InviteShell>
      <div className="rounded-2xl border border-[#1F2937] bg-[#0D1117] p-8 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
        {/* Org card */}
        <div className="mb-6 flex items-center gap-3 rounded-xl border border-[#1F2937] bg-[#111827] p-4">
          <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-purple-600 text-sm font-bold text-white">
            {invitation.organization.name.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <p className="text-sm font-semibold text-[#F9FAFB]">{invitation.organization.name}</p>
            <p className="text-xs text-[#6B7280]">
              You've been invited as{" "}
              <span className="font-medium text-[#3B82F6]">{invitation.role.toLowerCase()}</span>
            </p>
          </div>
        </div>

        <div className="mb-6">
          <h2 className="text-lg font-semibold text-[#F9FAFB]">
            {existingUser ? "Accept invitation" : "Create your account"}
          </h2>
          <p className="mt-1 text-sm text-[#6B7280]">
            Joining <strong className="text-[#F9FAFB]">{invitation.organization.name}</strong> on SentinelASM
          </p>
        </div>

        <AcceptInviteForm
          token={token}
          email={invitation.email}
          orgName={invitation.organization.name}
          role={invitation.role}
          existingUser={!!existingUser}
        />
      </div>
    </InviteShell>
  );
}

function InviteShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#080B12] px-4">
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.03]"
        aria-hidden
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #3B82F6 1px, transparent 0)`,
          backgroundSize:  "32px 32px",
        }}
      />
      <div className="relative w-full max-w-[420px]">
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[#3B82F6] shadow-[0_0_40px_rgba(59,130,246,0.3)]">
            <Shield className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#F9FAFB]">
            Sentinel<span className="text-[#3B82F6]">ASM</span>
          </h1>
        </div>
        {children}
      </div>
    </div>
  );
}
