"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { MemberRole } from "@/types";

const newUserSchema = z
  .object({
    name:            z.string().min(2, "Name must be at least 2 characters"),
    password:        z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: "Passwords don't match",
    path:    ["confirmPassword"],
  });

const existingUserSchema = z.object({
  password: z.string().min(1, "Enter your password to confirm"),
});

type NewUserData      = z.infer<typeof newUserSchema>;
type ExistingUserData = z.infer<typeof existingUserSchema>;

interface AcceptInviteFormProps {
  token:        string;
  email:        string;
  orgName:      string;
  role:         MemberRole;
  existingUser: boolean;
}

export function AcceptInviteForm({
  token, email, existingUser,
}: AcceptInviteFormProps) {
  const router        = useRouter();
  const [showPw, setShowPw] = useState(false);

  const schema   = existingUser ? existingUserSchema : newUserSchema;
  const { register, handleSubmit, formState: { errors, isSubmitting } } =
    useForm<any>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: NewUserData | ExistingUserData) => {
    try {
      const res = await fetch("/api/auth/accept-invitation", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ token, ...data }),
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error ?? "Failed to accept invitation");
        return;
      }
      toast.success("Welcome to the team!");
      router.push("/dashboard");
      router.refresh();
    } catch {
      toast.error("Network error. Please try again.");
    }
  };

  const inputClass = (hasError: boolean) =>
    cn(
      "w-full rounded-lg border bg-[#080B12] px-3 py-2.5 text-sm text-[#F9FAFB]",
      "placeholder-[#374151] outline-none transition-colors",
      "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
      hasError ? "border-[#EF4444]" : "border-[#1F2937] hover:border-[#374151]"
    );

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      {/* Email — readonly */}
      <div>
        <label className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">Email Address</label>
        <input
          type="email"
          value={email}
          readOnly
          className="w-full cursor-not-allowed rounded-lg border border-[#1F2937] bg-[#080B12] px-3 py-2.5 text-sm text-[#6B7280]"
        />
      </div>

      {/* Name — only for new users */}
      {!existingUser && (
        <div>
          <label htmlFor="name" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
            Full Name
          </label>
          <input
            {...register("name")}
            id="name"
            type="text"
            autoFocus
            placeholder="Ali Raza"
            aria-invalid={!!(errors as any).name}
            className={inputClass(!!(errors as any).name)}
          />
          {(errors as any).name && (
            <p className="mt-1 text-xs text-[#EF4444]">{(errors as any).name?.message}</p>
          )}
        </div>
      )}

      {/* Password */}
      <div>
        <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
          {existingUser ? "Your Password (to confirm)" : "Create Password"}
        </label>
        <div className="relative">
          <input
            {...register("password")}
            id="password"
            type={showPw ? "text" : "password"}
            autoFocus={existingUser}
            placeholder="••••••••"
            aria-invalid={!!errors.password}
            className={cn(inputClass(!!errors.password), "pr-10")}
          />
          <button
            type="button"
            onClick={() => setShowPw(!showPw)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#9CA3AF]"
          >
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        {errors.password && (
          <p className="mt-1 text-xs text-[#EF4444]">{(errors.password as any).message}</p>
        )}
      </div>

      {/* Confirm password — only for new users */}
      {!existingUser && (
        <div>
          <label htmlFor="confirmPassword" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
            Confirm Password
          </label>
          <input
            {...register("confirmPassword")}
            id="confirmPassword"
            type={showPw ? "text" : "password"}
            placeholder="••••••••"
            aria-invalid={!!(errors as any).confirmPassword}
            className={inputClass(!!(errors as any).confirmPassword)}
          />
          {(errors as any).confirmPassword && (
            <p className="mt-1 text-xs text-[#EF4444]">{(errors as any).confirmPassword?.message}</p>
          )}
        </div>
      )}

      <button
        type="submit"
        disabled={isSubmitting}
        className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#3B82F6] py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
      >
        {isSubmitting ? (
          <><Loader2 className="h-4 w-4 animate-spin" /> Joining…</>
        ) : (
          existingUser ? "Accept & Join Team" : "Create Account & Join"
        )}
      </button>
    </form>
  );
}
