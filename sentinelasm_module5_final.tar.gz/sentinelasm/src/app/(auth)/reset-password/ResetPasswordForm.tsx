"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { Loader2, Eye, EyeOff, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const resetSchema = z
  .object({
    password:        z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: "Passwords don't match",
    path:    ["confirmPassword"],
  });

type ResetFormData = z.infer<typeof resetSchema>;

export function ResetPasswordForm({ token }: { token: string }) {
  const router        = useRouter();
  const [showPw, setShowPw] = useState(false);
  const [done,   setDone]   = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<ResetFormData>({ resolver: zodResolver(resetSchema) });

  const onSubmit = async (data: ResetFormData) => {
    try {
      const res = await fetch("/api/auth/reset-password", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ token, password: data.password }),
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error ?? "Reset failed. The link may have expired.");
        return;
      }
      setDone(true);
      setTimeout(() => router.push("/login"), 2500);
    } catch {
      toast.error("Network error. Please try again.");
    }
  };

  if (done) {
    return (
      <div className="flex flex-col items-center py-4 text-center">
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[rgba(16,185,129,0.1)]">
          <CheckCircle2 className="h-8 w-8 text-[#10B981]" />
        </div>
        <h3 className="mb-2 text-base font-semibold text-[#F9FAFB]">Password updated!</h3>
        <p className="text-sm text-[#6B7280]">Redirecting you to sign in…</p>
      </div>
    );
  }

  const inputClass = (hasError: boolean) =>
    cn(
      "w-full rounded-lg border bg-[#080B12] px-3 py-2.5 text-sm text-[#F9FAFB]",
      "placeholder-[#374151] outline-none transition-colors",
      "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
      hasError
        ? "border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]"
        : "border-[#1F2937] hover:border-[#374151]"
    );

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      {/* New password */}
      <div>
        <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
          New Password
        </label>
        <div className="relative">
          <input
            {...register("password")}
            id="password"
            type={showPw ? "text" : "password"}
            autoFocus
            placeholder="••••••••"
            aria-invalid={!!errors.password}
            className={cn(inputClass(!!errors.password), "pr-10")}
          />
          <button
            type="button"
            onClick={() => setShowPw(!showPw)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#9CA3AF]"
            aria-label={showPw ? "Hide password" : "Show password"}
          >
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        {errors.password && (
          <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors.password.message}</p>
        )}
      </div>

      {/* Confirm */}
      <div>
        <label htmlFor="confirmPassword" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
          Confirm Password
        </label>
        <input
          {...register("confirmPassword")}
          id="confirmPassword"
          type={showPw ? "text" : "password"}
          placeholder="••••••••"
          aria-invalid={!!errors.confirmPassword}
          className={inputClass(!!errors.confirmPassword)}
        />
        {errors.confirmPassword && (
          <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors.confirmPassword.message}</p>
        )}
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#3B82F6] py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
      >
        {isSubmitting ? (
          <><Loader2 className="h-4 w-4 animate-spin" /> Updating password…</>
        ) : (
          "Set New Password"
        )}
      </button>
    </form>
  );
}
