"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const loginSchema = z.object({
  email:    z.string().email("Enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

type LoginFormData = z.infer<typeof loginSchema>;

export function LoginForm() {
  const router          = useRouter();
  const [showPw, setShowPw] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFormData) => {
    try {
      const res = await fetch("/api/auth/login", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(data),
      });

      const json = await res.json();

      if (!res.ok) {
        toast.error(json.error ?? "Sign in failed. Please try again.");
        return;
      }

      router.push("/dashboard");
      router.refresh();
    } catch {
      toast.error("Connection error. Please check your network and try again.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      {/* Email */}
      <div>
        <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
          Email address
        </label>
        <input
          {...register("email")}
          id="email"
          type="email"
          autoComplete="email"
          autoFocus
          placeholder="you@company.com"
          aria-invalid={!!errors.email}
          aria-describedby={errors.email ? "email-error" : undefined}
          className={cn(
            "w-full rounded-lg border bg-[#080B12] px-3 py-2.5 text-sm text-[#F9FAFB]",
            "placeholder-[#374151] outline-none transition-colors",
            "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
            errors.email
              ? "border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]"
              : "border-[#1F2937] hover:border-[#374151]"
          )}
        />
        {errors.email && (
          <p id="email-error" className="mt-1 text-xs text-[#EF4444]" role="alert">
            {errors.email.message}
          </p>
        )}
      </div>

      {/* Password */}
      <div>
        <div className="mb-1.5 flex items-center justify-between">
          <label htmlFor="password" className="text-xs font-medium text-[#D1D5DB]">
            Password
          </label>
          <a
            href="/forgot-password"
            className="text-xs text-[#3B82F6] transition-colors hover:text-[#60A5FA]"
          >
            Forgot password?
          </a>
        </div>
        <div className="relative">
          <input
            {...register("password")}
            id="password"
            type={showPw ? "text" : "password"}
            autoComplete="current-password"
            placeholder="••••••••"
            aria-invalid={!!errors.password}
            aria-describedby={errors.password ? "password-error" : undefined}
            className={cn(
              "w-full rounded-lg border bg-[#080B12] px-3 py-2.5 pr-10 text-sm text-[#F9FAFB]",
              "placeholder-[#374151] outline-none transition-colors",
              "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
              errors.password
                ? "border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]"
                : "border-[#1F2937] hover:border-[#374151]"
            )}
          />
          <button
            type="button"
            onClick={() => setShowPw(!showPw)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280] transition-colors hover:text-[#9CA3AF]"
            aria-label={showPw ? "Hide password" : "Show password"}
          >
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        {errors.password && (
          <p id="password-error" className="mt-1 text-xs text-[#EF4444]" role="alert">
            {errors.password.message}
          </p>
        )}
      </div>

      {/* Submit */}
      <button
        type="submit"
        disabled={isSubmitting}
        className={cn(
          "mt-2 flex w-full items-center justify-center gap-2 rounded-lg",
          "bg-[#3B82F6] px-4 py-2.5 text-sm font-semibold text-white",
          "transition-colors hover:bg-[#1D4ED8]",
          "disabled:cursor-not-allowed disabled:opacity-60",
          "focus-visible:outline-2 focus-visible:outline-[#3B82F6]"
        )}
      >
        {isSubmitting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
            Signing in…
          </>
        ) : (
          "Sign in"
        )}
      </button>
    </form>
  );
}
