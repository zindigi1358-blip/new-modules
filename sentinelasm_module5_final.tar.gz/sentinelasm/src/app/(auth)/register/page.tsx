import type { Metadata } from "next";
import Link from "next/link";
import { Shield } from "lucide-react";
import { RegisterForm } from "./RegisterForm";

export const metadata: Metadata = { title: "Create Account" };

export default function RegisterPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#080B12] px-4">
      <div
        className="pointer-events-none fixed inset-0 opacity-[0.03]"
        aria-hidden
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #3B82F6 1px, transparent 0)`,
          backgroundSize:  "32px 32px",
        }}
      />
      <div className="relative w-full max-w-[420px]">
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-[#3B82F6] shadow-[0_0_40px_rgba(59,130,246,0.3)]">
            <Shield className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#F9FAFB]">
            Sentinel<span className="text-[#3B82F6]">ASM</span>
          </h1>
          <p className="mt-1 text-sm text-[#6B7280]">Start your free 14-day trial</p>
        </div>
        <div className="rounded-2xl border border-[#1F2937] bg-[#0D1117] p-8 shadow-[0_8px_32px_rgba(0,0,0,0.5)]">
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-[#F9FAFB]">Create your account</h2>
            <p className="mt-1 text-sm text-[#6B7280]">
              Already have an account?{" "}
              <Link href="/login" className="font-medium text-[#3B82F6] hover:text-[#60A5FA]">
                Sign in
              </Link>
            </p>
          </div>
          <RegisterForm />
        </div>
        <p className="mt-4 text-center text-xs text-[#6B7280]">
          No credit card required · Cancel anytime
        </p>
      </div>
    </div>
  );
}
