"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const schema = z.object({
  name:             z.string().min(2, "Name must be at least 2 characters"),
  email:            z.string().email("Enter a valid email address"),
  organizationName: z.string().min(2, "Organization name must be at least 2 characters"),
  password:         z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword:  z.string(),
}).refine(d => d.password === d.confirmPassword, {
  message: "Passwords don't match",
  path:    ["confirmPassword"],
});

type FormData = z.infer<typeof schema>;

export function RegisterForm() {
  const router    = useRouter();
  const [showPw, setShowPw] = useState(false);

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      const res = await fetch("/api/auth/register", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(data),
      });
      const json = await res.json();
      if (!res.ok) { toast.error(json.error ?? "Registration failed"); return; }
      router.push("/dashboard");
      router.refresh();
    } catch {
      toast.error("Connection error. Please try again.");
    }
  };

  const inputClass = (hasError: boolean) => cn(
    "w-full rounded-lg border bg-[#080B12] px-3 py-2.5 text-sm text-[#F9FAFB]",
    "placeholder-[#374151] outline-none transition-colors",
    "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
    hasError
      ? "border-[#EF4444] focus:border-[#EF4444] focus:ring-[#EF4444]"
      : "border-[#1F2937] hover:border-[#374151]"
  );

  const fields = [
    { id: "name",             label: "Full Name",          type: "text",     placeholder: "Ali Raza" },
    { id: "email",            label: "Work Email",         type: "email",    placeholder: "you@company.com" },
    { id: "organizationName", label: "Organization Name",  type: "text",     placeholder: "Acme Corp" },
  ] as const;

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      {fields.map(f => (
        <div key={f.id}>
          <label htmlFor={f.id} className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">{f.label}</label>
          <input
            {...register(f.id)}
            id={f.id}
            type={f.type}
            placeholder={f.placeholder}
            aria-invalid={!!errors[f.id]}
            className={inputClass(!!errors[f.id])}
          />
          {errors[f.id] && <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors[f.id]?.message}</p>}
        </div>
      ))}

      {/* Password */}
      <div>
        <label htmlFor="password" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">Password</label>
        <div className="relative">
          <input
            {...register("password")}
            id="password"
            type={showPw ? "text" : "password"}
            placeholder="Min. 8 characters"
            className={inputClass(!!errors.password) + " pr-10"}
          />
          <button type="button" onClick={() => setShowPw(!showPw)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#9CA3AF]">
            {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        {errors.password && <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors.password.message}</p>}
      </div>

      {/* Confirm password */}
      <div>
        <label htmlFor="confirmPassword" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">Confirm Password</label>
        <input
          {...register("confirmPassword")}
          id="confirmPassword"
          type={showPw ? "text" : "password"}
          placeholder="••••••••"
          className={inputClass(!!errors.confirmPassword)}
        />
        {errors.confirmPassword && <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors.confirmPassword.message}</p>}
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:cursor-not-allowed disabled:opacity-60"
      >
        {isSubmitting ? <><Loader2 className="h-4 w-4 animate-spin" />Creating account…</> : "Create account — free"}
      </button>
    </form>
  );
}
