"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, CheckCircle2, Mail } from "lucide-react";
import { cn } from "@/lib/utils";

const forgotSchema = z.object({
  email: z.string().email("Enter a valid email address"),
});
type ForgotFormData = z.infer<typeof forgotSchema>;

export function ForgotPasswordForm() {
  const [sent, setSent] = useState(false);
  const [sentEmail, setSentEmail] = useState("");

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<ForgotFormData>({
    resolver: zodResolver(forgotSchema),
  });

  const onSubmit = async (data: ForgotFormData) => {
    try {
      await fetch("/api/auth/forgot-password", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(data),
      });
      // Always show success — don't leak whether email exists
      setSentEmail(data.email);
      setSent(true);
    } catch {
      setSentEmail(data.email);
      setSent(true);
    }
  };

  if (sent) {
    return (
      <div className="flex flex-col items-center py-4 text-center">
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[rgba(16,185,129,0.1)]">
          <CheckCircle2 className="h-8 w-8 text-[#10B981]" />
        </div>
        <h3 className="mb-2 text-base font-semibold text-[#F9FAFB]">Check your inbox</h3>
        <p className="mb-4 text-sm text-[#6B7280]">
          If <span className="font-medium text-[#F9FAFB]">{sentEmail}</span> is registered,
          you'll receive a reset link within a few minutes.
        </p>
        <p className="text-xs text-[#6B7280]">
          Didn't get it? Check your spam folder or{" "}
          <button onClick={() => setSent(false)} className="text-[#3B82F6] hover:text-[#60A5FA]">
            try again
          </button>.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-4">
      <div>
        <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-[#D1D5DB]">
          Email address
        </label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#6B7280]" />
          <input
            {...register("email")}
            id="email"
            type="email"
            autoFocus
            autoComplete="email"
            placeholder="you@company.com"
            aria-invalid={!!errors.email}
            className={cn(
              "w-full rounded-lg border bg-[#080B12] py-2.5 pl-9 pr-3 text-sm text-[#F9FAFB]",
              "placeholder-[#374151] outline-none transition-colors",
              "focus:border-[#3B82F6] focus:ring-1 focus:ring-[#3B82F6]",
              errors.email
                ? "border-[#EF4444]"
                : "border-[#1F2937] hover:border-[#374151]"
            )}
          />
        </div>
        {errors.email && (
          <p className="mt-1 text-xs text-[#EF4444]" role="alert">{errors.email.message}</p>
        )}
      </div>

      <button
        type="submit"
        disabled={isSubmitting}
        className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#3B82F6] py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
      >
        {isSubmitting ? (
          <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</>
        ) : (
          "Send Reset Link"
        )}
      </button>
    </form>
  );
}
