import Link from "next/link";
import { Shield } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-[rgba(59,130,246,0.1)]">
        <Shield className="h-8 w-8 text-[#3B82F6]" />
      </div>

      <h1 className="mb-2 font-tabular text-5xl font-bold tracking-tight text-[var(--text-primary)]">
        404
      </h1>
      <h2 className="mb-3 text-lg font-semibold text-[var(--text-primary)]">
        Page not found
      </h2>
      <p className="mb-8 max-w-sm text-sm text-[var(--text-muted)]">
        The page you're looking for doesn't exist or you don't have permission to view it.
      </p>

      <div className="flex gap-3">
        <Link
          href="/dashboard"
          className="flex items-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
        >
          Back to Dashboard
        </Link>
        <Link
          href="/dashboard/findings"
          className="flex items-center gap-2 rounded-lg border border-[var(--border)] px-4 py-2 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
        >
          View Findings
        </Link>
      </div>
    </div>
  );
}
