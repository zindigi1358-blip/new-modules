"use client";

import { useEffect, useRef } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import {
  AlertTriangle, Globe, ScanLine, FileText,
  TrendingUp, TrendingDown, Minus, ArrowRight,
  CheckCircle2, Info, Shield,
} from "lucide-react";
import { cn, timeAgo, securityScoreColor, scoreRingOffset, formatNumber } from "@/lib/utils";
import { SeverityBadge, CvssPill } from "@/components/ui/Badge";
import type { DashboardStats, RiskDistribution, FindingSeverity } from "@/types";

// ─── Types ───────────────────────────────────────────────────────────────────

interface RecentScan {
  id: string; domain: string; status: string;
  createdAt: string | Date; findingsCount: number;
  aliveAssets: number; durationSecs: number | null;
}

interface RecentNotif {
  id: string; title: string; body: string; severity: FindingSeverity;
  isRead: boolean; linkTo: string | null; createdAt: string | Date;
}

interface DashboardClientProps {
  stats:               DashboardStats;
  riskDistribution:    RiskDistribution;
  recentScans:         RecentScan[];
  recentNotifications: RecentNotif[];
  orgName:             string;
}

// ─── Demo chart data (filled from real data in production) ────────────────────

const GROWTH_DATA = [
  { week: "W1", assets: 671, subs: 198 },
  { week: "W2", assets: 698, subs: 206 },
  { week: "W3", assets: 712, subs: 213 },
  { week: "W4", assets: 729, subs: 219 },
  { week: "W5", assets: 751, subs: 228 },
  { week: "W6", assets: 783, subs: 237 },
  { week: "W7", assets: 821, subs: 241 },
  { week: "W8", assets: 847, subs: 243 },
];

const RISK_TREND = [
  { month: "Feb", critical: 12, high: 22, medium: 34 },
  { month: "Mar", critical: 10, high: 19, medium: 31 },
  { month: "Apr", critical: 8,  high: 17, medium: 29 },
  { month: "May", critical: 9,  high: 18, medium: 32 },
  { month: "Jun", critical: 6,  high: 16, medium: 28 },
  { month: "Jul", critical: 7,  high: 16, medium: 28 },
];

const RISK_PIE_COLORS = {
  critical: "#EF4444",
  high:     "#F59E0B",
  medium:   "#60A5FA",
  low:      "#10B981",
  info:     "#6B7280",
};

// ─── Custom tooltip ────────────────────────────────────────────────────────────

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: { name: string; value: number; color: string }[]; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-[#1F2937] bg-[#1C2333] p-3 shadow-xl">
      <p className="mb-1.5 text-xs font-semibold text-[#9CA3AF]">{label}</p>
      {payload.map((entry) => (
        <div key={entry.name} className="flex items-center gap-2 text-xs">
          <span className="h-2 w-2 rounded-full" style={{ background: entry.color }} />
          <span className="text-[#9CA3AF]">{entry.name}:</span>
          <span className="font-semibold text-[#F9FAFB]">{entry.value}</span>
        </div>
      ))}
    </div>
  );
}

// ─── Score Ring ───────────────────────────────────────────────────────────────

function SecurityScoreRing({ score }: { score: number }) {
  const circumference = 364.4;
  const offset        = scoreRingOffset(score, circumference);
  const color         = securityScoreColor(score);
  const ringRef       = useRef<SVGCircleElement>(null);

  useEffect(() => {
    if (!ringRef.current) return;
    const el = ringRef.current;
    el.style.strokeDashoffset = String(circumference);
    const timer = setTimeout(() => {
      el.style.transition = "stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)";
      el.style.strokeDashoffset = String(offset);
    }, 200);
    return () => clearTimeout(timer);
  }, [offset]);

  const label =
    score >= 80 ? "Good"    :
    score >= 60 ? "Fair"    :
    score >= 40 ? "Poor"    :
                  "Critical";

  return (
    <div
      className="flex flex-col items-center justify-center"
      role="img"
      aria-label={`Security score: ${score} out of 100 — ${label}`}
    >
      <div className="relative h-[140px] w-[140px]">
        <svg width="140" height="140" viewBox="0 0 140 140" className="-rotate-90">
          <circle
            cx="70" cy="70" r="58"
            fill="none" stroke="#1C2333" strokeWidth="10"
          />
          <circle
            ref={ringRef}
            cx="70" cy="70" r="58"
            fill="none"
            stroke={color}
            strokeWidth="10"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={circumference}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span
            className="font-tabular text-[34px] font-bold leading-none tracking-tight"
            style={{ color }}
          >
            {score}
          </span>
          <span className="mt-0.5 text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
            /100
          </span>
        </div>
      </div>
      <p className="mt-3 text-sm font-semibold text-[#F9FAFB]">Security Score</p>
      <p className="mt-0.5 flex items-center gap-1 text-xs text-[#10B981]">
        <TrendingUp className="h-3.5 w-3.5" aria-hidden />
        +4 pts from last week
      </p>
    </div>
  );
}

// ─── Metric card ──────────────────────────────────────────────────────────────

interface MetricCardProps {
  label:      string;
  value:      number | string;
  delta?:     { value: number | string; dir: "up" | "down" | "neutral"; label: string };
  accentColor: string;
  href?:      string;
  className?: string;
}

function MetricCard({ label, value, delta, accentColor, href, className }: MetricCardProps) {
  const content = (
    <div
      className={cn(
        "group relative overflow-hidden rounded-xl border border-[#1F2937] bg-[#111827] p-5",
        "transition-colors hover:border-[#374151] hover:bg-[#141E2E]",
        className
      )}
    >
      {/* Top accent line */}
      <div className="absolute inset-x-0 top-0 h-[2px]" style={{ background: accentColor }} />

      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]">
        {label}
      </p>
      <p
        className="font-tabular text-3xl font-bold leading-none tracking-tight"
        style={{ color: accentColor }}
      >
        {typeof value === "number" ? formatNumber(value) : value}
      </p>

      {delta && (
        <div className="mt-3 flex items-center justify-between">
          <div
            className={cn(
              "flex items-center gap-1 text-xs font-medium",
              delta.dir === "up"      && accentColor === "#EF4444" ? "text-[#EF4444]" :
              delta.dir === "up"      ? "text-[#10B981]" :
              delta.dir === "down"    ? "text-[#10B981]" :
                                        "text-[#6B7280]"
            )}
          >
            {delta.dir === "up"      && <TrendingUp   className="h-3.5 w-3.5" />}
            {delta.dir === "down"    && <TrendingDown className="h-3.5 w-3.5" />}
            {delta.dir === "neutral" && <Minus        className="h-3.5 w-3.5" />}
            {delta.value !== undefined ? `${delta.dir === "up" ? "▲" : delta.dir === "down" ? "▼" : "—"} ${delta.value}` : ""}
          </div>
          <span className="text-[11px] text-[#4B5563]">{delta.label}</span>
        </div>
      )}

      {/* Bar */}
      <div className="mt-3 h-1 overflow-hidden rounded-full bg-[#1C2333]">
        <div
          className="h-full rounded-full transition-all"
          style={{
            background: accentColor,
            width: typeof value === "number" ? `${Math.min(100, (value / 100) * 100)}%` : "50%",
            opacity: 0.6,
          }}
        />
      </div>
    </div>
  );

  return href ? <Link href={href}>{content}</Link> : content;
}

// ─── Activity item ────────────────────────────────────────────────────────────

function ActivityItem({ notif }: { notif: RecentNotif }) {
  const icons: Record<FindingSeverity, React.ElementType> = {
    CRITICAL: AlertTriangle,
    HIGH:     AlertTriangle,
    MEDIUM:   Info,
    LOW:      CheckCircle2,
    INFO:     Info,
  };
  const Icon = icons[notif.severity];

  const bgColors: Record<FindingSeverity, string> = {
    CRITICAL: "bg-[rgba(239,68,68,0.1)] text-[#EF4444]",
    HIGH:     "bg-[rgba(245,158,11,0.1)] text-[#F59E0B]",
    MEDIUM:   "bg-[rgba(245,158,11,0.1)] text-[#F59E0B]",
    LOW:      "bg-[rgba(16,185,129,0.1)] text-[#10B981]",
    INFO:     "bg-[rgba(59,130,246,0.1)] text-[#3B82F6]",
  };

  return (
    <div className="flex gap-3 border-b border-[#1F2937] py-3 last:border-0">
      <div className={cn("mt-0.5 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg", bgColors[notif.severity])}>
        <Icon className="h-3.5 w-3.5" aria-hidden />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-[13px] font-medium leading-snug text-[#F9FAFB]">{notif.title}</p>
        <div className="mt-1 flex items-center gap-2">
          <span className="text-[11px] text-[#6B7280]">{timeAgo(notif.createdAt)}</span>
          <SeverityBadge severity={notif.severity} dot={false} />
        </div>
      </div>
    </div>
  );
}

// ─── Top findings table ────────────────────────────────────────────────────────

const TOP_FINDINGS = [
  { title: "AWS Access Key Leaked — GitHub",         asset: "github.com/acmecorp/infra",         cvss: 9.9, severity: "CRITICAL" as FindingSeverity, score: 96 },
  { title: "Exposed .git Directory",                 asset: "dev.acmecorp.com/.git/config",       cvss: 9.8, severity: "CRITICAL" as FindingSeverity, score: 91 },
  { title: "PHP 5.6.40 — RCE (CVE-2019-11043) ☠",  asset: "old.acmecorp.com",                   cvss: 9.8, severity: "CRITICAL" as FindingSeverity, score: 88 },
  { title: "MongoDB Port Exposed to Internet",       asset: "api.acmecorp.com:27017",             cvss: 9.1, severity: "CRITICAL" as FindingSeverity, score: 88 },
  { title: "S3 Bucket Publicly Readable",            asset: "acmecorp-backups.s3.amazonaws.com",  cvss: 8.6, severity: "CRITICAL" as FindingSeverity, score: 85 },
];

// ─── Main component ───────────────────────────────────────────────────────────

export function DashboardClient({
  stats,
  riskDistribution,
  recentScans,
  recentNotifications,
  orgName,
}: DashboardClientProps) {
  const pieData = Object.entries(riskDistribution)
    .filter(([, v]) => v > 0)
    .map(([k, v]) => ({
      name:  k.charAt(0).toUpperCase() + k.slice(1),
      value: v,
      color: RISK_PIE_COLORS[k as keyof typeof RISK_PIE_COLORS],
    }));

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Page header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Security Overview</h1>
          <p className="mt-1 flex items-center gap-2 text-sm text-[#6B7280]">
            {orgName} · Last scan completed 14 minutes ago
            <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(16,185,129,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#10B981]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#10B981] animate-pulse-dot" />
              LIVE
            </span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/dashboard/reports"
            className="flex h-8 items-center gap-1.5 rounded-lg border border-[#1F2937] bg-[#111827] px-3 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151] hover:text-[#F9FAFB]"
          >
            <FileText className="h-3.5 w-3.5" aria-hidden /> Export Report
          </Link>
          <Link
            href="/dashboard/scans/new"
            className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
          >
            <ScanLine className="h-3.5 w-3.5" aria-hidden /> Run Scan
          </Link>
        </div>
      </div>

      {/* Score + Top metrics */}
      <div className="grid grid-cols-[200px_1fr] gap-4">
        {/* Score ring */}
        <div className="flex items-center justify-center rounded-xl border border-[#1F2937] bg-[#111827] p-6">
          <SecurityScoreRing score={stats.securityScore} />
        </div>

        {/* Metric grid */}
        <div className="space-y-3">
          <div className="grid grid-cols-4 gap-3">
            <MetricCard label="Critical Findings" value={stats.criticalFindings} delta={{ value: stats.criticalDelta, dir: "up",      label: "new today"    }} accentColor="#EF4444" href="/dashboard/findings" />
            <MetricCard label="High Risk"          value={stats.highFindings}     delta={{ value: "unchanged",           dir: "neutral", label: "7-day avg"    }} accentColor="#F59E0B" href="/dashboard/findings" />
            <MetricCard label="Total Assets"       value={stats.totalAssets}      delta={{ value: stats.assetsDelta,     dir: "up",      label: "this week"    }} accentColor="#3B82F6" href="/dashboard/assets" />
            <MetricCard label="Alive Subdomains"   value={stats.aliveSubdomains}  delta={{ value: 3,                     dir: "down",    label: "went offline" }} accentColor="#10B981" href="/dashboard/assets" />
          </div>
          <div className="grid grid-cols-4 gap-3">
            <MetricCard label="Open CVEs"       value={stats.openCves}          delta={{ value: 5,   dir: "up",   label: "KEV: " + stats.kevMatches }} accentColor="#EF4444" href="/dashboard/findings" className="py-3.5" />
            <MetricCard label="Cloud Assets"    value={stats.cloudAssets}       delta={{ value: stats.publicBuckets + " public", dir: "up", label: "buckets" }} accentColor="#6B7280" className="py-3.5" />
            <MetricCard label="Cred Leaks"      value={stats.credLeaks}         delta={{ value: "GitHub repos", dir: "neutral", label: "" }} accentColor="#EF4444" className="py-3.5" />
            <MetricCard label="Resolved"        value={stats.resolvedThisMonth} delta={{ value: "this month", dir: "down", label: "findings" }} accentColor="#10B981" className="py-3.5" />
          </div>
        </div>
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-[1fr_320px] gap-4">
        {/* Growth chart */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
            <div>
              <h2 className="text-sm font-semibold text-[#F9FAFB]">Attack Surface Growth</h2>
              <p className="text-xs text-[#6B7280]">Asset discovery over the last 8 weeks</p>
            </div>
            <div className="flex gap-1">
              {["8W", "3M", "1Y"].map((t, i) => (
                <button
                  key={t}
                  className={cn(
                    "rounded px-2.5 py-1 text-[11px] font-medium transition-colors",
                    i === 0
                      ? "bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                      : "text-[#6B7280] hover:text-[#9CA3AF]"
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="p-4">
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={GROWTH_DATA} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="assetsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#3B82F6" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="subsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#10B981" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
                <XAxis dataKey="week" tick={{ fill: "#6B7280", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#6B7280", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="assets" name="Total Assets"      stroke="#3B82F6" strokeWidth={2} fill="url(#assetsGrad)" dot={false} activeDot={{ r: 4, fill: "#3B82F6" }} />
                <Area type="monotone" dataKey="subs"   name="Alive Subdomains" stroke="#10B981" strokeWidth={2} fill="url(#subsGrad)"   dot={false} activeDot={{ r: 4, fill: "#10B981" }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk donut */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="border-b border-[#1F2937] px-5 py-4">
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Risk Distribution</h2>
            <p className="text-xs text-[#6B7280]">By severity level</p>
          </div>
          <div className="p-4">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%" cy="50%"
                  innerRadius={48} outerRadius={72}
                  paddingAngle={2}
                  dataKey="value"
                  startAngle={90} endAngle={-270}
                >
                  {pieData.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} opacity={0.9} stroke="#111827" strokeWidth={2} />
                  ))}
                </Pie>
                <Tooltip content={<ChartTooltip />} />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-2">
              {(Object.entries(riskDistribution) as [keyof RiskDistribution, number][])
                .filter(([, v]) => v > 0)
                .map(([key, val]) => (
                  <div key={key} className="flex items-center gap-2 text-xs">
                    <span
                      className="h-2 w-2 flex-shrink-0 rounded-sm"
                      style={{ background: RISK_PIE_COLORS[key] }}
                      aria-hidden
                    />
                    <span className="flex-1 capitalize text-[#6B7280]">{key}</span>
                    <span className="font-tabular font-semibold text-[#F9FAFB]">{val}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>

      {/* Risk trend + Bottom row */}
      <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
        <div className="border-b border-[#1F2937] px-5 py-4">
          <h2 className="text-sm font-semibold text-[#F9FAFB]">Risk Trend</h2>
          <p className="text-xs text-[#6B7280]">Finding severity over the last 6 months</p>
        </div>
        <div className="p-4">
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={RISK_TREND} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#6B7280", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#6B7280", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
              <Bar dataKey="critical" name="Critical" fill="#EF4444" radius={[2, 2, 0, 0]} opacity={0.85} />
              <Bar dataKey="high"     name="High"     fill="#F59E0B" radius={[2, 2, 0, 0]} opacity={0.85} />
              <Bar dataKey="medium"   name="Medium"   fill="#60A5FA" radius={[2, 2, 0, 0]} opacity={0.85} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Findings + Activity */}
      <div className="grid grid-cols-[1fr_340px] gap-4">
        {/* Critical findings table */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Critical Findings — Immediate Action Required</h2>
            <Link
              href="/dashboard/findings"
              className="flex items-center gap-1 text-xs font-medium text-[#3B82F6] transition-colors hover:text-[#60A5FA]"
            >
              View all <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full" role="grid" aria-label="Critical findings">
              <thead>
                <tr className="border-b border-[#1F2937]">
                  {["Finding", "CVSS", "Risk", "Asset", "Status"].map((h) => (
                    <th
                      key={h}
                      scope="col"
                      className="px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {TOP_FINDINGS.map((f, i) => (
                  <tr
                    key={i}
                    className="group cursor-pointer border-b border-[#1F2937] transition-colors hover:bg-[#141E2E] last:border-0"
                    role="row"
                  >
                    <td className="px-4 py-3">
                      <p className="text-[13px] font-medium text-[#F9FAFB] transition-colors group-hover:text-[#3B82F6]">
                        {f.title}
                      </p>
                    </td>
                    <td className="px-4 py-3">
                      <CvssPill score={f.cvss} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="font-tabular text-[13px] font-bold" style={{ color: "#EF4444" }}>
                          {f.score}
                        </span>
                        <div className="h-1 w-16 overflow-hidden rounded-full bg-[#1C2333]">
                          <div
                            className="h-full rounded-full bg-[#EF4444]"
                            style={{ width: `${f.score}%`, opacity: 0.7 }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-[11px] text-[#9CA3AF]">{f.asset}</span>
                    </td>
                    <td className="px-4 py-3">
                      <SeverityBadge severity={f.severity} dot />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Activity timeline */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Activity Timeline</h2>
            <span className="inline-flex items-center gap-1 rounded-full bg-[rgba(16,185,129,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#10B981]">
              <span className="h-1.5 w-1.5 rounded-full bg-[#10B981] animate-pulse-dot" />
              LIVE
            </span>
          </div>
          <div className="px-5 py-1">
            {recentNotifications.length > 0 ? (
              recentNotifications.map((n) => <ActivityItem key={n.id} notif={n} />)
            ) : (
              // Fallback demo data
              [
                { id: "1", title: "Critical finding detected — AWS key leaked", body: "", severity: "CRITICAL" as FindingSeverity, isRead: false, linkTo: null, createdAt: new Date(Date.now() - 2 * 60 * 1000).toISOString() },
                { id: "2", title: "Scan completed for api.acmecorp.com", body: "", severity: "INFO" as FindingSeverity, isRead: false, linkTo: null, createdAt: new Date(Date.now() - 14 * 60 * 1000).toISOString() },
                { id: "3", title: "New subdomain discovered — staging-v2.acmecorp.com", body: "", severity: "INFO" as FindingSeverity, isRead: false, linkTo: null, createdAt: new Date(Date.now() - 38 * 60 * 1000).toISOString() },
                { id: "4", title: "TLS cert expiring in 12 days — mail.acmecorp.com", body: "", severity: "HIGH" as FindingSeverity, isRead: true, linkTo: null, createdAt: new Date(Date.now() - 60 * 60 * 1000).toISOString() },
                { id: "5", title: "Finding resolved — Apache 2.2 on staging", body: "", severity: "LOW" as FindingSeverity, isRead: true, linkTo: null, createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString() },
                { id: "6", title: "Weekly digest sent to 3 team members", body: "", severity: "INFO" as FindingSeverity, isRead: true, linkTo: null, createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString() },
              ].map((n) => <ActivityItem key={n.id} notif={n} />)
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
