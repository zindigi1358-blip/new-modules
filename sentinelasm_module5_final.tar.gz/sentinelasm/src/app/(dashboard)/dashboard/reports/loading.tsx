import { PageSkeleton } from "@/components/ui/Skeletons";
export default function ReportsLoading() { return <PageSkeleton />; }
