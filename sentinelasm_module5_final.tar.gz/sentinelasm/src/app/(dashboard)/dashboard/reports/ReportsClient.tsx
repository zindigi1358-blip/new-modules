"use client";

import { useState } from "react";
import { FileText, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { cn, formatDate, formatBytes } from "@/lib/utils";
import { NoReportsEmpty } from "@/components/ui/EmptyStates";

const REPORT_TYPES = [
  { value: "FULL_PENTEST",      label: "Full Pentest Report",  desc: "All modules — exec + technical", color: "#EF4444" },
  { value: "EXECUTIVE_SUMMARY", label: "Executive Summary",    desc: "Non-technical language",          color: "#3B82F6" },
  { value: "RISK_ONLY",         label: "Risk Report",          desc: "CVEs + risk scores only",         color: "#F59E0B" },
  { value: "COMPLIANCE",        label: "Compliance Report",    desc: "SOC2 / ISO 27001 aligned",        color: "#10B981" },
];

const TYPE_COLORS: Record<string, string> = {
  FULL_PENTEST:      "#EF4444",
  EXECUTIVE_SUMMARY: "#3B82F6",
  RISK_ONLY:         "#F59E0B",
  COMPLIANCE:        "#10B981",
  WEEKLY_DIGEST:     "#9CA3AF",
};

const DEMO_REPORTS = [
  { id: "r1", title: "acmecorp.com — Full Pentest Report", reportType: "FULL_PENTEST",      createdAt: new Date(Date.now() - 2 * 3600 * 1000),      fileSizeBytes: 249000 },
  { id: "r2", title: "acmecorp.com — Executive Summary",   reportType: "EXECUTIVE_SUMMARY", createdAt: new Date(Date.now() - 24 * 3600 * 1000),      fileSizeBytes: 89000  },
  { id: "r3", title: "api.acmecorp.com — Risk Report",     reportType: "RISK_ONLY",         createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000),  fileSizeBytes: 112000 },
  { id: "r4", title: "Monthly Digest — June 2026",         reportType: "WEEKLY_DIGEST",     createdAt: new Date(Date.now() - 7 * 24 * 3600 * 1000),  fileSizeBytes: 195000 },
];

export function ReportsClient({ reports, domains }: { reports: any[]; domains: any[] }) {
  const [selectedType, setSelectedType] = useState("FULL_PENTEST");
  const [clientName,   setClientName]   = useState("");
  const [assessor,     setAssessor]     = useState("");
  const [generating,   setGenerating]   = useState(false);

  const displayReports = reports.length > 0 ? reports : DEMO_REPORTS;

  const handleGenerate = async () => {
    if (!clientName.trim()) { toast.error("Enter a client name"); return; }
    setGenerating(true);
    try {
      const res = await fetch("/api/reports", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ reportType: selectedType, clientName, assessorName: assessor || "SentinelASM Security" }),
      });
      const j = await res.json();
      if (!res.ok) { toast.error(j.error ?? "Failed to generate report"); return; }
      toast.success("Report generated successfully!");
    } catch { toast.error("Network error"); }
    finally { setGenerating(false); }
  };

  return (
    <div className="animate-fade-in space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">Reports</h1>
        <p className="mt-1 text-sm text-[var(--text-muted)]">Generate professional penetration testing reports</p>
      </div>

      <div className="grid grid-cols-[1fr_320px] gap-5">
        {/* Generator */}
        <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="text-sm font-semibold text-[var(--text-primary)]">Generate New Report</h2>
            <p className="text-xs text-[var(--text-muted)]">Powered by Module 4 — PDF report engine</p>
          </div>
          <div className="space-y-5 p-5">
            {/* Type selector */}
            <div>
              <p className="mb-2.5 text-xs font-medium text-[var(--text-muted)]">Report Type</p>
              <div className="grid grid-cols-2 gap-2.5">
                {REPORT_TYPES.map((t) => (
                  <div
                    key={t.value}
                    onClick={() => setSelectedType(t.value)}
                    className={cn(
                      "flex cursor-pointer items-center gap-3 rounded-lg border p-3 transition-all",
                      selectedType === t.value
                        ? "border-[rgba(59,130,246,0.4)] bg-[rgba(59,130,246,0.06)]"
                        : "border-[var(--border)] hover:border-[var(--border-light)]"
                    )}
                  >
                    <div className={cn(
                      "flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full border-2",
                      selectedType === t.value ? "border-[#3B82F6]" : "border-[var(--border-light)]"
                    )}>
                      {selectedType === t.value && <div className="h-2 w-2 rounded-full bg-[#3B82F6]" />}
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-[var(--text-primary)]">{t.label}</p>
                      <p className="text-[10px] text-[var(--text-muted)]">{t.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Client name */}
            <div>
              <label htmlFor="client-name-input" className="mb-1.5 block text-xs font-medium text-[var(--text-muted)]">
                Client Name *
              </label>
              <input
                id="client-name-input"
                type="text"
                value={clientName}
                onChange={e => setClientName(e.target.value)}
                placeholder="Acme Corp"
                className="w-full rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-3 py-2 text-sm text-[var(--text-primary)] placeholder-[var(--text-faint)] outline-none focus:border-[#3B82F6]"
              />
            </div>

            {/* Assessor */}
            <div>
              <label className="mb-1.5 block text-xs font-medium text-[var(--text-muted)]">Prepared By (Assessor)</label>
              <input
                type="text"
                value={assessor}
                onChange={e => setAssessor(e.target.value)}
                placeholder="Your Security Firm Name"
                className="w-full rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-3 py-2 text-sm text-[var(--text-primary)] placeholder-[var(--text-faint)] outline-none focus:border-[#3B82F6]"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={generating}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#3B82F6] py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60"
            >
              {generating
                ? <><Loader2 className="h-4 w-4 animate-spin" /> Generating PDF…</>
                : <><FileText className="h-4 w-4" /> Generate PDF Report</>}
            </button>

            <p className="text-center text-[11px] text-[var(--text-muted)]">
              Includes executive summary, technical findings, remediation roadmap, and CVE appendix.
            </p>
          </div>
        </div>

        {/* Recent reports */}
        <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
          <div className="border-b border-[var(--border)] px-5 py-4">
            <h2 className="text-sm font-semibold text-[var(--text-primary)]">Recent Reports</h2>
          </div>
          {displayReports.length === 0 ? (
            <NoReportsEmpty />
          ) : (
            <div className="divide-y divide-[var(--border)]">
              {displayReports.map((r: any) => (
                <div key={r.id}
                  className="flex cursor-pointer items-center gap-3 px-4 py-3.5 transition-colors hover:bg-[var(--bg-elevated)]">
                  <div
                    className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg"
                    style={{ background: `${TYPE_COLORS[r.reportType] ?? "#9CA3AF"}18` }}
                  >
                    <FileText className="h-4 w-4" style={{ color: TYPE_COLORS[r.reportType] ?? "#9CA3AF" }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-medium text-[var(--text-primary)]">{r.title}</p>
                    <p className="text-[11px] text-[var(--text-muted)]">
                      {formatDate(r.createdAt)} · {formatBytes(r.fileSizeBytes ?? 0)}
                    </p>
                  </div>
                  <button
                    className="flex-shrink-0 rounded-lg border border-[var(--border)] px-2.5 py-1.5 text-[11px] font-medium text-[var(--text-muted)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
                    title="Download PDF"
                    onClick={e => e.stopPropagation()}
                  >
                    <Download className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
