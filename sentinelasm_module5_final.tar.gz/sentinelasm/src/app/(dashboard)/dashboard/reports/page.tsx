// src/app/(dashboard)/dashboard/reports/page.tsx
import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { ReportsClient } from "./ReportsClient";
export const metadata: Metadata = { title: "Reports" };

export default async function ReportsPage() {
  const session = await requireSession();
  const reports = await db.report.findMany({
    where:   { organizationId: session.orgId },
    orderBy: { createdAt: "desc" },
    take:    20,
  });
  const domains = await db.monitoredDomain.findMany({
    where:  { organizationId: session.orgId, isActive: true },
    select: { id: true, domain: true },
  });
  return <ReportsClient reports={reports} domains={domains} />;
}
