"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Save, TestTube2, Bell, Mail, MessageSquare, Webhook } from "lucide-react";
import { cn } from "@/lib/utils";

function Toggle({ on, onToggle, label }: { on: boolean; onToggle: () => void; label?: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} onClick={onToggle}
      className={cn("relative h-5 w-9 flex-shrink-0 rounded-full border transition-all",
        on ? "border-[#3B82F6] bg-[#3B82F6]" : "border-[var(--border-light)] bg-[var(--bg-elevated)]")}>
      <span className={cn("absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-transform",
        on ? "left-[18px]" : "left-0.5")} />
    </button>
  );
}

function SeverityRow({ label, color, on, onToggle, desc }: {
  label: string; color: string; on: boolean; onToggle: () => void; desc: string
}) {
  return (
    <div className="flex items-center justify-between border-b border-[var(--border)] py-3.5 last:border-0">
      <div className="flex items-center gap-3">
        <span className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-bold"
          style={{ background: `${color}18`, color }}>{label}</span>
        <span className="text-sm text-[var(--text-muted)]">{desc}</span>
      </div>
      <Toggle on={on} onToggle={onToggle} label={`Toggle ${label} alerts`} />
    </div>
  );
}

export function NotificationsClient({ configs }: { configs: any[] }) {
  const [discord,    setDiscord]    = useState({ enabled: true,  url: "https://discord.com/api/webhooks/1234567890/demo_token" });
  const [slack,      setSlack]      = useState({ enabled: true,  url: "https://hooks.slack.com/services/T00/B00/demo" });
  const [email,      setEmail]      = useState({ enabled: true,  recipients: "ali.raza@acmecorp.com, soc@acmecorp.com" });
  const [customWh,   setCustomWh]   = useState({ enabled: false, url: "" });
  const [severities, setSeverities] = useState({ CRITICAL: true, HIGH: true, MEDIUM: true, LOW: false });
  const [schedule,   setSchedule]   = useState({ daily: true, weekly: true, scanDone: true, newAsset: true });
  const [testing,    setTesting]    = useState<string | null>(null);
  const [saving,     setSaving]     = useState(false);

  const handleTest = async (channel: string) => {
    setTesting(channel);
    await new Promise(r => setTimeout(r, 1400));
    toast.success(`Test alert sent to ${channel}`);
    setTesting(null);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch("/api/alert-configs", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify([
          { channel: "DISCORD", isEnabled: discord.enabled, minSeverity: "HIGH",   webhookUrl: discord.url, sendOnFindings: true, sendDailyDigest: schedule.daily, sendWeeklyReport: schedule.weekly, sendOnScanDone: schedule.scanDone, sendOnNewAsset: schedule.newAsset },
          { channel: "SLACK",   isEnabled: slack.enabled,   minSeverity: "HIGH",   webhookUrl: slack.url,   sendOnFindings: true, sendDailyDigest: schedule.daily, sendWeeklyReport: schedule.weekly, sendOnScanDone: schedule.scanDone, sendOnNewAsset: schedule.newAsset },
          { channel: "EMAIL",   isEnabled: email.enabled,   minSeverity: "MEDIUM", emailRecipients: email.recipients.split(",").map(e => e.trim()), sendOnFindings: true, sendDailyDigest: schedule.daily, sendWeeklyReport: schedule.weekly, sendOnScanDone: schedule.scanDone, sendOnNewAsset: schedule.newAsset },
        ]),
      });
      toast.success("Notification preferences saved");
    } catch { toast.error("Failed to save preferences"); }
    finally { setSaving(false); }
  };

  const inputCls = "w-full rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-3 py-2 text-sm text-[var(--text-primary)] placeholder-[var(--text-faint)] outline-none focus:border-[#3B82F6] disabled:opacity-40";

  type Channel = { enabled: boolean; icon: React.ElementType; iconColor: string; iconBg: string; label: string; desc: string; testKey: string; urlValue: string; setUrl: (u: string) => void; toggle: () => void; extraField?: React.ReactNode };

  const channels: Channel[] = [
    { enabled: discord.enabled, icon: MessageSquare, iconColor: "#5865F2", iconBg: "rgba(88,101,242,0.15)", label: "Discord",        desc: "Rich embeds with severity colors",  testKey: "Discord", urlValue: discord.url, setUrl: (u) => setDiscord(d => ({...d, url: u})), toggle: () => setDiscord(d => ({...d, enabled: !d.enabled})) },
    { enabled: slack.enabled,   icon: MessageSquare, iconColor: "#E01E5A", iconBg: "rgba(74,21,75,0.2)",    label: "Slack",          desc: "Incoming webhook integration",      testKey: "Slack",   urlValue: slack.url,   setUrl: (u) => setSlack(s => ({...s, url: u})),    toggle: () => setSlack(s => ({...s, enabled: !s.enabled})) },
    { enabled: email.enabled,   icon: Mail,          iconColor: "#3B82F6", iconBg: "rgba(59,130,246,0.1)",  label: "Email",          desc: "Instant alerts + daily digest",     testKey: "Email",   urlValue: email.recipients, setUrl: (u) => setEmail(em => ({...em, recipients: u})), toggle: () => setEmail(e => ({...e, enabled: !e.enabled})),
      extraField: <label className="mb-1.5 block text-xs font-medium text-[var(--text-muted)]">Recipients (comma-separated)</label> },
    { enabled: customWh.enabled,icon: Webhook,       iconColor: "#9CA3AF", iconBg: "rgba(107,114,128,0.1)", label: "Custom Webhook", desc: "Generic JSON to any endpoint",      testKey: "Webhook", urlValue: customWh.url,setUrl: (u) => setCustomWh(w => ({...w, url: u})), toggle: () => setCustomWh(w => ({...w, enabled: !w.enabled})) },
  ];

  return (
    <div className="animate-fade-in space-y-5">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">Notifications</h1>
          <p className="mt-1 text-sm text-[var(--text-muted)]">Configure alerts across Discord, Slack, email, and webhooks</p>
        </div>
        <button onClick={handleSave} disabled={saving}
          className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-60">
          {saving
            ? <><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" /> Saving…</>
            : <><Save className="h-3.5 w-3.5" /> Save Preferences</>}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-5">
        {/* Left — channels */}
        <div className="space-y-4">
          {channels.map((ch) => {
            const Icon = ch.icon;
            return (
              <div key={ch.label} className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
                <div className="flex items-center justify-between border-b border-[var(--border)] px-5 py-4">
                  <div className="flex items-center gap-2.5">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: ch.iconBg }}>
                      <Icon className="h-4 w-4" style={{ color: ch.iconColor }} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-[var(--text-primary)]">{ch.label}</p>
                      <p className="text-xs text-[var(--text-muted)]">{ch.desc}</p>
                    </div>
                  </div>
                  <Toggle on={ch.enabled} onToggle={ch.toggle} label={`Toggle ${ch.label}`} />
                </div>
                {(ch.enabled || ch.label === "Custom Webhook") && (
                  <div className="space-y-3 p-5">
                    <div>
                      {ch.extraField ?? (
                        <label className="mb-1.5 block text-xs font-medium text-[var(--text-muted)]">
                          {ch.label === "Email" ? "Recipients (comma-separated)" : "Webhook URL"}
                        </label>
                      )}
                      <input
                        type={ch.label === "Email" ? "text" : "url"}
                        value={ch.urlValue}
                        onChange={e => ch.setUrl(e.target.value)}
                        disabled={!ch.enabled}
                        placeholder={ch.label === "Email" ? "security@company.com" : `https://…`}
                        className={inputCls}
                      />
                    </div>
                    {ch.label !== "Custom Webhook" && (
                      <button
                        onClick={() => handleTest(ch.testKey)}
                        disabled={!ch.enabled || testing === ch.testKey}
                        className="flex h-7 items-center gap-1.5 rounded-lg border border-[var(--border)] px-3 text-xs font-medium text-[var(--text-muted)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)] disabled:opacity-40"
                      >
                        {testing === ch.testKey
                          ? <span className="h-3 w-3 animate-spin rounded-full border border-current border-t-transparent" />
                          : <TestTube2 className="h-3 w-3" />}
                        Send Test {ch.label === "Email" ? "Email" : "Alert"}
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right — severity + schedule */}
        <div className="space-y-4">
          <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
            <div className="border-b border-[var(--border)] px-5 py-4">
              <h2 className="text-sm font-semibold text-[var(--text-primary)]">Alert Severity Thresholds</h2>
              <p className="text-xs text-[var(--text-muted)]">Which findings trigger immediate alerts</p>
            </div>
            <div className="px-5">
              <SeverityRow label="CRITICAL" color="#EF4444" on={severities.CRITICAL} desc="Alert immediately via all channels" onToggle={() => setSeverities(s => ({...s, CRITICAL: !s.CRITICAL}))} />
              <SeverityRow label="HIGH"     color="#F59E0B" on={severities.HIGH}     desc="Alert within 1 hour"               onToggle={() => setSeverities(s => ({...s, HIGH:     !s.HIGH}))} />
              <SeverityRow label="MEDIUM"   color="#60A5FA" on={severities.MEDIUM}   desc="Include in daily digest"           onToggle={() => setSeverities(s => ({...s, MEDIUM:   !s.MEDIUM}))} />
              <SeverityRow label="LOW"      color="#10B981" on={severities.LOW}      desc="Weekly digest only"                onToggle={() => setSeverities(s => ({...s, LOW:      !s.LOW}))} />
            </div>
          </div>

          <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
            <div className="border-b border-[var(--border)] px-5 py-4">
              <h2 className="text-sm font-semibold text-[var(--text-primary)]">Digest Schedule</h2>
            </div>
            <div className="px-5">
              {([
                { key: "daily",    label: "Daily Digest",         desc: "Every morning at 08:00"     },
                { key: "weekly",   label: "Weekly Report",        desc: "Every Monday at 08:00"      },
                { key: "scanDone", label: "Scan Completions",     desc: "When each scan finishes"    },
                { key: "newAsset", label: "New Asset Discovered", desc: "Alert on new subdomains/IPs"},
              ] as const).map(({ key, label, desc }) => (
                <div key={key} className="flex items-center justify-between border-b border-[var(--border)] py-3.5 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-[var(--text-primary)]">{label}</p>
                    <p className="text-xs text-[var(--text-muted)]">{desc}</p>
                  </div>
                  <Toggle on={schedule[key]} onToggle={() => setSchedule(s => ({...s, [key]: !s[key]}))} label={`Toggle ${label}`} />
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-[rgba(239,68,68,0.3)] bg-[rgba(239,68,68,0.05)] p-4">
            <div className="flex items-start gap-3">
              <Bell className="mt-0.5 h-4 w-4 flex-shrink-0 text-[#EF4444]" />
              <div>
                <p className="text-sm font-semibold text-[var(--text-primary)]">KEV Instant Alerts — Always On</p>
                <p className="mt-1 text-xs leading-relaxed text-[var(--text-muted)]">
                  CISA Known Exploited Vulnerabilities are always alerted immediately regardless of severity threshold — actively exploited in the wild, same-day response required.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
