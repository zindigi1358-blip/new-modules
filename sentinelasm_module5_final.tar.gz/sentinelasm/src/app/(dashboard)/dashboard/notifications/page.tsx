import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { NotificationsClient } from "./NotificationsClient";

export const metadata: Metadata = { title: "Notifications" };

export default async function NotificationsPage() {
  const session = await requireSession();

  const configs = await db.alertConfig.findMany({
    where: { organizationId: session.orgId },
  });

  return <NotificationsClient configs={configs} />;
}
