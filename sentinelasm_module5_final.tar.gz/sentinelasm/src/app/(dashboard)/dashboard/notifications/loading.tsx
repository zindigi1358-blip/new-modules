import { PageSkeleton } from "@/components/ui/Skeletons";
export default function NotificationsLoading() { return <PageSkeleton />; }
