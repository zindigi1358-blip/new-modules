import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { TeamClient } from "./TeamClient";

export const metadata: Metadata = { title: "Team" };

export default async function TeamPage() {
  const session = await requireSession();

  const [members, invitations] = await Promise.all([
    db.organizationMember.findMany({
      where:   { organizationId: session.orgId },
      include: { user: { select: { id: true, name: true, email: true, avatarUrl: true, lastLoginAt: true } } },
      orderBy: { joinedAt: "asc" },
    }),
    db.invitation.findMany({
      where:   { organizationId: session.orgId, acceptedAt: null, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  return (
    <TeamClient
      members={members}
      invitations={invitations}
      currentUserId={session.userId}
      currentRole={session.role}
    />
  );
}
