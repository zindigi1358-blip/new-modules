"use client";

import { useState } from "react";
import { toast } from "sonner";
import { UserPlus, Send, X, Check, ChevronDown, Shield } from "lucide-react";
import { cn, initials, avatarColor, timeAgo, formatDate } from "@/lib/utils";
import type { MemberRole } from "@/types";

interface Member {
  id: string; role: MemberRole; joinedAt: Date;
  user: { id: string; name: string; email: string; avatarUrl: string | null; lastLoginAt: Date | null };
}
interface Invitation { id: string; email: string; role: MemberRole; expiresAt: Date; createdAt: Date }

interface TeamClientProps {
  members:       Member[];
  invitations:   Invitation[];
  currentUserId: string;
  currentRole:   MemberRole;
}

const ROLE_STYLES: Record<MemberRole, { label: string; color: string; bg: string }> = {
  OWNER:   { label: "Owner",   color: "#8B5CF6", bg: "rgba(139,92,246,0.1)" },
  ADMIN:   { label: "Admin",   color: "#3B82F6", bg: "rgba(59,130,246,0.1)"  },
  ANALYST: { label: "Analyst", color: "#10B981", bg: "rgba(16,185,129,0.1)"  },
  VIEWER:  { label: "Viewer",  color: "#6B7280", bg: "rgba(107,114,128,0.1)" },
};

const DEMO_MEMBERS: Member[] = [
  { id:"m1", role:"OWNER",   joinedAt: new Date("2026-01-01"), user:{ id:"u1", name:"Sara Khan",     email:"sara.khan@acmecorp.com",    avatarUrl:null, lastLoginAt: new Date(Date.now()-30*60*1000) }},
  { id:"m2", role:"ADMIN",   joinedAt: new Date("2026-01-15"), user:{ id:"u2", name:"Ahmed Hassan",  email:"a.hassan@acmecorp.com",     avatarUrl:null, lastLoginAt: new Date(Date.now()-2*3600*1000) }},
  { id:"m3", role:"ANALYST", joinedAt: new Date("2026-02-01"), user:{ id:"u3", name:"Ali Raza",      email:"ali.raza@acmecorp.com",     avatarUrl:null, lastLoginAt: new Date(Date.now()-14*60*1000) }},
  { id:"m4", role:"ANALYST", joinedAt: new Date("2026-03-10"), user:{ id:"u4", name:"Zara Farooq",   email:"z.farooq@acmecorp.com",     avatarUrl:null, lastLoginAt: new Date(Date.now()-24*3600*1000) }},
  { id:"m5", role:"VIEWER",  joinedAt: new Date("2026-05-20"), user:{ id:"u5", name:"Usman Malik",   email:"u.malik@acmecorp.com",      avatarUrl:null, lastLoginAt: new Date(Date.now()-3*24*3600*1000) }},
];

const DEMO_INVITATIONS: Invitation[] = [
  { id:"i1", email:"bilal@acmecorp.com", role:"ANALYST", expiresAt: new Date(Date.now()+5*86400*1000), createdAt: new Date(Date.now()-2*86400*1000) },
  { id:"i2", email:"nadia@acmecorp.com", role:"VIEWER",  expiresAt: new Date(Date.now()+7*86400*1000), createdAt: new Date(Date.now()-30*60*1000) },
];

const PERMISSIONS = [
  { label: "View Dashboard & Reports", owner:true, admin:true, analyst:true, viewer:true },
  { label: "Run & Cancel Scans",       owner:true, admin:true, analyst:true, viewer:false },
  { label: "Manage Findings",          owner:true, admin:true, analyst:true, viewer:false },
  { label: "Generate PDF Reports",     owner:true, admin:true, analyst:true, viewer:false },
  { label: "Manage API Keys",          owner:true, admin:true, analyst:false, viewer:false },
  { label: "Invite Team Members",      owner:true, admin:true, analyst:false, viewer:false },
  { label: "Change Member Roles",      owner:true, admin:false,analyst:false, viewer:false },
  { label: "Billing & Plans",          owner:true, admin:false,analyst:false, viewer:false },
  { label: "Delete Organization",      owner:true, admin:false,analyst:false, viewer:false },
];

function InviteModal({ onClose }: { onClose: () => void }) {
  const [email,    setEmail]    = useState("");
  const [role,     setRole]     = useState<MemberRole>("ANALYST");
  const [sending,  setSending]  = useState(false);

  const handleInvite = async () => {
    if (!email.trim()) { toast.error("Enter an email address"); return; }
    setSending(true);
    try {
      const res = await fetch("/api/team/invite", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ email, role }),
      });
      const j = await res.json();
      if (!res.ok) { toast.error(j.error ?? "Failed to send invitation"); return; }
      toast.success(`Invitation sent to ${email}`);
      onClose();
    } catch { toast.error("Network error"); }
    finally { setSending(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md rounded-2xl border border-[#1F2937] bg-[#111827] p-6 shadow-2xl">
        <h2 className="mb-5 text-base font-semibold text-[#F9FAFB]">Invite Team Member</h2>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Email Address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)}
              placeholder="colleague@company.com" autoFocus
              className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6]" />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Role</label>
            <div className="grid grid-cols-2 gap-2">
              {(["ANALYST","ADMIN","VIEWER","OWNER"] as MemberRole[]).map(r => {
                const s = ROLE_STYLES[r]!;
                return (
                  <button key={r} onClick={() => setRole(r)}
                    className={cn("rounded-lg border py-2.5 text-xs font-semibold transition-all",
                      role === r ? "border-[rgba(59,130,246,0.4)]" : "border-[#1F2937] hover:border-[#374151]"
                    )}
                    style={role === r ? { background: `${s.bg}`, color: s.color } : {}}>
                    {s.label}
                  </button>
                );
              })}
            </div>
          </div>
          <p className="text-xs text-[#6B7280]">
            They'll receive an email invitation valid for 7 days.
          </p>
          <div className="flex gap-2 pt-1">
            <button onClick={onClose} className="flex-1 rounded-lg border border-[#1F2937] py-2 text-sm font-medium text-[#9CA3AF] hover:border-[#374151] hover:text-[#F9FAFB]">Cancel</button>
            <button onClick={handleInvite} disabled={sending}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-[#3B82F6] py-2 text-sm font-semibold text-white hover:bg-[#1D4ED8] disabled:opacity-60">
              {sending ? "Sending…" : <><Send className="h-3.5 w-3.5" /> Send Invite</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TeamClient({ members, invitations, currentUserId }: TeamClientProps) {
  const [showInvite, setShowInvite] = useState(false);
  const displayMembers = members.length > 0 ? members : DEMO_MEMBERS;
  const displayInvites = invitations.length > 0 ? invitations : DEMO_INVITATIONS;

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Team</h1>
          <p className="mt-1 text-sm text-[#6B7280]">
            {displayMembers.length} members · {displayInvites.length} pending invitation{displayInvites.length !== 1 ? "s" : ""}
          </p>
        </div>
        <button onClick={() => setShowInvite(true)}
          className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white hover:bg-[#1D4ED8]">
          <UserPlus className="h-3.5 w-3.5" /> Invite Member
        </button>
      </div>

      <div className="grid grid-cols-[1fr_300px] gap-5">
        <div className="space-y-4">
          {/* Active members */}
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
              <h2 className="text-sm font-semibold text-[#F9FAFB]">Members</h2>
              <span className="rounded-full bg-[#1C2333] px-2 py-0.5 text-[10px] font-semibold text-[#6B7280]">
                {displayMembers.length} active
              </span>
            </div>
            <div className="divide-y divide-[#1F2937]">
              {displayMembers.map((m) => {
                const rs = ROLE_STYLES[m.role]!;
                const isCurrentUser = m.user.id === currentUserId || m.id === "m3";
                const grad = avatarColor(m.user.id);
                return (
                  <div key={m.id} className="flex items-center gap-3 px-5 py-3.5 transition-colors hover:bg-[#141E2E]">
                    <div className={cn("flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-xs font-bold text-white", grad)}>
                      {initials(m.user.name)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-semibold text-[#F9FAFB]">{m.user.name}</p>
                        {isCurrentUser && <span className="text-[10px] text-[#6B7280]">(you)</span>}
                      </div>
                      <p className="text-xs text-[#6B7280]">{m.user.email}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <p className="text-xs text-[#6B7280]">
                        {m.user.lastLoginAt ? timeAgo(m.user.lastLoginAt) : "Never"}
                      </p>
                      <span className="rounded px-2 py-0.5 text-[11px] font-bold"
                        style={{ background: rs.bg, color: rs.color }}>
                        {rs.label}
                      </span>
                      {!isCurrentUser && (
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] transition-colors hover:bg-[rgba(239,68,68,0.1)] hover:text-[#EF4444]">
                          <X className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pending invitations */}
          {displayInvites.length > 0 && (
            <div className="rounded-xl border border-[rgba(245,158,11,0.2)] bg-[#111827]">
              <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
                <h2 className="text-sm font-semibold text-[#F9FAFB]">Pending Invitations</h2>
                <span className="rounded-full bg-[rgba(245,158,11,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#F59E0B]">
                  {displayInvites.length} pending
                </span>
              </div>
              <div className="divide-y divide-[#1F2937]">
                {displayInvites.map((inv) => {
                  const rs = ROLE_STYLES[inv.role]!;
                  const daysLeft = Math.ceil((inv.expiresAt.getTime() - Date.now()) / 86400000);
                  return (
                    <div key={inv.id} className="flex items-center gap-3 px-5 py-3.5">
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-[#1C2333] text-xs font-bold text-[#6B7280]">?</div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-[#9CA3AF]">{inv.email}</p>
                        <p className="text-xs text-[#6B7280]">
                          Invited {timeAgo(inv.createdAt)} · expires in {daysLeft} day{daysLeft !== 1 ? "s" : ""}
                        </p>
                      </div>
                      <span className="rounded px-2 py-0.5 text-[11px] font-bold"
                        style={{ background: rs.bg, color: rs.color }}>
                        {rs.label}
                      </span>
                      <div className="flex gap-1.5">
                        <button className="h-7 rounded border border-[#1F2937] px-2 text-xs text-[#6B7280] hover:border-[#374151] hover:text-[#F9FAFB]">
                          Resend
                        </button>
                        <button className="h-7 rounded border border-[#1F2937] px-2 text-xs text-[#EF4444] hover:border-[rgba(239,68,68,0.3)]">
                          Cancel
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Permissions table */}
        <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
          <div className="flex items-center gap-2 border-b border-[#1F2937] px-5 py-4">
            <Shield className="h-4 w-4 text-[#6B7280]" />
            <h2 className="text-sm font-semibold text-[#F9FAFB]">Role Permissions</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-[#1F2937]">
                  <th className="px-4 py-2.5 text-left font-medium text-[#6B7280]">Permission</th>
                  {(["Owner","Admin","Analyst","Viewer"] as const).map(r => (
                    <th key={r} className="px-2 py-2.5 text-center font-medium text-[#6B7280]">{r}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PERMISSIONS.map((p) => (
                  <tr key={p.label} className="border-b border-[#1F2937] last:border-0">
                    <td className="px-4 py-2 text-[#9CA3AF]">{p.label}</td>
                    {([p.owner, p.admin, p.analyst, p.viewer] as boolean[]).map((has, i) => (
                      <td key={i} className="px-2 py-2 text-center">
                        {has
                          ? <Check className="mx-auto h-3.5 w-3.5 text-[#10B981]" />
                          : <X className="mx-auto h-3.5 w-3.5 text-[#374151]" />}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {showInvite && <InviteModal onClose={() => setShowInvite(false)} />}
    </div>
  );
}
