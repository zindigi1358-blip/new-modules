import { PageSkeleton } from "@/components/ui/Skeletons";
export default function TeamLoading() { return <PageSkeleton />; }
