import type { Metadata } from "next";
import { requireSession, requireRole } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { BillingClient } from "./BillingClient";

export const metadata: Metadata = { title: "Billing" };

export default async function BillingPage() {
  const session = await requireSession();
  try { requireRole(session.role, "OWNER"); } catch { redirect("/dashboard"); }

  const org = await db.organization.findUniqueOrThrow({
    where:  { id: session.orgId },
    select: {
      plan: true, planExpiresAt: true, stripeSubscriptionId: true,
      maxAssets: true, maxScansMonth: true, maxMembers: true,
    },
  });

  const [assetCount, scansThisMonth, memberCount] = await Promise.all([
    db.asset.count({ where: { organizationId: session.orgId } }),
    db.scan.count({
      where: {
        organizationId: session.orgId,
        createdAt:      { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
      },
    }),
    db.organizationMember.count({ where: { organizationId: session.orgId } }),
  ]);

  return (
    <BillingClient
      plan={org.plan}
      planExpiresAt={org.planExpiresAt}
      hasSubscription={!!org.stripeSubscriptionId}
      limits={{ maxAssets: org.maxAssets, maxScansMonth: org.maxScansMonth, maxMembers: org.maxMembers }}
      usage={{ assets: assetCount, scans: scansThisMonth, members: memberCount }}
    />
  );
}
