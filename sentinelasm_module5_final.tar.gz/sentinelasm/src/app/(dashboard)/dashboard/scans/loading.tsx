import { ScansSkeleton } from "@/components/ui/Skeletons";
export default function ScansLoading() {
  return <ScansSkeleton />;
}
