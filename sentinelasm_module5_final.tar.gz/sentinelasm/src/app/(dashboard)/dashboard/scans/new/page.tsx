// src/app/(dashboard)/dashboard/scans/new/page.tsx
import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: "New Scan" };

export default async function NewScanPage() {
  const session = await requireSession();

  const domains = await db.monitoredDomain.findMany({
    where:   { organizationId: session.orgId, isActive: true },
    select:  { id: true, domain: true },
    orderBy: { domain: "asc" },
  });

  // Redirect to scans page with ?new=true so the modal opens
  redirect("/dashboard/scans?new=true");
}
