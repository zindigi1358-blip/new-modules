import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { ScansClient } from "./ScansClient";

export const metadata: Metadata = { title: "Scans" };

export default async function ScansPage() {
  const session = await requireSession();

  const [running, queued, completed, domains] = await Promise.all([
    db.scan.count({ where: { organizationId: session.orgId, status: "RUNNING" } }),
    db.scan.count({ where: { organizationId: session.orgId, status: "QUEUED"  } }),
    db.scan.count({ where: { organizationId: session.orgId, status: "COMPLETED" } }),
    db.monitoredDomain.findMany({
      where:   { organizationId: session.orgId, isActive: true },
      select:  { id: true, domain: true },
      orderBy: { domain: "asc" },
    }),
  ]);

  return <ScansClient stats={{ running, queued, completed }} domains={domains} orgId={session.orgId} />;
}
