// src/app/(dashboard)/dashboard/loading.tsx
import { DashboardSkeleton } from "@/components/ui/Skeletons";
export default function DashboardLoading() {
  return <DashboardSkeleton />;
}
