import type { Metadata } from "next";
import { requireSession, requireRole } from "@/lib/auth";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { ApiKeysClient } from "./ApiKeysClient";

export const metadata: Metadata = { title: "API Keys" };

export default async function ApiKeysPage() {
  const session = await requireSession();
  try { requireRole(session.role, "ADMIN"); } catch { redirect("/dashboard"); }

  const keys = await db.apiKey.findMany({
    where:   { organizationId: session.orgId },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, name: true, keyPrefix: true, scopes: true,
      isActive: true, lastUsedAt: true, lastUsedIp: true,
      expiresAt: true, createdAt: true,
    },
  });

  const usageThisMonth = await db.auditLog.count({
    where: {
      organizationId: session.orgId,
      action:         "SCAN_STARTED",
      createdAt:      { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
    },
  });

  return <ApiKeysClient keys={keys} usageThisMonth={usageThisMonth} />;
}
