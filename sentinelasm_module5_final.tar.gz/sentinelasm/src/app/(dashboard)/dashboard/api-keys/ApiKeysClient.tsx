"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Plus, Copy, Eye, EyeOff, Trash2, Check, Key, Code2 } from "lucide-react";
import { cn, formatDate, timeAgo } from "@/lib/utils";

interface ApiKeyDisplay {
  id: string; name: string; keyPrefix: string; scopes: string[];
  isActive: boolean; lastUsedAt: Date | null; lastUsedIp: string | null;
  expiresAt: Date | null; createdAt: Date;
}

interface ApiKeysClientProps {
  keys:           ApiKeyDisplay[];
  usageThisMonth: number;
}

const ALL_SCOPES = [
  { value: "scan:read",     label: "scan:read",     desc: "View scan history and status" },
  { value: "scan:write",    label: "scan:write",    desc: "Start and cancel scans" },
  { value: "assets:read",   label: "assets:read",   desc: "Read asset inventory" },
  { value: "findings:read", label: "findings:read", desc: "Read findings and CVEs" },
  { value: "findings:write",label: "findings:write",desc: "Update finding status" },
  { value: "reports:read",  label: "reports:read",  desc: "Download reports" },
  { value: "reports:write", label: "reports:write", desc: "Generate reports" },
];

function CreateKeyModal({ onClose, onCreated }: { onClose: () => void; onCreated: (key: string, name: string) => void }) {
  const [name,      setName]      = useState("");
  const [scopes,    setScopes]    = useState<string[]>(["scan:read", "assets:read", "findings:read"]);
  const [expires,   setExpires]   = useState("never");
  const [creating,  setCreating]  = useState(false);

  const toggleScope = (s: string) =>
    setScopes(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const handleCreate = async () => {
    if (!name.trim()) { toast.error("Key name is required"); return; }
    if (scopes.length === 0) { toast.error("Select at least one scope"); return; }
    setCreating(true);
    try {
      const expiresAt = expires === "never" ? null :
        new Date(Date.now() + { "30d": 30, "90d": 90, "1y": 365 }[expires]! * 86400000).toISOString();
      const res = await fetch("/api/api-keys", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ name, scopes, expiresAt }),
      });
      const j = await res.json();
      if (!res.ok) { toast.error(j.error ?? "Failed to create key"); return; }
      onCreated(j.data.key, name);
    } catch { toast.error("Network error"); }
    finally { setCreating(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg rounded-2xl border border-[#1F2937] bg-[#111827] p-6 shadow-2xl">
        <h2 className="mb-5 text-base font-semibold text-[#F9FAFB]">Create API Key</h2>
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Key Name *</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)}
              placeholder="e.g. CI/CD Pipeline, Monitoring Dashboard"
              className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#4B5563] outline-none focus:border-[#3B82F6]" />
          </div>
          <div>
            <label className="mb-2 block text-xs font-medium text-[#9CA3AF]">Permissions</label>
            <div className="space-y-1.5">
              {ALL_SCOPES.map(s => (
                <label key={s.value} className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2 transition-colors hover:bg-[#1C2333]">
                  <div onClick={() => toggleScope(s.value)}
                    className={cn("flex h-4 w-4 flex-shrink-0 items-center justify-center rounded border transition-colors",
                      scopes.includes(s.value) ? "border-[#3B82F6] bg-[#3B82F6]" : "border-[#374151]"
                    )}>
                    {scopes.includes(s.value) && <Check className="h-3 w-3 text-white" />}
                  </div>
                  <div className="flex-1">
                    <span className="font-mono text-xs font-semibold text-[#F9FAFB]">{s.label}</span>
                    <span className="ml-2 text-xs text-[#6B7280]">{s.desc}</span>
                  </div>
                </label>
              ))}
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-[#9CA3AF]">Expiration</label>
            <div className="flex gap-2">
              {[["never","No expiry"],["30d","30 days"],["90d","90 days"],["1y","1 year"]].map(([v,l]) => (
                <button key={v} onClick={() => setExpires(v)}
                  className={cn("flex-1 rounded-lg border py-1.5 text-xs font-medium transition-colors",
                    expires === v ? "border-[rgba(59,130,246,0.4)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                                 : "border-[#1F2937] text-[#6B7280] hover:border-[#374151]"
                  )}>
                  {l}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 rounded-lg border border-[#1F2937] py-2 text-sm font-medium text-[#9CA3AF] hover:border-[#374151] hover:text-[#F9FAFB]">Cancel</button>
            <button onClick={handleCreate} disabled={creating}
              className="flex-1 rounded-lg bg-[#3B82F6] py-2 text-sm font-semibold text-white hover:bg-[#1D4ED8] disabled:opacity-60">
              {creating ? "Creating…" : "Create Key"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function NewKeyDisplay({ rawKey, name, onDismiss }: { rawKey: string; name: string; onDismiss: () => void }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(rawKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="rounded-xl border border-[rgba(16,185,129,0.3)] bg-[rgba(16,185,129,0.05)] p-5">
      <div className="mb-3 flex items-center gap-2">
        <Check className="h-4 w-4 text-[#10B981]" />
        <p className="text-sm font-semibold text-[#10B981]">API Key created — "{name}"</p>
      </div>
      <p className="mb-3 text-xs text-[#9CA3AF]">
        Copy this key now. For security reasons, it will never be shown again.
      </p>
      <div className="flex items-center gap-2 rounded-lg border border-[#1F2937] bg-[#0D1117] p-3">
        <code className="flex-1 break-all font-mono text-xs text-[#10B981]">{rawKey}</code>
        <button onClick={copy}
          className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded text-[#6B7280] transition-colors hover:text-[#F9FAFB]">
          {copied ? <Check className="h-3.5 w-3.5 text-[#10B981]" /> : <Copy className="h-3.5 w-3.5" />}
        </button>
      </div>
      <button onClick={onDismiss} className="mt-3 text-xs text-[#6B7280] hover:text-[#9CA3AF]">
        I've copied the key, dismiss this message →
      </button>
    </div>
  );
}

export function ApiKeysClient({ keys, usageThisMonth }: ApiKeysClientProps) {
  const [showCreate, setShowCreate] = useState(false);
  const [newKey,     setNewKey]     = useState<{ raw: string; name: string } | null>(null);
  const [revealed,   setRevealed]   = useState<Record<string, boolean>>({});

  const handleRevoke = async (id: string, name: string) => {
    if (!confirm(`Revoke "${name}"? This cannot be undone.`)) return;
    const res = await fetch(`/api/api-keys/${id}`, { method: "DELETE" });
    if (res.ok) toast.success(`Key "${name}" revoked`);
    else toast.error("Failed to revoke key");
  };

  const DEMO_KEYS: ApiKeyDisplay[] = keys.length > 0 ? keys : [
    { id: "k1", name: "CI/CD Pipeline",       keyPrefix: "sk_live_9xK2", scopes: ["scan:read","assets:read","findings:read"], isActive: true,  lastUsedAt: new Date(Date.now()-2*3600*1000),  lastUsedIp: "104.21.44.1", expiresAt: new Date(Date.now()+180*86400*1000), createdAt: new Date(Date.now()-10*86400*1000) },
    { id: "k2", name: "Monitoring Dashboard", keyPrefix: "sk_live_3pA7", scopes: ["assets:read","findings:read","reports:read"], isActive: true, lastUsedAt: new Date(Date.now()-24*3600*1000), lastUsedIp: "203.0.113.45", expiresAt: null, createdAt: new Date(Date.now()-25*86400*1000) },
    { id: "k3", name: "Read-only Integration",keyPrefix: "sk_live_7wX1", scopes: ["assets:read"], isActive: false, lastUsedAt: null, lastUsedIp: null, expiresAt: new Date(Date.now()+365*86400*1000), createdAt: new Date(Date.now()-70*86400*1000) },
  ];

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">API Keys</h1>
          <p className="mt-1 text-sm text-[#6B7280]">Integrate SentinelASM into your CI/CD pipeline and tooling</p>
        </div>
        <button onClick={() => setShowCreate(true)}
          className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white hover:bg-[#1D4ED8]">
          <Plus className="h-3.5 w-3.5" /> Create API Key
        </button>
      </div>

      {newKey && (
        <NewKeyDisplay rawKey={newKey.raw} name={newKey.name} onDismiss={() => setNewKey(null)} />
      )}

      <div className="grid grid-cols-[1fr_300px] gap-5">
        {/* Keys list */}
        <div className="space-y-3">
          {DEMO_KEYS.map((key) => (
            <div key={key.id} className={cn(
              "rounded-xl border bg-[#111827] p-5 transition-colors",
              key.isActive ? "border-[#1F2937]" : "border-[#1F2937] opacity-60"
            )}>
              <div className="mb-4 flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className={cn("mt-0.5 flex h-8 w-8 items-center justify-center rounded-lg",
                    key.isActive ? "bg-[rgba(59,130,246,0.1)]" : "bg-[#1C2333]"
                  )}>
                    <Key className={cn("h-4 w-4", key.isActive ? "text-[#3B82F6]" : "text-[#6B7280]")} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#F9FAFB]">{key.name}</p>
                    <p className="text-xs text-[#6B7280]">
                      Created {formatDate(key.createdAt)}
                      {key.expiresAt ? ` · Expires ${formatDate(key.expiresAt)}` : " · No expiry"}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold",
                    key.isActive ? "bg-[rgba(16,185,129,0.1)] text-[#10B981]" : "bg-[#1C2333] text-[#6B7280]"
                  )}>
                    {key.isActive ? "Active" : "Inactive"}
                  </span>
                  <button onClick={() => handleRevoke(key.id, key.name)}
                    className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] transition-colors hover:bg-[rgba(239,68,68,0.1)] hover:text-[#EF4444]">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Key display */}
              <div className="mb-3 flex items-center gap-2 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2">
                <code className="flex-1 font-mono text-xs text-[#9CA3AF]">
                  {revealed[key.id]
                    ? `${key.keyPrefix}••••••••••••••••••••`
                    : `${key.keyPrefix}${"•".repeat(24)}`}
                </code>
                <button onClick={() => setRevealed(r => ({ ...r, [key.id]: !r[key.id] }))}
                  className="text-[#6B7280] hover:text-[#9CA3AF]">
                  {revealed[key.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
                <button onClick={() => { navigator.clipboard.writeText(key.keyPrefix + "…"); toast.success("Key prefix copied"); }}
                  className="text-[#6B7280] hover:text-[#9CA3AF]">
                  <Copy className="h-3.5 w-3.5" />
                </button>
              </div>

              {/* Scopes */}
              <div className="mb-3 flex flex-wrap gap-1.5">
                {key.scopes.map(s => (
                  <span key={s} className="rounded bg-[#1C2333] px-2 py-0.5 font-mono text-[10px] text-[#9CA3AF]">{s}</span>
                ))}
              </div>

              <p className="text-xs text-[#6B7280]">
                Last used: <span className="text-[#9CA3AF]">{key.lastUsedAt ? timeAgo(key.lastUsedAt) : "Never"}</span>
                {key.lastUsedIp && <> · from <span className="font-mono text-[#9CA3AF]">{key.lastUsedIp}</span></>}
              </p>
            </div>
          ))}
        </div>

        {/* Sidebar — quick start + usage */}
        <div className="space-y-4">
          <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
            <div className="flex items-center gap-2 border-b border-[#1F2937] px-5 py-4">
              <Code2 className="h-4 w-4 text-[#6B7280]" />
              <h2 className="text-sm font-semibold text-[#F9FAFB]">Quick Start</h2>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <p className="mb-2 text-xs font-medium text-[#9CA3AF]">Authentication</p>
                <div className="rounded-lg border border-[#1F2937] bg-[#0D1117] p-3 font-mono text-[11px] leading-relaxed">
                  <span className="text-[#6B7280]">curl</span>{" "}
                  <span className="text-[#F9FAFB]">https://api.sentinelasm.io/v1/assets \</span><br />
                  &nbsp;&nbsp;<span className="text-[#6B7280]">-H</span>{" "}
                  <span className="text-[#10B981]">"Authorization: Bearer sk_live_..."</span>
                </div>
              </div>
              <div>
                <p className="mb-2 text-xs font-medium text-[#9CA3AF]">Trigger a scan</p>
                <div className="rounded-lg border border-[#1F2937] bg-[#0D1117] p-3 font-mono text-[11px] leading-relaxed">
                  <span className="text-[#6B7280]">curl</span>{" "}
                  <span className="text-[#6B7280]">-X POST</span>{" "}
                  <span className="text-[#F9FAFB]">\</span><br />
                  &nbsp;&nbsp;<span className="text-[#F9FAFB]">https://api.sentinelasm.io/v1/scans \</span><br />
                  &nbsp;&nbsp;<span className="text-[#6B7280]">-H</span>{" "}
                  <span className="text-[#10B981]">"Authorization: Bearer sk_live_..."</span>{" "}
                  <span className="text-[#F9FAFB]">\</span><br />
                  &nbsp;&nbsp;<span className="text-[#6B7280]">-d</span>{" "}
                  <span className="text-[#F59E0B]">'{"{"}"domain":"target.com"{"}"}'</span>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-[#1F2937] bg-[#111827] p-5">
            <h2 className="mb-4 text-sm font-semibold text-[#F9FAFB]">API Usage</h2>
            <div className="space-y-3">
              <div>
                <div className="mb-1.5 flex justify-between text-xs">
                  <span className="text-[#6B7280]">Requests this month</span>
                  <span className="font-tabular font-semibold text-[#F9FAFB]">{(usageThisMonth * 160).toLocaleString()} / 50,000</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-[#1C2333]">
                  <div className="h-full rounded-full bg-[#3B82F6]"
                    style={{ width: `${Math.min(100, (usageThisMonth * 160 / 50000) * 100)}%` }} />
                </div>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-[#6B7280]">Rate limit</span>
                <span className="font-semibold text-[#F9FAFB]">60 req/min</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-[#6B7280]">Plan allowance</span>
                <span className="rounded-full bg-[rgba(59,130,246,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#3B82F6]">Professional</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-[#6B7280]">Active keys</span>
                <span className="font-semibold text-[#F9FAFB]">{DEMO_KEYS.filter(k => k.isActive).length} / 10</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showCreate && (
        <CreateKeyModal
          onClose={() => setShowCreate(false)}
          onCreated={(raw, name) => { setNewKey({ raw, name }); setShowCreate(false); }}
        />
      )}
    </div>
  );
}

const DEMO_KEYS: ApiKeyDisplay[] = [];
