import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { SettingsClient } from "./SettingsClient";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  const session = await requireSession();

  const [user, org, auditLogs] = await Promise.all([
    db.user.findUniqueOrThrow({
      where:  { id: session.userId },
      select: { id: true, name: true, email: true, twoFactorEnabled: true, lastLoginAt: true },
    }),
    db.organization.findUniqueOrThrow({
      where:  { id: session.orgId },
      select: { name: true, slug: true, plan: true },
    }),
    db.auditLog.findMany({
      where:   { organizationId: session.orgId },
      orderBy: { createdAt: "desc" },
      take:    20,
      include: { user: { select: { id: true, name: true, email: true } } },
    }),
  ]);

  return (
    <SettingsClient
      user={user}
      org={org}
      auditLogs={auditLogs}
      currentRole={session.role}
    />
  );
}
