"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Save, Shield, Eye, EyeOff, LogOut, Trash2, Download } from "lucide-react";
import { cn, timeAgo, formatDateTime, initials, avatarColor } from "@/lib/utils";
import type { MemberRole } from "@/types";

interface SettingsUser {
  id: string; name: string; email: string;
  twoFactorEnabled: boolean; lastLoginAt: Date | null;
}
interface SettingsOrg { name: string; slug: string; plan: string }
interface AuditLogEntry {
  id: string; action: string; target: string | null;
  ipAddress: string | null; createdAt: Date;
  user: { id: string; name: string; email: string } | null;
}
interface SettingsClientProps {
  user:        SettingsUser;
  org:         SettingsOrg;
  auditLogs:   AuditLogEntry[];
  currentRole: MemberRole;
}

type SettingsTab = "profile" | "security" | "sessions" | "general" | "scanning" | "audit";

const NAV_SECTIONS = [
  { label: "Account",      items: [
    { id: "profile",  label: "Profile" },
    { id: "security", label: "Security" },
    { id: "sessions", label: "Sessions" },
  ]},
  { label: "Organization", items: [
    { id: "general",  label: "General" },
    { id: "scanning", label: "Scanning" },
    { id: "audit",    label: "Audit Logs" },
  ]},
];

const ACTION_LABELS: Record<string, { label: string; color: string }> = {
  LOGIN:             { label: "Login",              color: "#9CA3AF" },
  LOGOUT:            { label: "Logout",             color: "#9CA3AF" },
  SCAN_STARTED:      { label: "Scan Started",       color: "#3B82F6" },
  SCAN_CANCELLED:    { label: "Scan Cancelled",     color: "#F59E0B" },
  FINDING_RESOLVED:  { label: "Finding Resolved",   color: "#10B981" },
  FINDING_ACCEPTED:  { label: "Finding Accepted",   color: "#10B981" },
  API_KEY_CREATED:   { label: "API Key Created",    color: "#F59E0B" },
  API_KEY_REVOKED:   { label: "API Key Revoked",    color: "#EF4444" },
  MEMBER_INVITED:    { label: "Member Invited",     color: "#8B5CF6" },
  MEMBER_REMOVED:    { label: "Member Removed",     color: "#EF4444" },
  ROLE_CHANGED:      { label: "Role Changed",       color: "#F59E0B" },
  DOMAIN_ADDED:      { label: "Domain Added",       color: "#3B82F6" },
  REPORT_GENERATED:  { label: "Report Generated",   color: "#3B82F6" },
  SETTINGS_UPDATED:  { label: "Settings Updated",   color: "#9CA3AF" },
  BILLING_UPDATED:   { label: "Billing Updated",    color: "#10B981" },
};

const DEMO_AUDIT: AuditLogEntry[] = [
  { id:"a1", action:"SCAN_STARTED",     target:"scan:acmecorp.com",         ipAddress:"104.21.44.1", createdAt: new Date(Date.now()-14*60*1000),        user:{ id:"u3", name:"Ali Raza",    email:"ali.raza@acmecorp.com"    }},
  { id:"a2", action:"LOGIN",            target:null,                        ipAddress:"104.21.44.1", createdAt: new Date(Date.now()-58*60*1000),        user:{ id:"u3", name:"Ali Raza",    email:"ali.raza@acmecorp.com"    }},
  { id:"a3", action:"FINDING_RESOLVED", target:"CVE-2017-9798 on staging",  ipAddress:"203.0.113.5", createdAt: new Date(Date.now()-2*3600*1000),       user:{ id:"u1", name:"Sara Khan",   email:"sara.khan@acmecorp.com"   }},
  { id:"a4", action:"API_KEY_CREATED",  target:"CI/CD Pipeline",            ipAddress:"198.51.100.3",createdAt: new Date(Date.now()-4*3600*1000),       user:{ id:"u2", name:"Ahmed Hassan",email:"a.hassan@acmecorp.com"    }},
  { id:"a5", action:"SCAN_STARTED",     target:"scan:api.acmecorp.com",     ipAddress:"104.21.44.1", createdAt: new Date(Date.now()-1*86400*1000),      user:{ id:"u3", name:"Ali Raza",    email:"ali.raza@acmecorp.com"    }},
  { id:"a6", action:"MEMBER_INVITED",   target:"bilal@acmecorp.com",        ipAddress:"203.0.113.5", createdAt: new Date(Date.now()-2*86400*1000),      user:{ id:"u1", name:"Sara Khan",   email:"sara.khan@acmecorp.com"   }},
  { id:"a7", action:"REPORT_GENERATED", target:"Full Pentest — Acme Corp",  ipAddress:"104.21.44.1", createdAt: new Date(Date.now()-3*86400*1000),      user:{ id:"u3", name:"Ali Raza",    email:"ali.raza@acmecorp.com"    }},
  { id:"a8", action:"BILLING_UPDATED",  target:"Starter→Professional",      ipAddress:"203.0.113.5", createdAt: new Date(Date.now()-30*86400*1000),     user:{ id:"u1", name:"Sara Khan",   email:"sara.khan@acmecorp.com"   }},
];

function Toggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button role="switch" aria-checked={on} onClick={onToggle}
      className={cn("relative h-5 w-9 rounded-full border transition-all",
        on ? "border-[#3B82F6] bg-[#3B82F6]" : "border-[#374151] bg-[#1C2333]"
      )}>
      <span className={cn("absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-transform",
        on ? "left-[18px]" : "left-0.5"
      )} />
    </button>
  );
}

function FormRow({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-[#1F2937] py-4 last:border-0">
      <div className="pr-6">
        <p className="text-sm font-medium text-[#F9FAFB]">{label}</p>
        {desc && <p className="mt-0.5 text-xs text-[#6B7280]">{desc}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

export function SettingsClient({ user, org, auditLogs, currentRole }: SettingsClientProps) {
  const [activeTab, setActiveTab] = useState<SettingsTab>("profile");
  const [saving,    setSaving]    = useState(false);

  // Profile state
  const [name,     setName]     = useState(user.name);
  const [email,    setEmail]    = useState(user.email);
  const [timezone, setTimezone] = useState("Asia/Karachi");

  // Security state
  const [showPw,       setShowPw]       = useState(false);
  const [currentPw,    setCurrentPw]    = useState("");
  const [newPw,        setNewPw]        = useState("");
  const [confirmPw,    setConfirmPw]    = useState("");
  const [twoFactor,    setTwoFactor]    = useState(user.twoFactorEnabled);

  // Org state
  const [orgName,    setOrgName]    = useState(org.name);
  const [scanTime,   setScanTime]   = useState("03:00");
  const [retention,  setRetention]  = useState("90");

  const handleSave = async () => {
    setSaving(true);
    await new Promise(r => setTimeout(r, 700));
    toast.success("Settings saved successfully");
    setSaving(false);
  };

  const handleChangePassword = async () => {
    if (!currentPw || !newPw) { toast.error("Fill in all password fields"); return; }
    if (newPw !== confirmPw)  { toast.error("New passwords don't match"); return; }
    if (newPw.length < 8)     { toast.error("Password must be at least 8 characters"); return; }
    setSaving(true);
    await new Promise(r => setTimeout(r, 800));
    toast.success("Password changed successfully");
    setCurrentPw(""); setNewPw(""); setConfirmPw("");
    setSaving(false);
  };

  const displayLogs = auditLogs.length > 0 ? auditLogs : DEMO_AUDIT;

  return (
    <div className="animate-fade-in space-y-5">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#F9FAFB]">Settings</h1>
          <p className="mt-1 text-sm text-[#6B7280]">Account, organization, and security configuration</p>
        </div>
        {activeTab !== "audit" && (
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white hover:bg-[#1D4ED8] disabled:opacity-60"
          >
            {saving
              ? <><span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white border-t-transparent" />Saving…</>
              : <><Save className="h-3.5 w-3.5" />Save Changes</>
            }
          </button>
        )}
      </div>

      <div className="grid grid-cols-[200px_1fr] gap-5">
        {/* Sidebar nav */}
        <div className="h-fit rounded-xl border border-[#1F2937] bg-[#111827] p-2">
          {NAV_SECTIONS.map(section => (
            <div key={section.label} className="mb-1">
              <p className="mb-1 px-3 pt-2 text-[10px] font-semibold uppercase tracking-[0.7px] text-[#6B7280]">
                {section.label}
              </p>
              {section.items.map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as SettingsTab)}
                  className={cn(
                    "w-full rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors",
                    activeTab === item.id
                      ? "bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                      : "text-[#9CA3AF] hover:bg-[#1C2333] hover:text-[#F9FAFB]"
                  )}
                >
                  {item.label}
                </button>
              ))}
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="space-y-4">

          {/* ── PROFILE ── */}
          {activeTab === "profile" && (
            <>
              <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
                <div className="border-b border-[#1F2937] px-5 py-4">
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">Profile</h2>
                </div>
                <div className="px-5">
                  <FormRow label="Avatar">
                    <div className={cn("flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br text-sm font-bold text-white", avatarColor(user.id))}>
                      {initials(name)}
                    </div>
                  </FormRow>
                  <FormRow label="Display Name" desc="Visible to your team members">
                    <input
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]"
                    />
                  </FormRow>
                  <FormRow label="Email Address" desc="Used for login and notifications">
                    <input
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      type="email"
                      className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]"
                    />
                  </FormRow>
                  <FormRow label="Timezone" desc="Used for scan scheduling and digest emails">
                    <select
                      value={timezone}
                      onChange={e => setTimezone(e.target.value)}
                      className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]"
                    >
                      <option value="Asia/Karachi">Asia/Karachi (PKT, UTC+5)</option>
                      <option value="UTC">UTC</option>
                      <option value="America/New_York">America/New_York (EST)</option>
                      <option value="Europe/London">Europe/London (GMT)</option>
                      <option value="Asia/Dubai">Asia/Dubai (GST, UTC+4)</option>
                    </select>
                  </FormRow>
                </div>
              </div>
            </>
          )}

          {/* ── SECURITY ── */}
          {activeTab === "security" && (
            <>
              <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
                <div className="border-b border-[#1F2937] px-5 py-4">
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">Change Password</h2>
                </div>
                <div className="px-5">
                  {[
                    { label: "Current Password", value: currentPw, setter: setCurrentPw, id: "cur" },
                    { label: "New Password",      value: newPw,     setter: setNewPw,     id: "new" },
                    { label: "Confirm Password",  value: confirmPw, setter: setConfirmPw, id: "con" },
                  ].map(({ label, value, setter, id }) => (
                    <FormRow key={id} label={label}>
                      <div className="relative w-64">
                        <input
                          type={showPw ? "text" : "password"}
                          value={value}
                          onChange={e => setter(e.target.value)}
                          placeholder="••••••••"
                          className="w-full rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 pr-9 text-sm text-[#F9FAFB] placeholder-[#374151] outline-none focus:border-[#3B82F6]"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPw(!showPw)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#9CA3AF]"
                        >
                          {showPw ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </button>
                      </div>
                    </FormRow>
                  ))}
                  <div className="py-4">
                    <button
                      onClick={handleChangePassword}
                      disabled={saving}
                      className="h-8 rounded-lg bg-[#3B82F6] px-4 text-sm font-semibold text-white hover:bg-[#1D4ED8] disabled:opacity-60"
                    >
                      {saving ? "Changing…" : "Change Password"}
                    </button>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
                <div className="border-b border-[#1F2937] px-5 py-4">
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">Two-Factor Authentication</h2>
                </div>
                <div className="px-5">
                  <FormRow
                    label="Authenticator App"
                    desc={twoFactor ? "2FA is enabled — your account is protected" : "Add an extra layer of security to your account"}
                  >
                    {twoFactor ? (
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1.5 rounded-full bg-[rgba(16,185,129,0.1)] px-2.5 py-1 text-xs font-semibold text-[#10B981]">
                          <Shield className="h-3 w-3" /> Enabled
                        </span>
                        <button
                          onClick={() => setTwoFactor(false)}
                          className="text-xs font-medium text-[#EF4444] hover:text-[#FCA5A5]"
                        >
                          Disable
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => toast.info("2FA setup — scan the QR code with your authenticator app")}
                        className="h-8 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white hover:bg-[#1D4ED8]"
                      >
                        Enable 2FA
                      </button>
                    )}
                  </FormRow>
                </div>
              </div>

              <div className="rounded-xl border border-[rgba(239,68,68,0.2)] bg-[#111827]">
                <div className="border-b border-[#1F2937] px-5 py-4">
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">Danger Zone</h2>
                </div>
                <div className="px-5">
                  <FormRow label="Sign out all sessions" desc="Revoke all active sessions except this one">
                    <button
                      onClick={() => toast.success("All other sessions revoked")}
                      className="flex h-8 items-center gap-1.5 rounded-lg border border-[rgba(239,68,68,0.3)] px-3 text-sm font-medium text-[#EF4444] transition-colors hover:bg-[rgba(239,68,68,0.1)]"
                    >
                      <LogOut className="h-3.5 w-3.5" /> Revoke All Sessions
                    </button>
                  </FormRow>
                </div>
              </div>
            </>
          )}

          {/* ── SESSIONS ── */}
          {activeTab === "sessions" && (
            <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
              <div className="border-b border-[#1F2937] px-5 py-4">
                <h2 className="text-sm font-semibold text-[#F9FAFB]">Active Sessions</h2>
                <p className="text-xs text-[#6B7280]">Devices currently signed into your account</p>
              </div>
              <div className="divide-y divide-[#1F2937]">
                {[
                  { device: "Chrome on macOS",  ip: "104.21.44.1",  location: "Lahore, PK", current: true,  lastSeen: new Date() },
                  { device: "Safari on iPhone", ip: "104.21.44.2",  location: "Lahore, PK", current: false, lastSeen: new Date(Date.now()-2*3600*1000) },
                  { device: "Firefox on Linux", ip: "203.0.113.5",  location: "Karachi, PK",current: false, lastSeen: new Date(Date.now()-2*86400*1000) },
                ].map((session, i) => (
                  <div key={i} className="flex items-center gap-4 px-5 py-4">
                    <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-[#1C2333] text-[#6B7280]">
                      <Shield className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-[#F9FAFB]">{session.device}</p>
                        {session.current && (
                          <span className="rounded-full bg-[rgba(16,185,129,0.1)] px-2 py-0.5 text-[10px] font-bold text-[#10B981]">
                            Current
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-[#6B7280]">
                        {session.ip} · {session.location} · {session.current ? "Active now" : timeAgo(session.lastSeen)}
                      </p>
                    </div>
                    {!session.current && (
                      <button
                        onClick={() => toast.success("Session revoked")}
                        className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] transition-colors hover:bg-[rgba(239,68,68,0.1)] hover:text-[#EF4444]"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── ORG GENERAL ── */}
          {activeTab === "general" && (
            <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
              <div className="border-b border-[#1F2937] px-5 py-4">
                <h2 className="text-sm font-semibold text-[#F9FAFB]">Organization — General</h2>
              </div>
              <div className="px-5">
                <FormRow label="Organization Name" desc="Visible to all members">
                  <input value={orgName} onChange={e => setOrgName(e.target.value)}
                    className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]" />
                </FormRow>
                <FormRow label="Organization Slug" desc="Used in API calls and URLs">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#6B7280]">sentinelasm.io/</span>
                    <input value={org.slug} readOnly
                      className="w-40 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#6B7280] outline-none" />
                  </div>
                </FormRow>
                <FormRow label="Scan Schedule" desc="Daily automatic full-domain scan">
                  <select value={scanTime} onChange={e => setScanTime(e.target.value)}
                    className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]">
                    <option value="03:00">03:00 AM daily (recommended)</option>
                    <option value="06:00">06:00 AM daily</option>
                    <option value="12:00">12:00 PM daily</option>
                    <option value="manual">Manual only</option>
                  </select>
                </FormRow>
                <FormRow label="Data Retention" desc="How long to keep scan history and findings">
                  <select value={retention} onChange={e => setRetention(e.target.value)}
                    className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] outline-none focus:border-[#3B82F6]">
                    <option value="90">90 days</option>
                    <option value="180">180 days</option>
                    <option value="365">1 year</option>
                    <option value="0">Forever</option>
                  </select>
                </FormRow>
              </div>
            </div>
          )}

          {/* ── SCANNING ── */}
          {activeTab === "scanning" && (
            <div className="space-y-4">
              <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
                <div className="border-b border-[#1F2937] px-5 py-4">
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">Scan Engine Configuration</h2>
                </div>
                <div className="px-5">
                  {[
                    { label:"Port Scanning",         desc:"TCP connect scan on top ports",           default:true  },
                    { label:"Cloud Asset Discovery", desc:"S3 / Azure Blob / GCP Storage enum",      default:true  },
                    { label:"GitHub Secret Scan",    desc:"Search public repos for leaked keys",     default:true  },
                    { label:"Directory Fuzzing",     desc:"Check for exposed .git, .env, backups",   default:true  },
                    { label:"CVE Matching",          desc:"Match tech versions against NVD + OSV",   default:true  },
                    { label:"CISA KEV Enrichment",   desc:"Flag actively exploited CVEs from KEV",   default:true  },
                  ].map(({ label, desc, default: def }, i) => {
                    const [on, setOn] = useState(def);
                    return (
                      <FormRow key={i} label={label} desc={desc}>
                        <Toggle on={on} onToggle={() => setOn(!on)} />
                      </FormRow>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
                <div className="border-b border-[#1F2937] px-5 py-4">
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">API Keys for Scan Modules</h2>
                  <p className="text-xs text-[#6B7280]">Add keys for higher rate limits and better coverage</p>
                </div>
                <div className="px-5">
                  {[
                    { label:"NVD API Key",     desc:"nvd.nist.gov · 10× rate limit (50 vs 5 req/30s)", placeholder:"Enter NVD API key" },
                    { label:"Vulners API Key", desc:"vulners.com · exploit availability data",           placeholder:"Enter Vulners API key" },
                    { label:"OTX API Key",     desc:"otx.alienvault.com · passive DNS data",             placeholder:"Enter OTX API key" },
                    { label:"URLScan Key",     desc:"urlscan.io · additional subdomain coverage",         placeholder:"Enter URLScan API key" },
                  ].map(({ label, desc, placeholder }) => (
                    <FormRow key={label} label={label} desc={desc}>
                      <input
                        type="password"
                        placeholder={placeholder}
                        className="w-64 rounded-lg border border-[#1F2937] bg-[#0D1117] px-3 py-2 text-sm text-[#F9FAFB] placeholder-[#374151] outline-none focus:border-[#3B82F6]"
                      />
                    </FormRow>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── AUDIT LOG ── */}
          {activeTab === "audit" && (
            <div className="rounded-xl border border-[#1F2937] bg-[#111827]">
              <div className="flex items-center justify-between border-b border-[#1F2937] px-5 py-4">
                <div>
                  <h2 className="text-sm font-semibold text-[#F9FAFB]">Audit Log</h2>
                  <p className="text-xs text-[#6B7280]">All actions performed in your organization</p>
                </div>
                <button
                  onClick={() => toast.info("Exporting audit log as CSV…")}
                  className="flex h-8 items-center gap-1.5 rounded-lg border border-[#1F2937] px-3 text-sm font-medium text-[#D1D5DB] transition-colors hover:border-[#374151]"
                >
                  <Download className="h-3.5 w-3.5" /> Export CSV
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-[#1F2937]">
                      {["Timestamp","User","Action","Target","IP Address"].map(h => (
                        <th key={h} className="whitespace-nowrap px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[#6B7280]">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {displayLogs.map((log) => {
                      const actionStyle = ACTION_LABELS[log.action] ?? { label: log.action, color: "#9CA3AF" };
                      return (
                        <tr key={log.id} className="border-b border-[#1F2937] transition-colors hover:bg-[#141E2E] last:border-0">
                          <td className="whitespace-nowrap px-4 py-3 font-mono text-xs text-[#9CA3AF]">
                            {formatDateTime(log.createdAt)}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              {log.user ? (
                                <>
                                  <div className={cn("flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br text-[9px] font-bold text-white", avatarColor(log.user.id))}>
                                    {initials(log.user.name)}
                                  </div>
                                  <span className="text-xs text-[#F9FAFB]">{log.user.name}</span>
                                </>
                              ) : (
                                <span className="text-xs text-[#6B7280]">System</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <span className="rounded px-2 py-0.5 text-[11px] font-semibold"
                              style={{ background: `${actionStyle.color}18`, color: actionStyle.color }}>
                              {actionStyle.label}
                            </span>
                          </td>
                          <td className="max-w-[200px] px-4 py-3">
                            <span className="block truncate text-xs text-[#9CA3AF]">{log.target ?? "—"}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className="font-mono text-xs text-[#6B7280]">{log.ipAddress ?? "—"}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
