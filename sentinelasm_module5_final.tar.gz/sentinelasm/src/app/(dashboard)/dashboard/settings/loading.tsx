import { SettingsSkeleton } from "@/components/ui/Skeletons";
export default function SettingsLoading() { return <SettingsSkeleton />; }
