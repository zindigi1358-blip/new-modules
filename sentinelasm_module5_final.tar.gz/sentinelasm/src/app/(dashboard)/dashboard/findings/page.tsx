import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { FindingsClient } from "./FindingsClient";

export const metadata: Metadata = { title: "Findings" };

export default async function FindingsPage() {
  const session = await requireSession();
  const counts = await db.finding.groupBy({
    by:     ["severity"],
    where:  { organizationId: session.orgId, status: { not: "RESOLVED" } },
    _count: true,
  });
  const total = await db.finding.count({ where: { organizationId: session.orgId } });
  const kev   = await db.finding.count({ where: { organizationId: session.orgId, isKev: true, status: { not: "RESOLVED" } } });

  const bySeverity = Object.fromEntries(counts.map(c => [c.severity, c._count])) as Record<string, number>;

  return <FindingsClient totalFindings={total} bySeverity={bySeverity} kevCount={kev} />;
}
