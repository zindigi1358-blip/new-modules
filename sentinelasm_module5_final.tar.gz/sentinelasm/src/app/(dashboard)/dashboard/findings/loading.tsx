import { FindingsSkeleton } from "@/components/ui/Skeletons";
export default function FindingsLoading() {
  return <FindingsSkeleton />;
}
