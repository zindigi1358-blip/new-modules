"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Search, AlertTriangle, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { SeverityBadge, CvssPill } from "@/components/ui/Badge";
import { FindingDrawer } from "@/components/ui/FindingDrawer";
import { NoFindingsEmpty } from "@/components/ui/EmptyStates";
import type { FindingSeverity } from "@/types";

interface FindingsClientProps {
  totalFindings: number;
  bySeverity:    Record<string, number>;
  kevCount:      number;
}

const DEMO_FINDINGS = [
  { id:"f1", title:"AWS Access Key Exposed in GitHub",                  asset:"github.com/acmecorp/infra",           severity:"CRITICAL" as FindingSeverity, cvss:9.9, score:96, isKev:false, category:"Credentials", status:"OPEN",        assignee:null,       description:"An AWS access key was found in a public GitHub repository commit history. The key may grant access to production AWS resources including S3, EC2, and IAM.", evidence:"AWS_ACCESS_KEY_ID found in terraform/backend.tf at commit a3f9b12", remediation:"Rotate all AWS credentials immediately. Revoke the exposed key in AWS IAM console. Add .env and terraform.tfvars to .gitignore. Use AWS Secrets Manager going forward." },
  { id:"f2", title:"Exposed .git Directory",                            asset:"dev.acmecorp.com/.git/config",        severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:91, isKev:false, category:"Exposure",    status:"OPEN",        assignee:null,       description:"The .git directory is publicly accessible, allowing full reconstruction of the source code repository including all commit history, credentials, and configuration files.", evidence:"HTTP 200 on /.git/config — content contains [core] repositoryformatversion = 0",            remediation:"Block web access to .git via nginx config: location ~ /\\.git { deny all; return 404; }. Rotate any secrets found in git history immediately." },
  { id:"f3", title:"PHP 5.6.40 — Remote Code Execution (CVE-2019-11043)",asset:"old.acmecorp.com",                 severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:88, isKev:true,  category:"CVE",         status:"OPEN",        assignee:"Ali Raza", description:"PHP 5.6 reached end-of-life in December 2018 and contains a critical remote code execution vulnerability. CVE-2019-11043 is in the CISA KEV catalog — it is being actively exploited in the wild.", evidence:"PHP 5.6.40 detected via X-Powered-By header. CVE-2019-11043 confirmed via version match.", remediation:"Upgrade PHP to 8.1+ immediately. This is actively exploited. Migrating the application may require code changes for PHP 8 compatibility." },
  { id:"f4", title:"MongoDB Port 27017 Exposed — No Authentication",    asset:"api.acmecorp.com:27017",             severity:"CRITICAL" as FindingSeverity, cvss:9.1, score:88, isKev:false, category:"Exposure",    status:"OPEN",        assignee:null,       description:"MongoDB is listening on port 27017 with no authentication required, accessible from any IP address on the internet. All database contents can be read, modified, or deleted by any attacker.", evidence:"TCP connect to 27017 succeeded. No SASL/SCRAM authentication challenge received.",          remediation:"Immediately restrict port 27017 via iptables to application server IPs only. Enable MongoDB authentication. Move MongoDB to a private subnet." },
  { id:"f5", title:"S3 Bucket Publicly Readable",                       asset:"acmecorp-backups.s3.amazonaws.com",  severity:"CRITICAL" as FindingSeverity, cvss:8.6, score:85, isKev:false, category:"Cloud",       status:"OPEN",        assignee:null,       description:"An S3 bucket containing database backups is publicly accessible. Any internet user can list and download all backup files, potentially exposing sensitive customer data and credentials.", evidence:"ListBucket API returns HTTP 200 with 47 objects including .sql.gz backup files.",            remediation:"Set bucket ACL to private immediately. Enable S3 Block Public Access at account level. Move backups to private bucket. Rotate any credentials found in backups." },
  { id:"f6", title:"WordPress 5.8 — SQL Injection (CVE-2022-21661)",    asset:"admin.acmecorp.com",                 severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:91, isKev:false, category:"CVE",         status:"OPEN",        assignee:null,       description:"WordPress 5.8 contains a SQL injection vulnerability in WP_Query that allows unauthenticated attackers to extract the entire database contents via crafted POST requests.", evidence:"WordPress 5.8 detected via readme.html and login page meta generator tag.",                  remediation:"Update WordPress to 5.8.3+ or the latest version immediately. Apply WordPress auto-updates going forward." },
  { id:"f7", title:"Exposed .env File with Database Credentials",        asset:"staging.acmecorp.com/.env",         severity:"CRITICAL" as FindingSeverity, cvss:9.8, score:88, isKev:false, category:"Exposure",    status:"OPEN",        assignee:null,       description:"A .env file containing database credentials, API keys, and secret keys is publicly accessible. This is equivalent to direct database access and full application compromise.", evidence:"Content contains: DB_PASSWORD, AWS_SECRET_ACCESS_KEY, APP_KEY, MAIL_PASSWORD",              remediation:"Remove the file immediately. Rotate every secret listed. Never store .env in web root. Use a secrets manager." },
  { id:"f8", title:"Express.js 4.17 — Open Redirect (CVE-2022-24999)", asset:"api.acmecorp.com",                   severity:"HIGH"     as FindingSeverity, cvss:7.5, score:73, isKev:false, category:"CVE",         status:"OPEN",        assignee:null,       description:"Express.js 4.17.1 contains an open redirect vulnerability allowing attackers to redirect users to malicious URLs via crafted Host headers, enabling phishing attacks.", evidence:"CVE-2022-24999 — Express version 4.17.1 confirmed via package.json exposure",               remediation:"Update express to 4.18.2+ via npm update express." },
  { id:"f9", title:"Admin Panel Exposed to Public Internet",             asset:"admin.acmecorp.com",                 severity:"HIGH"     as FindingSeverity, cvss:7.2, score:68, isKev:false, category:"Config",      status:"IN_PROGRESS", assignee:"Ali Raza", description:"The WordPress admin panel is accessible from any IP address without restriction. This exposes the login page to brute-force and credential stuffing attacks.", evidence:"HTTP 200 on /wp-admin/ from external IP. No IP allowlist or rate limiting detected.",        remediation:"Restrict /wp-admin to office IP via nginx allow/deny. Enable 2FA on all admin accounts. Implement account lockout after 5 failed attempts." },
  { id:"fa", title:"Grafana 7.3.1 — Unauthenticated Snapshot API",      asset:"monitor.acmecorp.com",               severity:"HIGH"     as FindingSeverity, cvss:8.8, score:67, isKev:false, category:"CVE",         status:"OPEN",        assignee:null,       description:"Grafana 7.3.1 exposes a snapshot API endpoint that allows unauthenticated access to dashboard data, potentially exposing internal metrics and infrastructure details.", evidence:"CVE-2021-27358 — Grafana 7.3.1 detected via HTTP headers.",                                  remediation:"Update Grafana to 7.5.15+ or 8.5.5+." },
  { id:"fb", title:"Missing HSTS Header",                                asset:"admin.acmecorp.com",                 severity:"MEDIUM"   as FindingSeverity, cvss:5.4, score:32, isKev:false, category:"Config",      status:"OPEN",        assignee:null,       description:"The Strict-Transport-Security header is absent, leaving users vulnerable to TLS downgrade attacks and man-in-the-middle interception on their first HTTP request.", evidence:"Strict-Transport-Security header absent from all HTTP responses.",                           remediation:"Add: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload" },
  { id:"fc", title:"TLS Certificate Expiring in 12 Days",                asset:"mail.acmecorp.com",                  severity:"MEDIUM"   as FindingSeverity, cvss:0,   score:28, isKev:false, category:"Config",      status:"OPEN",        assignee:null,       description:"The TLS certificate for mail.acmecorp.com will expire in 12 days. After expiry, email clients will show security warnings and reject connections.", evidence:"TLS certificate expires: 2026-08-01T00:00:00Z (12 days remaining)",                          remediation:"Renew the certificate immediately. Configure auto-renewal via certbot: certbot renew --quiet" },
  { id:"fd", title:"Roundcube XSS (CVE-2021-44025)",                    asset:"mail.acmecorp.com",                  severity:"LOW"      as FindingSeverity, cvss:4.3, score:22, isKev:false, category:"CVE",         status:"OPEN",        assignee:null,       description:"Roundcube 1.4.11 contains a stored XSS vulnerability that can be exploited by sending a crafted HTML email, potentially stealing session cookies.", evidence:"CVE-2021-44025 — Roundcube 1.4.11 detected via login page markup.",                          remediation:"Update Roundcube to 1.4.13+ or 1.5.2+." },
];

const STATUS_BADGE: Record<string, { label: string; color: string; bg: string }> = {
  OPEN:          { label: "Open",         color: "#EF4444", bg: "rgba(239,68,68,0.1)"   },
  IN_PROGRESS:   { label: "In Progress",  color: "#3B82F6", bg: "rgba(59,130,246,0.1)"  },
  RESOLVED:      { label: "Resolved",     color: "#10B981", bg: "rgba(16,185,129,0.1)"  },
  ACCEPTED_RISK: { label: "Accepted",     color: "#9CA3AF", bg: "rgba(107,114,128,0.1)" },
  FALSE_POSITIVE:{ label: "False +",      color: "#6B7280", bg: "rgba(107,114,128,0.1)" },
};

export function FindingsClient({ totalFindings, bySeverity, kevCount }: FindingsClientProps) {
  const router = useRouter();
  const [search,     setSearch]     = useState("");
  const [sevFilter,  setSevFilter]  = useState("");
  const [catFilter,  setCatFilter]  = useState("");
  const [kevOnly,    setKevOnly]    = useState(false);
  const [page,       setPage]       = useState(1);
  const [selected,   setSelected]   = useState<string[]>([]);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerFinding, setDrawerFinding] = useState<(typeof DEMO_FINDINGS)[0] | null>(null);
  const pageSize = 25;

  const filtered = DEMO_FINDINGS.filter((f) => {
    if (kevOnly     && !f.isKev)                           return false;
    if (sevFilter   && f.severity !== sevFilter)           return false;
    if (catFilter   && f.category !== catFilter)           return false;
    if (search      && !f.title.toLowerCase().includes(search.toLowerCase())
                    && !f.asset.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const handleRowClick = useCallback((finding: typeof DEMO_FINDINGS[0]) => {
    setDrawerFinding(finding);
    setDrawerOpen(true);
  }, []);

  const handleStatusChange = useCallback(async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/findings/${id}`, {
        method:  "PATCH",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ status }),
      });
      if (!res.ok) { toast.error("Failed to update status"); return; }
      toast.success(`Finding marked as ${status.toLowerCase().replace("_", " ")}`);
      router.refresh();
    } catch {
      toast.error("Network error");
    }
  }, [router]);

  const severityTabs = [
    { label: "All",      value: "",         count: totalFindings || DEMO_FINDINGS.length },
    { label: "Critical", value: "CRITICAL",  count: bySeverity["CRITICAL"] ?? 7  },
    { label: "High",     value: "HIGH",      count: bySeverity["HIGH"]     ?? 3  },
    { label: "Medium",   value: "MEDIUM",    count: bySeverity["MEDIUM"]   ?? 2  },
    { label: "Low",      value: "LOW",       count: bySeverity["LOW"]      ?? 1  },
  ];

  const allChecked = filtered.length > 0 && selected.length === filtered.length;
  const toggleAll  = () => setSelected(allChecked ? [] : filtered.map(f => f.id));
  const toggleOne  = (id: string) =>
    setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);

  const drawerData = drawerFinding ? {
    ...drawerFinding,
    cvssScore:   drawerFinding.cvss,
    riskScore:   drawerFinding.score,
    affectedAsset: drawerFinding.asset,
    cveIds:      drawerFinding.category === "CVE" ? ["CVE-2022-21661"] : [],
    firstSeenAt: new Date(Date.now() - 3 * 86400 * 1000).toISOString(),
    lastSeenAt:  new Date().toISOString(),
    resolvedAt:  null,
    assignee:    drawerFinding.assignee
      ? { id: "u3", name: drawerFinding.assignee, avatarUrl: null }
      : null,
    asset: {
      subdomain:    drawerFinding.asset.split("/")[0] ?? null,
      ipAddress:    "104.21.44.12",
      openPorts:    [80, 443, 3306],
      technologies: ["WordPress 5.8", "PHP 7.4", "Nginx"],
    },
  } : null;

  return (
    <>
      <div className="animate-fade-in space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">Findings</h1>
            <p className="mt-1 text-sm text-[var(--text-muted)]">
              {totalFindings || DEMO_FINDINGS.length} total ·{" "}
              {bySeverity["CRITICAL"] ?? 7} critical ·{" "}
              {bySeverity["HIGH"] ?? 3} high
              {(kevCount || 2) > 0 && (
                <> · <span className="font-medium text-[#EF4444]">{kevCount || 2} actively exploited (KEV)</span></>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {selected.length > 0 && (
              <button className="h-8 rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-3 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:border-[var(--border-light)]">
                Bulk Actions ({selected.length})
              </button>
            )}
            <button className="h-8 rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-3 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:border-[var(--border-light)]">
              Export
            </button>
          </div>
        </div>

        {/* Severity tabs */}
        <div className="flex items-center gap-0 border-b border-[var(--border)]">
          {severityTabs.map((tab) => (
            <button
              key={tab.value}
              onClick={() => { setSevFilter(tab.value); setPage(1); }}
              className={cn(
                "flex items-center gap-1.5 border-b-2 px-3 pb-3 pt-3 text-sm font-medium transition-colors",
                sevFilter === tab.value
                  ? "border-[#3B82F6] text-[#3B82F6]"
                  : "border-transparent text-[var(--text-muted)] hover:text-[var(--text-secondary)]"
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className={cn(
                  "rounded-full px-1.5 py-0.5 text-[10px] font-bold",
                  sevFilter === tab.value
                    ? "bg-[rgba(59,130,246,0.2)] text-[#3B82F6]"
                    : "bg-[var(--bg-elevated)] text-[var(--text-muted)]"
                )}>
                  {tab.count}
                </span>
              )}
            </button>
          ))}
          <div className="ml-auto flex items-center gap-2 pb-3">
            <button
              onClick={() => setKevOnly(!kevOnly)}
              className={cn(
                "h-7 rounded-full border px-3 text-xs font-medium transition-colors",
                kevOnly
                  ? "border-[rgba(239,68,68,0.3)] bg-[rgba(239,68,68,0.1)] text-[#EF4444]"
                  : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border-light)]"
              )}
            >
              ☠ KEV Only
            </button>
          </div>
        </div>

        {/* Table card */}
        <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
          {/* Filter bar */}
          <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-4 py-3">
            <div className="flex h-8 min-w-[240px] flex-1 items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-3">
              <Search className="h-3.5 w-3.5 flex-shrink-0 text-[var(--text-muted)]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search findings, CVEs, assets…"
                className="flex-1 bg-transparent text-sm text-[var(--text-primary)] placeholder-[var(--text-faint)] outline-none"
              />
            </div>
            <select
              value={catFilter}
              onChange={(e) => setCatFilter(e.target.value)}
              className="h-8 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-2 text-xs text-[var(--text-muted)] outline-none"
            >
              <option value="">All Categories</option>
              {["Exposure","CVE","Config","Credentials","Cloud"].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <select className="h-8 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-2 text-xs text-[var(--text-muted)] outline-none">
              <option>Sort: Risk Score ↓</option>
              <option>Sort: CVSS ↓</option>
              <option>Sort: Newest</option>
            </select>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            {filtered.length === 0 ? (
              <NoFindingsEmpty hasFilters={!!(search || sevFilter || catFilter || kevOnly)} />
            ) : (
              <table className="w-full" role="grid">
                <thead>
                  <tr className="border-b border-[var(--border)]">
                    <th className="w-10 px-4 py-2.5">
                      <input
                        type="checkbox"
                        checked={allChecked}
                        onChange={toggleAll}
                        className="h-3.5 w-3.5 rounded border-[var(--border-light)] accent-[#3B82F6]"
                        aria-label="Select all findings"
                      />
                    </th>
                    {["Finding","Severity","CVSS","Risk Score","Asset","Category","Status","Assigned"].map(h => (
                      <th key={h} className="whitespace-nowrap px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[var(--text-muted)]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.slice((page - 1) * pageSize, page * pageSize).map((f) => {
                    const st = STATUS_BADGE[f.status] ?? STATUS_BADGE["OPEN"]!;
                    return (
                      <tr
                        key={f.id}
                        className="group cursor-pointer border-b border-[var(--border)] transition-colors hover:bg-[var(--bg-elevated)] last:border-0"
                        onClick={() => handleRowClick(f)}
                        role="row"
                      >
                        <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                          <input
                            type="checkbox"
                            checked={selected.includes(f.id)}
                            onChange={() => toggleOne(f.id)}
                            className="h-3.5 w-3.5 rounded border-[var(--border-light)] accent-[#3B82F6]"
                          />
                        </td>
                        <td className="max-w-[280px] px-3 py-3">
                          <p className="text-[13px] font-medium leading-snug text-[var(--text-primary)] transition-colors group-hover:text-[#3B82F6]">
                            {f.title}
                            {f.isKev && (
                              <span className="ml-1.5 text-[#EF4444]" title="CISA Known Exploited Vulnerability">☠</span>
                            )}
                          </p>
                          <p className="mt-0.5 font-mono text-[11px] text-[var(--text-muted)]">{f.asset}</p>
                        </td>
                        <td className="px-3 py-3"><SeverityBadge severity={f.severity} dot /></td>
                        <td className="px-3 py-3"><CvssPill score={f.cvss} /></td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-2">
                            <span
                              className="font-tabular text-sm font-bold"
                              style={{ color: f.score >= 85 ? "#EF4444" : f.score >= 65 ? "#F59E0B" : "#10B981" }}
                            >
                              {f.score}
                            </span>
                            <div className="h-1 w-14 overflow-hidden rounded-full bg-[var(--bg-elevated)]">
                              <div
                                className="h-full rounded-full"
                                style={{
                                  width: `${f.score}%`,
                                  background: f.score >= 85 ? "#EF4444" : f.score >= 65 ? "#F59E0B" : "#10B981",
                                  opacity: 0.7,
                                }}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="max-w-[160px] px-3 py-3">
                          <span className="block truncate font-mono text-[11px] text-[var(--text-muted)]">
                            {f.asset.split("/")[0]}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <span className="rounded bg-[var(--bg-elevated)] px-1.5 py-0.5 text-[11px] text-[var(--text-muted)]">
                            {f.category}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <span
                            className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold"
                            style={{ background: st.bg, color: st.color }}
                          >
                            <span className="h-1.5 w-1.5 rounded-full bg-current" />
                            {st.label}
                          </span>
                        </td>
                        <td className="px-3 py-3">
                          <span className="text-xs text-[var(--text-muted)]">{f.assignee ?? "—"}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>

          {/* Pagination */}
          {filtered.length > 0 && (
            <div className="flex items-center justify-between border-t border-[var(--border)] px-4 py-3">
              <span className="text-xs text-[var(--text-muted)]">
                Showing {Math.min(filtered.length, pageSize)} of {filtered.length} findings
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="flex h-7 w-7 items-center justify-center rounded border border-[var(--border)] text-[var(--text-muted)] disabled:opacity-40 hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                {Array.from({ length: Math.min(3, Math.ceil(filtered.length / pageSize)) }, (_, i) => i + 1).map(p => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={cn(
                      "flex h-7 w-7 items-center justify-center rounded border text-xs font-medium transition-colors",
                      page === p
                        ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                        : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
                    )}
                  >
                    {p}
                  </button>
                ))}
                <button
                  onClick={() => setPage(p => p + 1)}
                  disabled={page >= Math.ceil(filtered.length / pageSize)}
                  className="flex h-7 w-7 items-center justify-center rounded border border-[var(--border)] text-[var(--text-muted)] disabled:opacity-40 hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Finding Detail Drawer */}
      <FindingDrawer
        finding={drawerData}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        onStatusChange={handleStatusChange}
      />
    </>
  );
}
