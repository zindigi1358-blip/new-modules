"use client";

import { useState, useCallback } from "react";
import { Globe, Download, Plus, Search, ChevronLeft, ChevronRight } from "lucide-react";
import { cn, timeAgo } from "@/lib/utils";
import { SeverityBadge } from "@/components/ui/Badge";
import { AssetDrawer } from "@/components/ui/AssetDrawer";
import { NoAssetsEmpty } from "@/components/ui/EmptyStates";
import type { FindingSeverity } from "@/types";

interface AssetStats {
  totalAssets: number; aliveAssets: number; cloudAssets: number;
  publicBuckets: number; riskyPorts: number; ipCount: number;
}
interface AssetsClientProps { stats: AssetStats; orgId: string }

const DEMO_ASSETS = [
  { id:"1", subdomain:"admin.acmecorp.com",   isAlive:true,  httpsStatus:200, httpStatus:301, ipAddress:"104.21.44.12", openPorts:[80,443,3306],       technologies:["WordPress 5.8","PHP 7.4.3","jQuery 3.5.1","Missing HSTS"], riskLevel:"CRITICAL" as FindingSeverity, lastSeenAt:new Date(Date.now()-2*60*1000),       title:"Admin Dashboard Login" },
  { id:"2", subdomain:"api.acmecorp.com",     isAlive:true,  httpsStatus:200, httpStatus:null, ipAddress:"104.21.44.18", openPorts:[443,6379,27017],   technologies:["Express.js 4.17.1","Nginx 1.18.0","Node.js 14.17"],       riskLevel:"CRITICAL" as FindingSeverity, lastSeenAt:new Date(Date.now()-14*60*1000),     title:"API v2" },
  { id:"3", subdomain:"staging.acmecorp.com", isAlive:true,  httpsStatus:200, httpStatus:200,  ipAddress:"104.21.44.23", openPorts:[443,9200],         technologies:["Django 3.1.4","Python 3.8","Nginx 1.14.0"],               riskLevel:"HIGH"     as FindingSeverity, lastSeenAt:new Date(Date.now()-14*60*1000),     title:"Staging Environment" },
  { id:"4", subdomain:"dev.acmecorp.com",     isAlive:true,  httpsStatus:200, httpStatus:200,  ipAddress:"104.21.44.31", openPorts:[22,80,27017],      technologies:["Apache 2.4.29","MongoDB"],                                 riskLevel:"CRITICAL" as FindingSeverity, lastSeenAt:new Date(Date.now()-38*60*1000),     title:"Dev Server" },
  { id:"5", subdomain:"old.acmecorp.com",     isAlive:true,  httpsStatus:200, httpStatus:200,  ipAddress:"104.21.44.44", openPorts:[80,443,21],        technologies:["PHP 5.6.40","Apache 2.2.34","Missing HSTS"],               riskLevel:"CRITICAL" as FindingSeverity, lastSeenAt:new Date(Date.now()-60*60*1000),     title:"Legacy Portal" },
  { id:"6", subdomain:"mail.acmecorp.com",    isAlive:true,  httpsStatus:200, httpStatus:null, ipAddress:"104.21.44.52", openPorts:[25,443,587,993],   technologies:["Roundcube 1.4.11"],                                        riskLevel:"MEDIUM"   as FindingSeverity, lastSeenAt:new Date(Date.now()-60*60*1000),     title:"Webmail" },
  { id:"7", subdomain:"www.acmecorp.com",     isAlive:true,  httpsStatus:200, httpStatus:301,  ipAddress:"104.21.44.8",  openPorts:[80,443],           technologies:["React 17.0.2","Next.js 11.0.1","Nginx 1.20.1"],           riskLevel:"LOW"      as FindingSeverity, lastSeenAt:new Date(Date.now()-2*60*60*1000),   title:"Home Page" },
  { id:"8", subdomain:"vpn.acmecorp.com",     isAlive:true,  httpsStatus:200, httpStatus:null, ipAddress:"104.21.44.61", openPorts:[443,1194],         technologies:["OpenVPN 2.4.9"],                                           riskLevel:"MEDIUM"   as FindingSeverity, lastSeenAt:new Date(Date.now()-2*60*60*1000),   title:"VPN Portal" },
  { id:"9", subdomain:"monitor.acmecorp.com", isAlive:true,  httpsStatus:200, httpStatus:null, ipAddress:"104.21.44.71", openPorts:[443,3000],         technologies:["Grafana 7.3.1"],                                           riskLevel:"HIGH"     as FindingSeverity, lastSeenAt:new Date(Date.now()-3*60*60*1000),   title:"Grafana" },
  { id:"10",subdomain:"backup.acmecorp.com",  isAlive:true,  httpsStatus:200, httpStatus:200,  ipAddress:"104.21.44.82", openPorts:[21,22,80,5900],    technologies:["Apache 2.4.18"],                                           riskLevel:"HIGH"     as FindingSeverity, lastSeenAt:new Date(Date.now()-3*60*60*1000),   title:"Backup Server" },
  { id:"11",subdomain:"payment.acmecorp.com", isAlive:true,  httpsStatus:200, httpStatus:301,  ipAddress:"104.21.44.91", openPorts:[443],              technologies:["Nginx 1.20.1","Vue.js 2.6.14","Stripe"],                  riskLevel:"LOW"      as FindingSeverity, lastSeenAt:new Date(Date.now()-4*60*60*1000),   title:"Payment Portal" },
  { id:"12",subdomain:"auth.acmecorp.com",    isAlive:true,  httpsStatus:200, httpStatus:null, ipAddress:"104.21.44.95", openPorts:[443],              technologies:["Keycloak 12.0.4"],                                         riskLevel:"MEDIUM"   as FindingSeverity, lastSeenAt:new Date(Date.now()-5*60*60*1000),   title:"SSO Login" },
];

const RISK_LEVELS = ["","CRITICAL","HIGH","MEDIUM","LOW"];

export function AssetsClient({ stats }: AssetsClientProps) {
  const [search,       setSearch]       = useState("");
  const [riskFilter,   setRiskFilter]   = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [page,         setPage]         = useState(1);
  const [drawerOpen,   setDrawerOpen]   = useState(false);
  const [drawerAsset,  setDrawerAsset]  = useState<typeof DEMO_ASSETS[0] | null>(null);
  const pageSize = 25;

  const filtered = DEMO_ASSETS.filter((a) => {
    if (search && !a.subdomain.toLowerCase().includes(search.toLowerCase()) &&
        !a.ipAddress?.toLowerCase().includes(search.toLowerCase()) &&
        !a.technologies.some(t => t.toLowerCase().includes(search.toLowerCase()))) return false;
    if (riskFilter && a.riskLevel !== riskFilter) return false;
    if (statusFilter === "alive"   && !a.isAlive) return false;
    if (statusFilter === "at-risk" && !["CRITICAL","HIGH"].includes(a.riskLevel)) return false;
    if (statusFilter === "cloud") return false;
    return true;
  });

  const handleRowClick = useCallback((asset: typeof DEMO_ASSETS[0]) => {
    setDrawerAsset(asset);
    setDrawerOpen(true);
  }, []);

  const statCards = [
    { label: "Subdomains",   value: stats.totalAssets,   color: "#3B82F6" },
    { label: "Alive",        value: stats.aliveAssets,   color: "#10B981" },
    { label: "IP Addresses", value: stats.ipCount,       color: "#9CA3AF" },
    { label: "Cloud Assets", value: stats.cloudAssets,   color: "#9CA3AF" },
    { label: "Public!",      value: stats.publicBuckets, color: "#EF4444" },
  ];

  const assetDrawerData = drawerAsset ? {
    id:            drawerAsset.id,
    subdomain:     drawerAsset.subdomain,
    ipAddress:     drawerAsset.ipAddress,
    url:           null,
    assetType:     "SUBDOMAIN",
    isAlive:       drawerAsset.isAlive,
    httpStatus:    drawerAsset.httpStatus,
    httpsStatus:   drawerAsset.httpsStatus,
    title:         drawerAsset.title,
    openPorts:     drawerAsset.openPorts,
    technologies:  drawerAsset.technologies,
    cloudProvider: null,
    cloudAssetType:null,
    isPublic:      null,
    firstSeenAt:   new Date(Date.now() - 30 * 86400 * 1000).toISOString(),
    lastSeenAt:    drawerAsset.lastSeenAt.toISOString(),
    findings: [
      { id:"f1", title:"CVE-2022-21661 — SQL Injection",    severity:"CRITICAL" as FindingSeverity, riskScore:91, status:"OPEN" },
      { id:"f2", title:"Missing HSTS Header",               severity:"MEDIUM"   as FindingSeverity, riskScore:32, status:"OPEN" },
      { id:"f3", title:"Admin Panel Publicly Accessible",   severity:"HIGH"     as FindingSeverity, riskScore:68, status:"IN_PROGRESS" },
    ],
  } : null;

  return (
    <>
      <div className="animate-fade-in space-y-5">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold tracking-tight text-[var(--text-primary)]">Assets</h1>
            <p className="mt-1 text-sm text-[var(--text-muted)]">
              {stats.totalAssets.toLocaleString()} assets discovered across monitored domains
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex h-8 items-center gap-1.5 rounded-lg border border-[var(--border)] bg-[var(--bg-card)] px-3 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:border-[var(--border-light)]">
              <Download className="h-3.5 w-3.5" /> Export CSV
            </button>
            <button className="flex h-8 items-center gap-1.5 rounded-lg bg-[#3B82F6] px-3 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]">
              <Plus className="h-3.5 w-3.5" /> Add Domain
            </button>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-5 gap-3">
          {statCards.map((s) => (
            <div key={s.label} className="relative overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--bg-card)] p-4">
              <div className="absolute inset-x-0 top-0 h-0.5" style={{ background: s.color }} />
              <p className="text-[11px] font-semibold uppercase tracking-[0.5px] text-[var(--text-muted)]">{s.label}</p>
              <p className="mt-1 font-tabular text-2xl font-bold" style={{ color: s.color }}>
                {s.value.toLocaleString()}
              </p>
            </div>
          ))}
        </div>

        {/* Table card */}
        <div className="rounded-xl border border-[var(--border)] bg-[var(--bg-card)]">
          {/* Filter bar */}
          <div className="flex flex-wrap items-center gap-2 border-b border-[var(--border)] px-4 py-3">
            <div className="flex h-8 items-center gap-2 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-3 min-w-[220px] flex-1">
              <Search className="h-3.5 w-3.5 flex-shrink-0 text-[var(--text-muted)]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter by subdomain, IP, technology…"
                className="flex-1 bg-transparent text-sm text-[var(--text-primary)] placeholder-[var(--text-faint)] outline-none"
              />
            </div>
            {["all","alive","at-risk","cloud"].map((f) => (
              <button
                key={f}
                onClick={() => setStatusFilter(f)}
                className={cn(
                  "h-7 rounded-full border px-3 text-xs font-medium capitalize transition-colors",
                  statusFilter === f
                    ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                    : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border-light)] hover:text-[var(--text-secondary)]"
                )}
              >
                {f === "at-risk" ? "At Risk" : f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
            <select
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="h-7 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-2 text-xs text-[var(--text-muted)] outline-none"
            >
              <option value="">All Risk Levels</option>
              {RISK_LEVELS.filter(r => r).map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
            <select className="h-7 rounded-lg border border-[var(--border)] bg-[var(--bg-base)] px-2 text-xs text-[var(--text-muted)] outline-none">
              <option>All Technologies</option>
              <option>Nginx</option><option>Apache</option>
              <option>WordPress</option><option>Node.js</option>
            </select>
          </div>

          {/* Table */}
          {filtered.length === 0 ? (
            <NoAssetsEmpty />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full" role="grid">
                <thead>
                  <tr className="border-b border-[var(--border)]">
                    {["Subdomain","Status","IP Address","Technologies","Open Ports","Risk","Last Seen"].map((h) => (
                      <th key={h} className="whitespace-nowrap px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.5px] text-[var(--text-muted)]">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.slice((page - 1) * pageSize, page * pageSize).map((asset) => (
                    <tr
                      key={asset.id}
                      className="group cursor-pointer border-b border-[var(--border)] transition-colors hover:bg-[var(--bg-elevated)] last:border-0"
                      onClick={() => handleRowClick(asset)}
                    >
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs font-semibold text-[var(--text-primary)] transition-colors group-hover:text-[#3B82F6]">
                          {asset.subdomain}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5">
                          <span className={cn("h-1.5 w-1.5 rounded-full", asset.isAlive ? "bg-[#10B981]" : "bg-[#EF4444]")} />
                          <span className={cn("text-xs font-medium", asset.isAlive ? "text-[#10B981]" : "text-[#EF4444]")}>
                            {asset.isAlive ? "Alive" : "Dead"}
                          </span>
                          <span className="font-tabular text-xs text-[var(--text-muted)]">
                            {asset.httpsStatus ?? asset.httpStatus ?? "—"}
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs text-[var(--text-muted)]">{asset.ipAddress}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {asset.technologies.slice(0, 3).map((t) => (
                            <span
                              key={t}
                              className={cn(
                                "rounded px-1.5 py-0.5 text-[10px] font-medium",
                                (t.includes("5.6") || t.includes("2.2") || t.includes("2.4.18"))
                                  ? "bg-[rgba(239,68,68,0.1)] text-[#EF4444]"
                                  : "bg-[var(--bg-elevated)] text-[var(--text-muted)]"
                              )}
                            >
                              {t}
                            </span>
                          ))}
                          {asset.technologies.length > 3 && (
                            <span className="rounded px-1.5 py-0.5 text-[10px] text-[var(--text-muted)]">
                              +{asset.technologies.length - 3}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs text-[var(--text-muted)]">
                          {asset.openPorts.join(", ") || "—"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <SeverityBadge severity={asset.riskLevel} dot />
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs text-[var(--text-muted)]">{timeAgo(asset.lastSeenAt)}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {filtered.length > 0 && (
            <div className="flex items-center justify-between border-t border-[var(--border)] px-4 py-3">
              <span className="text-xs text-[var(--text-muted)]">
                Showing {Math.min(filtered.length, pageSize)} of {filtered.length} assets
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="flex h-7 w-7 items-center justify-center rounded border border-[var(--border)] text-[var(--text-muted)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)] disabled:opacity-40"
                >
                  <ChevronLeft className="h-3.5 w-3.5" />
                </button>
                {[1, 2, 3].map(p => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={cn(
                      "flex h-7 w-7 items-center justify-center rounded border text-xs font-medium transition-colors",
                      page === p
                        ? "border-[rgba(59,130,246,0.3)] bg-[rgba(59,130,246,0.1)] text-[#3B82F6]"
                        : "border-[var(--border)] text-[var(--text-muted)] hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
                    )}
                  >
                    {p}
                  </button>
                ))}
                <button
                  onClick={() => setPage(p => p + 1)}
                  disabled={page >= Math.ceil(filtered.length / pageSize)}
                  className="flex h-7 w-7 items-center justify-center rounded border border-[var(--border)] text-[var(--text-muted)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)] disabled:opacity-40"
                >
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Asset Detail Drawer */}
      <AssetDrawer
        asset={assetDrawerData}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
      />
    </>
  );
}
