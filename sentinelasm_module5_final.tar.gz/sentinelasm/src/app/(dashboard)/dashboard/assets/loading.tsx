import { AssetsSkeleton } from "@/components/ui/Skeletons";
export default function AssetsLoading() {
  return <AssetsSkeleton />;
}
