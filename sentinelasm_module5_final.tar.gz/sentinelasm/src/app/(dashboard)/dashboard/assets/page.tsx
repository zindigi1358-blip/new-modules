import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { AssetsClient } from "./AssetsClient";

export const metadata: Metadata = { title: "Assets" };
export const revalidate = 60;

export default async function AssetsPage() {
  const session = await requireSession();

  const [totalAssets, aliveAssets, cloudAssets, publicBuckets, riskyPorts] = await Promise.all([
    db.asset.count({ where: { organizationId: session.orgId } }),
    db.asset.count({ where: { organizationId: session.orgId, isAlive: true } }),
    db.asset.count({ where: { organizationId: session.orgId, assetType: "CLOUD_ASSET" } }),
    db.asset.count({ where: { organizationId: session.orgId, assetType: "CLOUD_ASSET", isPublic: true } }),
    db.asset.count({
      where: {
        organizationId: session.orgId,
        openPorts: { hasSome: [21, 23, 3389, 5900, 27017, 6379, 9200, 2375] },
      },
    }),
  ]);

  const ipCount = await db.asset.count({
    where: { organizationId: session.orgId, assetType: "IP_ADDRESS" },
  });

  return (
    <AssetsClient
      stats={{ totalAssets, aliveAssets, cloudAssets, publicBuckets, riskyPorts, ipCount }}
      orgId={session.orgId}
    />
  );
}
