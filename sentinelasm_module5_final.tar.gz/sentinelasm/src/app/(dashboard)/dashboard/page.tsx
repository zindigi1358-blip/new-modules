import type { Metadata } from "next";
import { requireSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { DashboardClient } from "./DashboardClient";
import type { DashboardStats, RiskDistribution } from "@/types";

export const metadata: Metadata = { title: "Dashboard" };

// Revalidate every 60 seconds
export const revalidate = 60;

async function getDashboardData(orgId: string) {
  const [
    totalAssets,
    aliveAssets,
    criticalFindings,
    highFindings,
    openFindings,
    kevFindings,
    resolvedThisMonth,
    cloudAssets,
    publicBuckets,
    recentScans,
    recentNotifications,
  ] = await Promise.all([
    db.asset.count({ where: { organizationId: orgId } }),
    db.asset.count({ where: { organizationId: orgId, isAlive: true } }),
    db.finding.count({ where: { organizationId: orgId, severity: "CRITICAL", status: { not: "RESOLVED" } } }),
    db.finding.count({ where: { organizationId: orgId, severity: "HIGH",     status: { not: "RESOLVED" } } }),
    db.finding.count({ where: { organizationId: orgId, status: { not: "RESOLVED" } } }),
    db.finding.count({ where: { organizationId: orgId, isKev: true, status: { not: "RESOLVED" } } }),
    db.finding.count({
      where: {
        organizationId: orgId,
        status:         "RESOLVED",
        resolvedAt:     { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
      },
    }),
    db.asset.count({ where: { organizationId: orgId, assetType: "CLOUD_ASSET" } }),
    db.asset.count({ where: { organizationId: orgId, assetType: "CLOUD_ASSET", isPublic: true } }),
    db.scan.findMany({
      where:   { organizationId: orgId },
      orderBy: { createdAt: "desc" },
      take:    5,
      select:  { id: true, domain: true, status: true, createdAt: true, findingsCount: true, aliveAssets: true, durationSecs: true },
    }),
    db.notification.findMany({
      where:   { organizationId: orgId },
      orderBy: { createdAt: "desc" },
      take:    6,
      select:  { id: true, title: true, body: true, severity: true, isRead: true, linkTo: true, createdAt: true },
    }),
  ]);

  const riskDistribution: RiskDistribution = {
    critical: criticalFindings,
    high:     highFindings,
    medium:   await db.finding.count({ where: { organizationId: orgId, severity: "MEDIUM", status: { not: "RESOLVED" } } }),
    low:      await db.finding.count({ where: { organizationId: orgId, severity: "LOW",    status: { not: "RESOLVED" } } }),
    info:     await db.finding.count({ where: { organizationId: orgId, severity: "INFO",   status: { not: "RESOLVED" } } }),
  };

  // Security score: 100 - weighted penalty
  const criticalPenalty = Math.min(criticalFindings * 8, 40);
  const highPenalty     = Math.min(highFindings     * 3, 20);
  const kevPenalty      = Math.min(kevFindings       * 5, 15);
  const securityScore   = Math.max(0, 100 - criticalPenalty - highPenalty - kevPenalty);

  const stats: DashboardStats = {
    securityScore,
    scoreDelta:        4,       // TODO: compare to last week's score
    totalAssets,
    assetsDelta:       12,
    aliveSubdomains:   aliveAssets,
    subdomainsDelta:   -3,
    criticalFindings,
    criticalDelta:     2,
    highFindings,
    openCves:          openFindings,
    kevMatches:        kevFindings,
    credLeaks:         3,       // from Module 1 GitHub scan
    cloudAssets,
    publicBuckets,
    resolvedThisMonth,
  };

  return { stats, riskDistribution, recentScans, recentNotifications };
}

export default async function DashboardPage() {
  const session = await requireSession();
  const data    = await getDashboardData(session.orgId);

  return <DashboardClient {...data} orgName={session.orgName} />;
}
