import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { Sidebar } from "@/components/layout/SidebarV2";
import { Topbar } from "@/components/layout/TopbarV2";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Auth guard — redirect unauthenticated users to login
  const session = await getSession();
  if (!session) redirect("/login");

  // Fetch unread notification count for topbar badge
  const unreadCount = await db.notification.count({
    where: {
      organizationId: session.orgId,
      isRead:         false,
    },
  });

  const org = await db.organization.findUnique({
    where:  { id: session.orgId },
    select: { plan: true },
  });

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--bg-base)]">
      <Sidebar
        session={session}
        orgName={session.orgName}
        orgPlan={org?.plan ?? "STARTER"}
      />
      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <Topbar
          orgName={session.orgName}
          unreadCount={unreadCount}
        />
        <main
          id="main-content"
          className="flex-1 overflow-y-auto bg-[var(--bg-base)]"
          tabIndex={-1}
        >
          <div className="mx-auto max-w-[1400px] p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
