"use client";

import { useEffect } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

export default function DashboardError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log to error reporting service (Sentry etc.) in production
    console.error("[Dashboard Error]", error);
  }, [error]);

  return (
    <div className="flex flex-col items-center justify-center py-24 text-center">
      <div className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-[rgba(239,68,68,0.1)]">
        <AlertTriangle className="h-8 w-8 text-[#EF4444]" />
      </div>

      <h2 className="mb-2 text-lg font-bold text-[var(--text-primary)]">
        Something went wrong
      </h2>
      <p className="mb-1 max-w-sm text-sm text-[var(--text-muted)]">
        {error.message || "An unexpected error occurred while loading this page."}
      </p>
      {error.digest && (
        <p className="mb-6 font-mono text-[10px] text-[var(--text-faint)]">
          Error ID: {error.digest}
        </p>
      )}

      <div className="flex gap-3">
        <button
          onClick={reset}
          className="flex items-center gap-2 rounded-lg bg-[#3B82F6] px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-[#1D4ED8]"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Try again
        </button>
        <button
          onClick={() => (window.location.href = "/dashboard")}
          className="flex items-center gap-2 rounded-lg border border-[var(--border)] px-4 py-2 text-sm font-medium text-[var(--text-secondary)] transition-colors hover:border-[var(--border-light)] hover:text-[var(--text-primary)]"
        >
          Go to Dashboard
        </button>
      </div>
    </div>
  );
}
