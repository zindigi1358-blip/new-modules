import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import {
  ok, created, badRequest, handleRouteError,
  parsePagination, paginationMeta,
} from "@/lib/api";
import { isValidDomain } from "@/lib/utils";
import type { Prisma } from "@prisma/client";

const createScanSchema = z.object({
  domain:     z.string().min(1).refine(isValidDomain, { message: "Invalid domain format" }),
  scanPorts:  z.boolean().default(true),
  scanCloud:  z.boolean().default(true),
  scanGithub: z.boolean().default(true),
});

export async function GET(req: NextRequest) {
  try {
    const session = await requireSession();
    const { page, pageSize } = parsePagination(req.nextUrl.searchParams);

    const status = req.nextUrl.searchParams.get("status");
    const where: Prisma.ScanWhereInput = {
      organizationId: session.orgId,
      ...(status && { status: status as Prisma.EnumScanStatusFilter }),
    };

    const [items, total] = await Promise.all([
      db.scan.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip:    (page - 1) * pageSize,
        take:    pageSize,
        include: { _count: { select: { findings: true } } },
      }),
      db.scan.count({ where }),
    ]);

    return ok(items, paginationMeta(total, page, pageSize));
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ANALYST"); // Viewers cannot start scans

    const body = await req.json();
    const data = createScanSchema.parse(body);

    // Check plan limits
    const org = await db.organization.findUniqueOrThrow({
      where:  { id: session.orgId },
      select: { maxScansMonth: true, plan: true },
    });

    const scansThisMonth = await db.scan.count({
      where: {
        organizationId: session.orgId,
        createdAt:      { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) },
      },
    });

    if (scansThisMonth >= org.maxScansMonth) {
      return badRequest(
        `Monthly scan limit reached (${org.maxScansMonth} scans). Upgrade your plan to scan more.`
      );
    }

    // Check domain is in monitored list
    let monitoredDomain = await db.monitoredDomain.findFirst({
      where: { organizationId: session.orgId, domain: data.domain },
    });

    if (!monitoredDomain) {
      monitoredDomain = await db.monitoredDomain.create({
        data: { organizationId: session.orgId, domain: data.domain },
      });
    }

    // Create scan record
    const scan = await db.scan.create({
      data: {
        organizationId: session.orgId,
        domainId:       monitoredDomain.id,
        domain:         data.domain,
        status:         "QUEUED",
        triggeredBy:    session.userId,
        scanOptions: {
          scanPorts:  data.scanPorts,
          scanCloud:  data.scanCloud,
          scanGithub: data.scanGithub,
        },
      },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "SCAN_STARTED",
        target:         `scan:${scan.id}`,
        metadata:       { domain: data.domain },
      },
    });

    // In production: dispatch to background job queue (BullMQ / Celery)
    // await scanQueue.add("run-scan", { scanId: scan.id, ...data });

    return created(scan);
  } catch (err) {
    return handleRouteError(err);
  }
}
