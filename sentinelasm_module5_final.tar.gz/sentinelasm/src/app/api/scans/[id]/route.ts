import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, notFound, handleRouteError } from "@/lib/api";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();

    const scan = await db.scan.findFirst({
      where:   { id: params.id, organizationId: session.orgId },
      include: {
        findings: {
          orderBy: { riskScore: "desc" },
          take:    10,
          select:  { id: true, title: true, severity: true, riskScore: true, affectedAsset: true },
        },
        _count: { select: { findings: true } },
      },
    });

    if (!scan) return notFound("Scan");
    return ok(scan);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ANALYST");

    const scan = await db.scan.findFirst({
      where: { id: params.id, organizationId: session.orgId },
    });
    if (!scan) return notFound("Scan");

    if (!["QUEUED","RUNNING"].includes(scan.status)) {
      return ok({ message: "Scan is not in a cancellable state" });
    }

    await db.scan.update({
      where: { id: params.id },
      data:  { status: "CANCELLED" },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "SCAN_CANCELLED",
        target:         `scan:${params.id}`,
        metadata:       { domain: scan.domain },
      },
    });

    return ok({ cancelled: true });
  } catch (err) {
    return handleRouteError(err);
  }
}
