import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Server-Sent Events endpoint for real-time scan progress.
 * Client connects once and receives updates as the scan progresses.
 *
 * Usage:
 *   const es = new EventSource(`/api/scans/${scanId}/stream`);
 *   es.onmessage = (e) => { const data = JSON.parse(e.data); ... };
 *   es.addEventListener("complete", () => es.close());
 */
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();

    // Verify this scan belongs to the user's org
    const scan = await db.scan.findFirst({
      where: { id: params.id, organizationId: session.orgId },
    });

    if (!scan) {
      return new Response("Scan not found", { status: 404 });
    }

    const encoder = new TextEncoder();
    let intervalId: ReturnType<typeof setInterval>;
    let closed = false;

    const stream = new ReadableStream({
      start(controller) {
        // Send initial state immediately
        const send = (event: string, data: object) => {
          if (closed) return;
          try {
            const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
            controller.enqueue(encoder.encode(msg));
          } catch {
            closed = true;
          }
        };

        // Poll database every 2 seconds for scan updates
        intervalId = setInterval(async () => {
          if (closed) {
            clearInterval(intervalId);
            return;
          }

          try {
            const updated = await db.scan.findUnique({
              where: { id: params.id },
              select: {
                id:           true,
                status:       true,
                progress:     true,
                currentModule: true,
                totalAssets:  true,
                aliveAssets:  true,
                findingsCount:true,
                errorMessage: true,
                completedAt:  true,
              },
            });

            if (!updated) {
              clearInterval(intervalId);
              controller.close();
              return;
            }

            send("progress", updated);

            // Stop polling when scan is done
            if (["COMPLETED","FAILED","CANCELLED"].includes(updated.status)) {
              send("complete", { status: updated.status });
              clearInterval(intervalId);
              closed = true;
              controller.close();
            }
          } catch {
            clearInterval(intervalId);
          }
        }, 2000);

        // Heartbeat every 15s to keep connection alive through proxies
        const heartbeat = setInterval(() => {
          if (closed) { clearInterval(heartbeat); return; }
          try {
            controller.enqueue(encoder.encode(": heartbeat\n\n"));
          } catch {
            closed = true;
            clearInterval(heartbeat);
          }
        }, 15000);
      },
      cancel() {
        closed = true;
        clearInterval(intervalId);
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type":                "text/event-stream",
        "Cache-Control":               "no-cache, no-transform",
        "Connection":                  "keep-alive",
        "X-Accel-Buffering":           "no",  // Disable Nginx buffering
        "Access-Control-Allow-Origin": "*",
      },
    });
  } catch {
    return new Response("Unauthorized", { status: 401 });
  }
}
