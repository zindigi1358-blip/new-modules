import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { ok, handleRouteError } from "@/lib/api";

export async function GET(req: NextRequest) {
  try {
    const session  = await requireSession();
    const unreadOnly = req.nextUrl.searchParams.get("unread") === "true";

    const notifications = await db.notification.findMany({
      where: {
        organizationId: session.orgId,
        ...(unreadOnly && { isRead: false }),
      },
      orderBy: { createdAt: "desc" },
      take:    50,
    });

    const unreadCount = await db.notification.count({
      where: { organizationId: session.orgId, isRead: false },
    });

    return ok({ notifications, unreadCount });
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await requireSession();
    const body    = await req.json();

    if (body.markAllRead) {
      await db.notification.updateMany({
        where: { organizationId: session.orgId, isRead: false },
        data:  { isRead: true },
      });
      return ok({ updated: true });
    }

    if (body.id) {
      await db.notification.updateMany({
        where: { id: body.id, organizationId: session.orgId },
        data:  { isRead: true },
      });
      return ok({ updated: true });
    }

    return ok({ updated: false });
  } catch (err) {
    return handleRouteError(err);
  }
}
