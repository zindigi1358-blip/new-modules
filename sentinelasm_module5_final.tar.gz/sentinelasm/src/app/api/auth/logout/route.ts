import { NextRequest, NextResponse } from "next/server";
import { clearSessionCookie, getSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { ok } from "@/lib/api";

export async function POST(_req: NextRequest) {
  const session = await getSession();

  if (session) {
    // Invalidate the session record
    await db.session.deleteMany({
      where: { userId: session.userId },
    }).catch(() => {});

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "LOGOUT",
      },
    }).catch(() => {});
  }

  await clearSessionCookie();
  return ok({ redirectTo: "/login" });
}
