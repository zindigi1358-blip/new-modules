import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createToken, setSessionCookie } from "@/lib/auth";
import { created, conflict, handleRouteError, checkRateLimit, tooManyRequests } from "@/lib/api";
import { slugify } from "@/lib/utils";

const registerSchema = z.object({
  name:             z.string().min(2).max(80),
  email:            z.string().email(),
  password:         z.string().min(8).max(128),
  organizationName: z.string().min(2).max(100),
});

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const { allowed } = checkRateLimit(`auth:register:${ip}`, 5, 3600);
    if (!allowed) return tooManyRequests(3600);

    const body = await req.json();
    const data = registerSchema.parse(body);

    const existing = await db.user.findUnique({
      where: { email: data.email.toLowerCase() },
    });
    if (existing) {
      return conflict("An account with this email already exists. Try signing in instead.");
    }

    const passwordHash = await bcrypt.hash(data.password, 12);

    // Generate unique org slug
    let slug = slugify(data.organizationName);
    const slugExists = await db.organization.findUnique({ where: { slug } });
    if (slugExists) slug = `${slug}-${Math.random().toString(36).slice(2, 7)}`;

    // Create user + org + membership in one transaction
    const { user, org, member } = await db.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          name:         data.name,
          email:        data.email.toLowerCase(),
          passwordHash,
        },
      });

      const org = await tx.organization.create({
        data: {
          name:         data.organizationName,
          slug,
          plan:         "STARTER",
          maxAssets:    500,
          maxScansMonth: 50,
          maxMembers:   5,
        },
      });

      const member = await tx.organizationMember.create({
        data: {
          userId:         user.id,
          organizationId: org.id,
          role:           "OWNER",
        },
      });

      await tx.auditLog.create({
        data: {
          organizationId: org.id,
          userId:         user.id,
          action:         "LOGIN",
          metadata:       { event: "registration" },
          ipAddress:      ip,
        },
      });

      return { user, org, member };
    });

    // Create JWT and set cookie
    const token = await createToken({
      userId:    user.id,
      email:     user.email,
      name:      user.name,
      orgId:     org.id,
      orgSlug:   org.slug,
      orgName:   org.name,
      role:      member.role,
      sessionId: crypto.randomUUID(),
    });

    await setSessionCookie(token);

    return created({ redirectTo: "/dashboard" });
  } catch (err) {
    return handleRouteError(err);
  }
}
