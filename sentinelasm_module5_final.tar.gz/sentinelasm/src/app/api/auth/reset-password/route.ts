import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { ok, badRequest, handleRouteError } from "@/lib/api";

const schema = z.object({
  token:    z.string().min(1),
  password: z.string().min(8).max(128),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { token, password } = schema.parse(body);

    // Find the reset session
    const session = await db.session.findFirst({
      where: {
        token:     `reset_${token}`,
        expiresAt: { gt: new Date() },
      },
      include: { user: true },
    });

    if (!session) {
      return badRequest("This reset link is invalid or has expired. Please request a new one.");
    }

    const newHash = await bcrypt.hash(password, 12);

    // Update password + delete all sessions (forces re-login)
    await db.$transaction([
      db.user.update({
        where: { id: session.userId },
        data:  { passwordHash: newHash },
      }),
      db.session.deleteMany({
        where: { userId: session.userId },
      }),
    ]);

    return ok({ reset: true });
  } catch (err) {
    return handleRouteError(err);
  }
}
