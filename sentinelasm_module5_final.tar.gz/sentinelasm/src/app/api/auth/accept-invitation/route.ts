import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { createToken, setSessionCookie } from "@/lib/auth";
import { ok, badRequest, handleRouteError } from "@/lib/api";

const schema = z.object({
  token:    z.string().min(1),
  password: z.string().min(8),
  name:     z.string().min(2).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const data = schema.parse(body);

    // Validate invitation
    const invitation = await db.invitation.findFirst({
      where: {
        token:      data.token,
        acceptedAt: null,
        expiresAt:  { gt: new Date() },
      },
      include: {
        organization: true,
      },
    });

    if (!invitation) {
      return badRequest("This invitation link is invalid or has expired.");
    }

    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";

    // Check if user already exists
    let user = await db.user.findUnique({
      where: { email: invitation.email },
    });

    if (user) {
      // Existing user — verify password
      const valid = await bcrypt.compare(data.password, user.passwordHash);
      if (!valid) return badRequest("Incorrect password. Please try again.");
    } else {
      // New user — require name
      if (!data.name) return badRequest("Name is required for new accounts.");
      const passwordHash = await bcrypt.hash(data.password, 12);
      user = await db.user.create({
        data: {
          name:         data.name,
          email:        invitation.email,
          passwordHash,
        },
      });
    }

    // Check not already a member
    const existing = await db.organizationMember.findFirst({
      where: { organizationId: invitation.organizationId, userId: user.id },
    });

    if (!existing) {
      await db.organizationMember.create({
        data: {
          organizationId: invitation.organizationId,
          userId:         user.id,
          role:           invitation.role,
        },
      });
    }

    // Mark invitation accepted
    await db.invitation.update({
      where: { id: invitation.id },
      data:  { acceptedAt: new Date() },
    });

    // Audit log
    await db.auditLog.create({
      data: {
        organizationId: invitation.organizationId,
        userId:         user.id,
        action:         "LOGIN",
        ipAddress:      ip,
        metadata:       { event: "invitation_accepted" },
      },
    });

    // Create session
    const sessionRecord = await db.session.create({
      data: {
        userId:    user.id,
        token:     crypto.randomUUID(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        ipAddress: ip,
      },
    });

    const token = await createToken({
      userId:    user.id,
      email:     user.email,
      name:      user.name,
      orgId:     invitation.organizationId,
      orgSlug:   invitation.organization.slug,
      orgName:   invitation.organization.name,
      role:      invitation.role,
      sessionId: sessionRecord.id,
    });

    await setSessionCookie(token);
    return ok({ redirectTo: "/dashboard" });
  } catch (err) {
    return handleRouteError(err);
  }
}
