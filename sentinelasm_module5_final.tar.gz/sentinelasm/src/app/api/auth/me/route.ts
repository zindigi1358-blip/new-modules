import { NextRequest } from "next/server";
import { getSession } from "@/lib/auth";
import { ok, unauthorized } from "@/lib/api";

export async function GET(_req: NextRequest) {
  const session = await getSession();
  if (!session) return unauthorized();
  // Return safe subset — never expose sessionId or internal fields
  return ok({
    userId:  session.userId,
    email:   session.email,
    name:    session.name,
    orgId:   session.orgId,
    orgSlug: session.orgSlug,
    orgName: session.orgName,
    role:    session.role,
  });
}
