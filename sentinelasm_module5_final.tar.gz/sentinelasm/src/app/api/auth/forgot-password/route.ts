import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, handleRouteError, checkRateLimit, tooManyRequests } from "@/lib/api";

const schema = z.object({ email: z.string().email() });

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
    const { allowed } = checkRateLimit(`auth:forgot:${ip}`, 5, 3600);
    if (!allowed) return tooManyRequests(3600);

    const body = await req.json();
    const { email } = schema.parse(body);

    const user = await db.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    // Always return success — never leak whether email exists
    if (!user) return ok({ sent: true });

    // Create a short-lived reset token stored in sessions table
    const token    = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await db.session.create({
      data: {
        userId:    user.id,
        token:     `reset_${token}`,
        expiresAt,
        ipAddress: ip,
      },
    });

    // In production: send email with reset link
    // await sendResetEmail({
    //   to:   user.email,
    //   name: user.name,
    //   url:  `${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${token}`,
    // });

    console.log(`[Auth] Password reset link for ${email}: /reset-password?token=${token}`);

    return ok({ sent: true });
  } catch (err) {
    return handleRouteError(err);
  }
}
