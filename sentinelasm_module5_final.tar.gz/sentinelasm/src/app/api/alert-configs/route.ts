import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, handleRouteError } from "@/lib/api";
import type { AlertChannel, AlertSeverityLevel } from "@prisma/client";

const configSchema = z.object({
  channel:         z.enum(["DISCORD","SLACK","EMAIL","WEBHOOK","IN_APP"] as const),
  isEnabled:       z.boolean(),
  minSeverity:     z.enum(["CRITICAL","HIGH","MEDIUM","LOW","INFO"] as const),
  webhookUrl:      z.string().url().optional().nullable(),
  emailRecipients: z.array(z.string().email()).optional(),
  sendOnNewAsset:  z.boolean().default(true),
  sendOnScanDone:  z.boolean().default(true),
  sendOnFindings:  z.boolean().default(true),
  sendDailyDigest: z.boolean().default(true),
  sendWeeklyReport:z.boolean().default(true),
});

export async function GET(_req: NextRequest) {
  try {
    const session = await requireSession();
    const configs = await db.alertConfig.findMany({
      where: { organizationId: session.orgId },
    });
    return ok(configs);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const body    = await req.json();
    const configs = z.array(configSchema).parse(body);

    // Upsert each config by channel
    const results = await Promise.all(
      configs.map(async (cfg) => {
        const existing = await db.alertConfig.findFirst({
          where: { organizationId: session.orgId, channel: cfg.channel as AlertChannel },
        });

        if (existing) {
          return db.alertConfig.update({
            where: { id: existing.id },
            data: {
              isEnabled:       cfg.isEnabled,
              minSeverity:     cfg.minSeverity as AlertSeverityLevel,
              webhookUrl:      cfg.webhookUrl ?? null,
              emailRecipients: cfg.emailRecipients ?? [],
              sendOnNewAsset:  cfg.sendOnNewAsset,
              sendOnScanDone:  cfg.sendOnScanDone,
              sendOnFindings:  cfg.sendOnFindings,
              sendDailyDigest: cfg.sendDailyDigest,
              sendWeeklyReport:cfg.sendWeeklyReport,
            },
          });
        } else {
          return db.alertConfig.create({
            data: {
              organizationId:  session.orgId,
              channel:         cfg.channel as AlertChannel,
              isEnabled:       cfg.isEnabled,
              minSeverity:     cfg.minSeverity as AlertSeverityLevel,
              webhookUrl:      cfg.webhookUrl ?? null,
              emailRecipients: cfg.emailRecipients ?? [],
              sendOnNewAsset:  cfg.sendOnNewAsset,
              sendOnScanDone:  cfg.sendOnScanDone,
              sendOnFindings:  cfg.sendOnFindings,
              sendDailyDigest: cfg.sendDailyDigest,
              sendWeeklyReport:cfg.sendWeeklyReport,
            },
          });
        }
      })
    );

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "SETTINGS_UPDATED",
        target:         "alert_configs",
        metadata:       { channels: configs.map(c => c.channel) },
      },
    });

    return ok(results);
  } catch (err) {
    return handleRouteError(err);
  }
}
