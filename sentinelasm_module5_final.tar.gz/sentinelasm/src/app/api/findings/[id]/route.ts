import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, notFound, handleRouteError } from "@/lib/api";

const updateSchema = z.object({
  status:     z.enum(["OPEN","IN_PROGRESS","RESOLVED","ACCEPTED_RISK","FALSE_POSITIVE"]).optional(),
  assignedTo: z.string().nullable().optional(),
});

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();

    const finding = await db.finding.findFirst({
      where:   { id: params.id, organizationId: session.orgId },
      include: {
        asset:   { select: { id: true, subdomain: true, ipAddress: true, assetType: true, openPorts: true, technologies: true } },
        assignee:{ select: { id: true, name: true, avatarUrl: true } },
        scan:    { select: { id: true, domain: true, completedAt: true } },
      },
    });

    if (!finding) return notFound("Finding");
    return ok(finding);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ANALYST");

    const body = await req.json();
    const data = updateSchema.parse(body);

    const finding = await db.finding.findFirst({
      where: { id: params.id, organizationId: session.orgId },
    });
    if (!finding) return notFound("Finding");

    const updateData: Record<string, unknown> = { ...data };

    if (data.status === "RESOLVED" && finding.status !== "RESOLVED") {
      updateData.resolvedAt = new Date();
      updateData.resolvedBy = session.userId;
    }

    const updated = await db.finding.update({
      where: { id: params.id },
      data:  updateData,
    });

    if (data.status === "RESOLVED") {
      await db.auditLog.create({
        data: {
          organizationId: session.orgId,
          userId:         session.userId,
          action:         "FINDING_RESOLVED",
          target:         `finding:${params.id}`,
          metadata:       { title: finding.title },
        },
      });
    }

    return ok(updated);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const finding = await db.finding.findFirst({
      where: { id: params.id, organizationId: session.orgId },
    });
    if (!finding) return notFound("Finding");

    await db.finding.delete({ where: { id: params.id } });
    return ok({ deleted: true });
  } catch (err) {
    return handleRouteError(err);
  }
}
