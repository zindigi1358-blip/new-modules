import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import {
  ok, unauthorized, handleRouteError,
  parsePagination, paginationMeta,
} from "@/lib/api";
import type { FindingSeverity, FindingStatus, Prisma } from "@prisma/client";

const querySchema = z.object({
  page:      z.coerce.number().int().positive().default(1),
  pageSize:  z.coerce.number().int().min(1).max(100).default(25),
  severity:  z.enum(["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]).optional(),
  status:    z.enum(["OPEN", "IN_PROGRESS", "RESOLVED", "ACCEPTED_RISK", "FALSE_POSITIVE"]).optional(),
  isKev:     z.enum(["true", "false"]).optional(),
  category:  z.string().optional(),
  search:    z.string().optional(),
  sortBy:    z.enum(["riskScore", "cvssScore", "createdAt", "updatedAt"]).default("riskScore"),
  sortDir:   z.enum(["asc", "desc"]).default("desc"),
  assetId:   z.string().optional(),
  scanId:    z.string().optional(),
});

export async function GET(req: NextRequest) {
  try {
    const session = await requireSession();

    const sp     = Object.fromEntries(req.nextUrl.searchParams);
    const params = querySchema.parse(sp);

    const where: Prisma.FindingWhereInput = {
      organizationId: session.orgId,
      ...(params.severity && { severity: params.severity as FindingSeverity }),
      ...(params.status   && { status:   params.status   as FindingStatus }),
      ...(params.isKev    && { isKev:    params.isKev === "true" }),
      ...(params.category && { category: params.category }),
      ...(params.assetId  && { assetId:  params.assetId }),
      ...(params.scanId   && { scanId:   params.scanId }),
      ...(params.search && {
        OR: [
          { title:         { contains: params.search, mode: "insensitive" } },
          { affectedAsset: { contains: params.search, mode: "insensitive" } },
          { cveIds:        { hasSome:  [params.search] } },
        ],
      }),
    };

    const [items, total] = await Promise.all([
      db.finding.findMany({
        where,
        orderBy: { [params.sortBy]: params.sortDir },
        skip:    (params.page - 1) * params.pageSize,
        take:    params.pageSize,
        include: {
          asset: {
            select: { id: true, subdomain: true, ipAddress: true, assetType: true },
          },
          assignee: {
            select: { id: true, name: true, avatarUrl: true },
          },
        },
      }),
      db.finding.count({ where }),
    ]);

    return ok(items, paginationMeta(total, params.page, params.pageSize));
  } catch (err) {
    return handleRouteError(err);
  }
}
