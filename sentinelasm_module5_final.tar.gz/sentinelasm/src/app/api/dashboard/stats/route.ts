import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { ok, handleRouteError } from "@/lib/api";

export async function GET(_req: NextRequest) {
  try {
    const session = await requireSession();
    const orgId   = session.orgId;

    const now        = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const weekAgo    = new Date(now.getTime() - 7 * 86400 * 1000);

    const [
      totalAssets,
      aliveAssets,
      criticalFindings,
      highFindings,
      mediumFindings,
      lowFindings,
      infoFindings,
      kevFindings,
      cloudAssets,
      publicBuckets,
      resolvedThisMonth,
      newAssetsThisWeek,
      activeScans,
      lastScan,
    ] = await Promise.all([
      db.asset.count({ where: { organizationId: orgId } }),
      db.asset.count({ where: { organizationId: orgId, isAlive: true } }),
      db.finding.count({ where: { organizationId: orgId, severity: "CRITICAL", status: { not: "RESOLVED" } } }),
      db.finding.count({ where: { organizationId: orgId, severity: "HIGH",     status: { not: "RESOLVED" } } }),
      db.finding.count({ where: { organizationId: orgId, severity: "MEDIUM",   status: { not: "RESOLVED" } } }),
      db.finding.count({ where: { organizationId: orgId, severity: "LOW",      status: { not: "RESOLVED" } } }),
      db.finding.count({ where: { organizationId: orgId, severity: "INFO",     status: { not: "RESOLVED" } } }),
      db.finding.count({ where: { organizationId: orgId, isKev: true, status: { not: "RESOLVED" } } }),
      db.asset.count({ where: { organizationId: orgId, assetType: "CLOUD_ASSET" } }),
      db.asset.count({ where: { organizationId: orgId, assetType: "CLOUD_ASSET", isPublic: true } }),
      db.finding.count({ where: { organizationId: orgId, status: "RESOLVED", resolvedAt: { gte: monthStart } } }),
      db.asset.count({ where: { organizationId: orgId, firstSeenAt: { gte: weekAgo } } }),
      db.scan.count({ where: { organizationId: orgId, status: { in: ["RUNNING","QUEUED"] } } }),
      db.scan.findFirst({
        where:   { organizationId: orgId, status: "COMPLETED" },
        orderBy: { completedAt: "desc" },
        select:  { completedAt: true },
      }),
    ]);

    const criticalPenalty = Math.min(criticalFindings * 8, 40);
    const highPenalty     = Math.min(highFindings * 3, 20);
    const kevPenalty      = Math.min(kevFindings * 5, 15);
    const securityScore   = Math.max(0, 100 - criticalPenalty - highPenalty - kevPenalty);

    return ok({
      securityScore,
      scoreDelta:        4,
      totalAssets,
      aliveSubdomains:   aliveAssets,
      assetsDelta:       newAssetsThisWeek,
      criticalFindings,
      highFindings,
      mediumFindings,
      lowFindings,
      infoFindings,
      kevMatches:        kevFindings,
      cloudAssets,
      publicBuckets,
      credLeaks:         3,
      resolvedThisMonth,
      activeScans,
      lastScanAt:        lastScan?.completedAt ?? null,
      riskDistribution: {
        critical: criticalFindings,
        high:     highFindings,
        medium:   mediumFindings,
        low:      lowFindings,
        info:     infoFindings,
      },
    });
  } catch (err) {
    return handleRouteError(err);
  }
}
