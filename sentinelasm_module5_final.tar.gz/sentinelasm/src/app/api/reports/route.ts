import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, created, handleRouteError } from "@/lib/api";
import type { ReportType } from "@prisma/client";

const generateSchema = z.object({
  reportType:  z.enum(["FULL_PENTEST","EXECUTIVE_SUMMARY","RISK_ONLY","COMPLIANCE","WEEKLY_DIGEST"] as const),
  clientName:  z.string().min(1).max(100),
  assessorName:z.string().max(100).default("SentinelASM Security"),
  scanId:      z.string().optional(),
});

export async function GET(_req: NextRequest) {
  try {
    const session = await requireSession();

    const reports = await db.report.findMany({
      where:   { organizationId: session.orgId },
      orderBy: { createdAt: "desc" },
      take:    20,
    });

    return ok(reports);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ANALYST");

    const body = await req.json();
    const data = generateSchema.parse(body);

    // Fetch latest scan data for this org
    const latestScan = data.scanId
      ? await db.scan.findFirst({ where: { id: data.scanId, organizationId: session.orgId } })
      : await db.scan.findFirst({
          where:   { organizationId: session.orgId, status: "COMPLETED" },
          orderBy: { completedAt: "desc" },
        });

    // Call Module 4 Python backend to generate the PDF
    const backendUrl = process.env.PYTHON_BACKEND_URL ?? "http://localhost:8000";
    const backendKey = process.env.PYTHON_BACKEND_API_KEY ?? "";

    let filePath: string | null = null;
    let fileSizeBytes: number | null = null;

    try {
      const genRes = await fetch(`${backendUrl}/api/generate-report`, {
        method:  "POST",
        headers: {
          "Content-Type":  "application/json",
          "X-Internal-Key": backendKey,
        },
        body: JSON.stringify({
          organizationId: session.orgId,
          reportType:     data.reportType,
          clientName:     data.clientName,
          assessorName:   data.assessorName,
          scanId:         latestScan?.id,
        }),
        signal: AbortSignal.timeout(120_000), // 2 min — PDF gen can be slow
      });

      if (genRes.ok) {
        const genData = await genRes.json();
        filePath      = genData.filePath      ?? null;
        fileSizeBytes = genData.fileSizeBytes ?? null;
      }
    } catch {
      // Backend unavailable — still record the report request, download fails gracefully
      console.warn("[Reports] Module 4 backend unavailable — report queued without file");
    }

    const report = await db.report.create({
      data: {
        organizationId: session.orgId,
        scanId:         latestScan?.id ?? null,
        reportType:     data.reportType as ReportType,
        title:          `${latestScan?.domain ?? "Unknown Domain"} — ${data.reportType.replace(/_/g, " ")}`,
        clientName:     data.clientName,
        assessorName:   data.assessorName,
        filePath,
        fileSizeBytes,
        generatedBy:    session.userId,
      },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "REPORT_GENERATED",
        target:         `report:${report.id}`,
        metadata:       { reportType: data.reportType, clientName: data.clientName },
      },
    });

    return created(report);
  } catch (err) {
    return handleRouteError(err);
  }
}
