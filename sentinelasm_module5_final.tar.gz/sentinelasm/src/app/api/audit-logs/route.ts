import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { ok, handleRouteError, parsePagination, paginationMeta } from "@/lib/api";

export async function GET(req: NextRequest) {
  try {
    const session         = await requireSession();
    const { page, pageSize } = parsePagination(req.nextUrl.searchParams);
    const action          = req.nextUrl.searchParams.get("action");
    const userId          = req.nextUrl.searchParams.get("userId");

    const where = {
      organizationId: session.orgId,
      ...(action && { action: action as any }),
      ...(userId && { userId }),
    };

    const [items, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip:    (page - 1) * pageSize,
        take:    pageSize,
        include: {
          user: { select: { id: true, name: true, email: true } },
        },
      }),
      db.auditLog.count({ where }),
    ]);

    return ok(items, paginationMeta(total, page, pageSize));
  } catch (err) {
    return handleRouteError(err);
  }
}
