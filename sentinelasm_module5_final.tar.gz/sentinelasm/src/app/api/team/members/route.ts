import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, notFound, forbidden, handleRouteError } from "@/lib/api";
import type { MemberRole } from "@prisma/client";

export async function GET(_req: NextRequest) {
  try {
    const session = await requireSession();

    const members = await db.organizationMember.findMany({
      where:   { organizationId: session.orgId },
      include: {
        user: {
          select: { id: true, name: true, email: true, avatarUrl: true, lastLoginAt: true },
        },
      },
      orderBy: { joinedAt: "asc" },
    });

    return ok(members);
  } catch (err) {
    return handleRouteError(err);
  }
}

const updateRoleSchema = z.object({
  userId: z.string(),
  role:   z.enum(["OWNER","ADMIN","ANALYST","VIEWER"] as const),
});

export async function PATCH(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const body = await req.json();
    const data = updateRoleSchema.parse(body);

    // Cannot change own role
    if (data.userId === session.userId) {
      return forbidden("You cannot change your own role");
    }

    // Only OWNER can promote to OWNER or ADMIN
    if (["OWNER","ADMIN"].includes(data.role) && session.role !== "OWNER") {
      return forbidden("Only owners can assign owner or admin roles");
    }

    const member = await db.organizationMember.findFirst({
      where: { organizationId: session.orgId, userId: data.userId },
    });
    if (!member) return notFound("Team member");

    const updated = await db.organizationMember.update({
      where: { id: member.id },
      data:  { role: data.role as MemberRole },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "ROLE_CHANGED",
        target:         `user:${data.userId}`,
        metadata:       { newRole: data.role, oldRole: member.role },
      },
    });

    return ok(updated);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const userId = req.nextUrl.searchParams.get("userId");
    if (!userId) return notFound("User ID");
    if (userId === session.userId) return forbidden("You cannot remove yourself");

    const member = await db.organizationMember.findFirst({
      where: { organizationId: session.orgId, userId },
    });
    if (!member) return notFound("Team member");

    // Cannot remove an OWNER
    if (member.role === "OWNER" && session.role !== "OWNER") {
      return forbidden("Only owners can remove other owners");
    }

    await db.organizationMember.delete({ where: { id: member.id } });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "MEMBER_REMOVED",
        target:         `user:${userId}`,
        metadata:       { removedRole: member.role },
      },
    });

    return ok({ removed: true });
  } catch (err) {
    return handleRouteError(err);
  }
}
