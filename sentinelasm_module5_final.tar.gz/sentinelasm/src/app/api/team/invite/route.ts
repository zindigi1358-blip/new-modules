import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, badRequest, conflict, handleRouteError } from "@/lib/api";
import type { MemberRole } from "@prisma/client";

const inviteSchema = z.object({
  email: z.string().email("Enter a valid email address"),
  role:  z.enum(["OWNER", "ADMIN", "ANALYST", "VIEWER"] as const),
});

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const body = await req.json();
    const data = inviteSchema.parse(body);

    // Check plan seat limit
    const [org, memberCount] = await Promise.all([
      db.organization.findUniqueOrThrow({
        where:  { id: session.orgId },
        select: { maxMembers: true },
      }),
      db.organizationMember.count({ where: { organizationId: session.orgId } }),
    ]);

    if (memberCount >= org.maxMembers) {
      return badRequest(
        `Team seat limit reached (${org.maxMembers} members). Upgrade your plan to invite more.`
      );
    }

    // Check not already a member
    const existingUser = await db.user.findUnique({
      where:   { email: data.email.toLowerCase() },
      include: { memberships: { where: { organizationId: session.orgId } } },
    });

    if (existingUser?.memberships.length) {
      return conflict("This user is already a member of your organization.");
    }

    // Cancel any existing pending invitation for this email
    await db.invitation.deleteMany({
      where: { organizationId: session.orgId, email: data.email.toLowerCase(), acceptedAt: null },
    });

    const invitation = await db.invitation.create({
      data: {
        organizationId: session.orgId,
        email:          data.email.toLowerCase(),
        role:           data.role as MemberRole,
        invitedBy:      session.userId,
        expiresAt:      new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
      },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "MEMBER_INVITED",
        target:         `invitation:${invitation.id}`,
        metadata:       { email: data.email, role: data.role },
      },
    });

    // In production: send invitation email here
    // await sendInvitationEmail({ to: data.email, token: invitation.token, orgName: session.orgName });

    return ok({ id: invitation.id, email: invitation.email, role: invitation.role, expiresAt: invitation.expiresAt });
  } catch (err) {
    return handleRouteError(err);
  }
}
