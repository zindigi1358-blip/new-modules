import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { db } from "@/lib/db";
import type { PlanTier } from "@prisma/client";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? "", {
  apiVersion: "2024-06-20",
});

const PRICE_TO_PLAN: Record<string, PlanTier> = {
  [process.env.STRIPE_PRICE_STARTER       ?? ""]: "STARTER",
  [process.env.STRIPE_PRICE_PROFESSIONAL  ?? ""]: "PROFESSIONAL",
  [process.env.STRIPE_PRICE_BUSINESS      ?? ""]: "BUSINESS",
};

const PLAN_LIMITS: Record<PlanTier, { maxAssets: number; maxScansMonth: number; maxMembers: number }> = {
  STARTER:      { maxAssets: 500,      maxScansMonth: 50,  maxMembers: 5   },
  PROFESSIONAL: { maxAssets: 5000,     maxScansMonth: 500, maxMembers: 25  },
  BUSINESS:     { maxAssets: 999999,   maxScansMonth: 9999, maxMembers: 100 },
  ENTERPRISE:   { maxAssets: 9999999,  maxScansMonth: 99999, maxMembers: 9999 },
};

export async function POST(req: NextRequest) {
  const body      = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature) {
    return new NextResponse("Missing stripe-signature header", { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET ?? ""
    );
  } catch (err) {
    console.error("[Stripe Webhook] Signature verification failed:", err);
    return new NextResponse("Invalid signature", { status: 400 });
  }

  try {
    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const sub       = event.data.object as Stripe.Subscription;
        const priceId   = sub.items.data[0]?.price.id ?? "";
        const plan      = PRICE_TO_PLAN[priceId] ?? "STARTER";
        const limits    = PLAN_LIMITS[plan];
        const expiresAt = new Date(sub.current_period_end * 1000);

        await db.organization.updateMany({
          where: { stripeCustomerId: sub.customer as string },
          data:  {
            stripeSubscriptionId: sub.id,
            plan,
            planExpiresAt: expiresAt,
            ...limits,
          },
        });
        break;
      }

      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        await db.organization.updateMany({
          where: { stripeCustomerId: sub.customer as string },
          data:  {
            stripeSubscriptionId: null,
            plan:                 "STARTER",
            planExpiresAt:        null,
            maxAssets:            500,
            maxScansMonth:        50,
            maxMembers:           5,
          },
        });
        break;
      }

      case "checkout.session.completed": {
        const checkout = event.data.object as Stripe.Checkout.Session;
        if (checkout.metadata?.["organizationId"]) {
          await db.organization.update({
            where: { id: checkout.metadata["organizationId"] },
            data:  { stripeCustomerId: checkout.customer as string },
          });
        }
        break;
      }

      default:
        // Unhandled event type — safe to ignore
        break;
    }
  } catch (err) {
    console.error("[Stripe Webhook] Handler error:", err);
    // Return 200 anyway to prevent Stripe retry loops on DB errors
  }

  return new NextResponse(null, { status: 200 });
}

// Disable body parsing — Stripe needs raw bytes for signature verification
export const config = { api: { bodyParser: false } };
