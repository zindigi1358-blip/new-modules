import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import {
  ok, handleRouteError,
  parsePagination, paginationMeta,
} from "@/lib/api";
import type { Prisma } from "@prisma/client";

const querySchema = z.object({
  search:    z.string().optional(),
  assetType: z.enum(["SUBDOMAIN","IP_ADDRESS","CLOUD_ASSET","GITHUB_REPO","API_ENDPOINT"]).optional(),
  isAlive:   z.enum(["true","false"]).optional(),
  isPublic:  z.enum(["true","false"]).optional(),
  sortBy:    z.enum(["lastSeenAt","firstSeenAt","subdomain"]).default("lastSeenAt"),
  sortDir:   z.enum(["asc","desc"]).default("desc"),
  page:      z.coerce.number().int().positive().default(1),
  pageSize:  z.coerce.number().int().min(1).max(100).default(25),
});

export async function GET(req: NextRequest) {
  try {
    const session = await requireSession();
    const sp      = Object.fromEntries(req.nextUrl.searchParams);
    const params  = querySchema.parse(sp);

    const where: Prisma.AssetWhereInput = {
      organizationId: session.orgId,
      ...(params.assetType && { assetType: params.assetType }),
      ...(params.isAlive   && { isAlive:  params.isAlive  === "true" }),
      ...(params.isPublic  && { isPublic: params.isPublic === "true" }),
      ...(params.search && {
        OR: [
          { subdomain:  { contains: params.search, mode: "insensitive" } },
          { ipAddress:  { contains: params.search, mode: "insensitive" } },
          { url:        { contains: params.search, mode: "insensitive" } },
        ],
      }),
    };

    const [items, total] = await Promise.all([
      db.asset.findMany({
        where,
        orderBy: { [params.sortBy]: params.sortDir },
        skip:    (params.page - 1) * params.pageSize,
        take:    params.pageSize,
        include: {
          findings: {
            where:  { status: { not: "RESOLVED" } },
            select: { id: true, severity: true, status: true },
          },
        },
      }),
      db.asset.count({ where }),
    ]);

    return ok(items, paginationMeta(total, params.page, params.pageSize));
  } catch (err) {
    return handleRouteError(err);
  }
}
