import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, notFound, handleRouteError } from "@/lib/api";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const key = await db.apiKey.findFirst({
      where: { id: params.id, organizationId: session.orgId },
    });
    if (!key) return notFound("API Key");

    await db.apiKey.update({
      where: { id: params.id },
      data:  { isActive: false },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "API_KEY_REVOKED",
        target:         `api_key:${params.id}`,
        metadata:       { name: key.name },
      },
    });

    return ok({ revoked: true });
  } catch (err) {
    return handleRouteError(err);
  }
}
