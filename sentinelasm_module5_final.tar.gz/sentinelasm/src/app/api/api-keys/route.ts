import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, created, handleRouteError } from "@/lib/api";

const AVAILABLE_SCOPES = [
  "scan:read", "scan:write",
  "assets:read",
  "findings:read", "findings:write",
  "reports:read", "reports:write",
];

const createKeySchema = z.object({
  name:      z.string().min(1).max(64),
  scopes:    z.array(z.enum(AVAILABLE_SCOPES as [string, ...string[]])).min(1),
  expiresAt: z.string().datetime().nullable().optional(),
});

export async function GET(_req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const keys = await db.apiKey.findMany({
      where:   { organizationId: session.orgId },
      orderBy: { createdAt: "desc" },
      select: {
        id: true, name: true, keyPrefix: true, scopes: true,
        isActive: true, lastUsedAt: true, lastUsedIp: true,
        expiresAt: true, createdBy: true, createdAt: true,
        // keyHash intentionally excluded — never return it
      },
    });

    return ok(keys);
  } catch (err) {
    return handleRouteError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const body = await req.json();
    const data = createKeySchema.parse(body);

    // Generate a cryptographically secure API key
    const rawBytes  = crypto.getRandomValues(new Uint8Array(32));
    const rawKey    = "sk_live_" + Buffer.from(rawBytes).toString("base64url");
    const keyPrefix = rawKey.slice(0, 16); // "sk_live_XXXXXXXX"
    const keyHash   = await bcrypt.hash(rawKey, 12);

    const apiKey = await db.apiKey.create({
      data: {
        organizationId: session.orgId,
        name:           data.name,
        keyHash,
        keyPrefix,
        scopes:         data.scopes,
        expiresAt:      data.expiresAt ? new Date(data.expiresAt) : null,
        createdBy:      session.userId,
      },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "API_KEY_CREATED",
        target:         `api_key:${apiKey.id}`,
        metadata:       { name: data.name, scopes: data.scopes },
      },
    });

    // Return rawKey ONCE — it's never stored in plain text
    return created({
      id:        apiKey.id,
      name:      apiKey.name,
      key:       rawKey,         // shown only on creation
      keyPrefix,
      scopes:    apiKey.scopes,
      expiresAt: apiKey.expiresAt,
      createdAt: apiKey.createdAt,
    });
  } catch (err) {
    return handleRouteError(err);
  }
}
