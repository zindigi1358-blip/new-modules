import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { ok, handleRouteError } from "@/lib/api";

// GET /api/organizations — list all orgs the current user belongs to
export async function GET(_req: NextRequest) {
  try {
    const session = await requireSession();

    const memberships = await db.organizationMember.findMany({
      where:   { userId: session.userId },
      include: {
        organization: {
          select: { id: true, name: true, slug: true, plan: true },
        },
      },
      orderBy: { joinedAt: "asc" },
    });

    const orgs = memberships.map(m => ({
      id:   m.organization.id,
      name: m.organization.name,
      slug: m.organization.slug,
      plan: m.organization.plan,
      role: m.role,
    }));

    return ok(orgs);
  } catch (err) {
    return handleRouteError(err);
  }
}
