import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, createToken, setSessionCookie } from "@/lib/auth";
import { ok, forbidden, handleRouteError } from "@/lib/api";

const schema = z.object({
  organizationId: z.string().min(1),
});

// POST /api/organizations/switch — switch active org context
export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    const body    = await req.json();
    const { organizationId } = schema.parse(body);

    // Verify membership
    const membership = await db.organizationMember.findFirst({
      where: { userId: session.userId, organizationId },
      include: {
        organization: {
          select: { id: true, name: true, slug: true },
        },
      },
    });

    if (!membership) {
      return forbidden("You are not a member of that organization");
    }

    // Issue a new JWT with the new org context
    const newToken = await createToken({
      userId:    session.userId,
      email:     session.email,
      name:      session.name,
      orgId:     membership.organizationId,
      orgSlug:   membership.organization.slug,
      orgName:   membership.organization.name,
      role:      membership.role,
      sessionId: session.sessionId,
    });

    await setSessionCookie(newToken);

    return ok({
      orgId:   membership.organizationId,
      orgName: membership.organization.name,
      role:    membership.role,
    });
  } catch (err) {
    return handleRouteError(err);
  }
}
