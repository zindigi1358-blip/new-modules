import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { created, handleRouteError } from "@/lib/api";
import { slugify } from "@/lib/utils";

const schema = z.object({
  name: z.string().min(2).max(100),
});

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    const body    = await req.json();
    const { name } = schema.parse(body);

    let slug = slugify(name);
    const existing = await db.organization.findUnique({ where: { slug } });
    if (existing) slug = `${slug}-${Math.random().toString(36).slice(2, 7)}`;

    const org = await db.$transaction(async (tx) => {
      const org = await tx.organization.create({
        data: {
          name,
          slug,
          plan:          "STARTER",
          maxAssets:     500,
          maxScansMonth: 50,
          maxMembers:    5,
        },
      });

      // Creator becomes OWNER
      await tx.organizationMember.create({
        data: {
          organizationId: org.id,
          userId:         session.userId,
          role:           "OWNER",
        },
      });

      await tx.auditLog.create({
        data: {
          organizationId: org.id,
          userId:         session.userId,
          action:         "SETTINGS_UPDATED",
          target:         "organization:created",
          metadata:       { name },
        },
      });

      return org;
    });

    return created({ id: org.id, name: org.name, slug: org.slug });
  } catch (err) {
    return handleRouteError(err);
  }
}
