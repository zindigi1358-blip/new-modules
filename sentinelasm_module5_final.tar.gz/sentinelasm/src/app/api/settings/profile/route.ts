import { NextRequest } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { requireSession } from "@/lib/auth";
import { ok, badRequest, unauthorized, handleRouteError } from "@/lib/api";

const profileSchema = z.object({
  name:     z.string().min(2).max(80).optional(),
  email:    z.string().email().optional(),
  timezone: z.string().max(60).optional(),
});

const passwordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword:     z.string().min(8).max(128),
});

export async function PATCH(req: NextRequest) {
  try {
    const session = await requireSession();
    const body    = await req.json();

    // Password change branch
    if (body.currentPassword !== undefined) {
      const data = passwordSchema.parse(body);

      const user = await db.user.findUniqueOrThrow({ where: { id: session.userId } });
      const valid = await bcrypt.compare(data.currentPassword, user.passwordHash);
      if (!valid) return unauthorized("Current password is incorrect");

      const newHash = await bcrypt.hash(data.newPassword, 12);
      await db.user.update({
        where: { id: session.userId },
        data:  { passwordHash: newHash },
      });

      // Invalidate all other sessions
      await db.session.deleteMany({
        where: { userId: session.userId, token: { not: session.sessionId } },
      });

      await db.auditLog.create({
        data: {
          organizationId: session.orgId,
          userId:         session.userId,
          action:         "SETTINGS_UPDATED",
          target:         "password",
        },
      });

      return ok({ updated: true });
    }

    // Profile update branch
    const data = profileSchema.parse(body);
    if (Object.keys(data).length === 0) return badRequest("No fields to update");

    if (data.email) {
      const existing = await db.user.findFirst({
        where: { email: data.email.toLowerCase(), NOT: { id: session.userId } },
      });
      if (existing) return badRequest("This email is already in use by another account");
    }

    const updated = await db.user.update({
      where: { id: session.userId },
      data: {
        ...(data.name  && { name: data.name }),
        ...(data.email && { email: data.email.toLowerCase() }),
      },
      select: { id: true, name: true, email: true },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "SETTINGS_UPDATED",
        target:         "profile",
        metadata:       { fields: Object.keys(data) },
      },
    });

    return ok(updated);
  } catch (err) {
    return handleRouteError(err);
  }
}
