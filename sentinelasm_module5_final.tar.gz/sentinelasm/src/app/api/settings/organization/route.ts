import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, handleRouteError } from "@/lib/api";

const orgSchema = z.object({
  name:         z.string().min(2).max(100).optional(),
  scanSchedule: z.string().optional(),
  retention:    z.coerce.number().int().min(0).max(3650).optional(),
  scanOptions: z.object({
    scanPorts:     z.boolean().optional(),
    scanCloud:     z.boolean().optional(),
    scanGithub:    z.boolean().optional(),
    scanLeaks:     z.boolean().optional(),
    matchCves:     z.boolean().optional(),
    enrichKev:     z.boolean().optional(),
  }).optional(),
  apiKeys: z.object({
    nvdApiKey:      z.string().optional(),
    vulturersApiKey: z.string().optional(),
    otxApiKey:      z.string().optional(),
    urlscanApiKey:  z.string().optional(),
  }).optional(),
});

export async function PATCH(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "ADMIN");

    const body = await req.json();
    const data = orgSchema.parse(body);

    const updated = await db.organization.update({
      where: { id: session.orgId },
      data:  {
        ...(data.name && { name: data.name }),
      },
      select: { id: true, name: true, slug: true, plan: true },
    });

    await db.auditLog.create({
      data: {
        organizationId: session.orgId,
        userId:         session.userId,
        action:         "SETTINGS_UPDATED",
        target:         "organization",
        metadata:       { fields: Object.keys(data) },
      },
    });

    return ok(updated);
  } catch (err) {
    return handleRouteError(err);
  }
}
