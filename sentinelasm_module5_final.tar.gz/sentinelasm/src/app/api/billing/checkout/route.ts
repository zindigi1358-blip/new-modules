import { NextRequest } from "next/server";
import { z } from "zod";
import Stripe from "stripe";
import { db } from "@/lib/db";
import { requireSession, requireRole } from "@/lib/auth";
import { ok, badRequest, handleRouteError } from "@/lib/api";
import type { PlanTier } from "@prisma/client";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY ?? "", {
  apiVersion: "2024-06-20",
});

const PRICE_IDS: Partial<Record<PlanTier, string>> = {
  STARTER:      process.env.STRIPE_PRICE_STARTER       ?? "",
  PROFESSIONAL: process.env.STRIPE_PRICE_PROFESSIONAL  ?? "",
  BUSINESS:     process.env.STRIPE_PRICE_BUSINESS      ?? "",
};

const checkoutSchema = z.object({
  plan: z.enum(["STARTER", "PROFESSIONAL", "BUSINESS"] as const),
});

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    requireRole(session.role, "OWNER");

    const body = await req.json();
    const { plan } = checkoutSchema.parse(body);

    const priceId = PRICE_IDS[plan];
    if (!priceId) {
      return badRequest(`Stripe price ID not configured for plan: ${plan}`);
    }

    const org = await db.organization.findUniqueOrThrow({
      where:  { id: session.orgId },
      select: { stripeCustomerId: true, name: true },
    });

    const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

    const checkoutSession = await stripe.checkout.sessions.create({
      mode:                "subscription",
      payment_method_types: ["card"],
      line_items:          [{ price: priceId, quantity: 1 }],
      customer:            org.stripeCustomerId ?? undefined,
      customer_creation:   org.stripeCustomerId ? undefined : "always",
      success_url:         `${appUrl}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url:          `${appUrl}/dashboard/billing?cancelled=true`,
      metadata:            { organizationId: session.orgId },
      subscription_data:   {
        metadata: { organizationId: session.orgId, plan },
      },
      allow_promotion_codes: true,
    });

    return ok({ url: checkoutSession.url });
  } catch (err) {
    return handleRouteError(err);
  }
}
