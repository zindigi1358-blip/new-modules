import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(_req: NextRequest) {
  const start = Date.now();

  try {
    // Quick DB connectivity check
    await db.$queryRaw`SELECT 1`;
    const latency = Date.now() - start;

    return NextResponse.json(
      {
        status:    "ok",
        version:   process.env.npm_package_version ?? "1.0.0",
        timestamp: new Date().toISOString(),
        uptime:    process.uptime(),
        db:        { status: "ok", latencyMs: latency },
      },
      { status: 200 }
    );
  } catch (err) {
    return NextResponse.json(
      {
        status:    "degraded",
        timestamp: new Date().toISOString(),
        db:        { status: "error", error: "Database unreachable" },
      },
      { status: 503 }
    );
  }
}
