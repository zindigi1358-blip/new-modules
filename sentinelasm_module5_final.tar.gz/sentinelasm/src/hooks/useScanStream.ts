"use client";

import { useEffect, useRef, useState, useCallback } from "react";

interface ScanProgress {
  id:            string;
  status:        string;
  progress:      number;
  currentModule: string | null;
  totalAssets:   number;
  aliveAssets:   number;
  findingsCount: number;
  errorMessage:  string | null;
  completedAt:   string | null;
}

interface UseScanStreamOptions {
  onComplete?: (status: string) => void;
  onError?:    (err: Event) => void;
}

/**
 * Subscribes to real-time scan progress via SSE.
 * Automatically reconnects on connection drops (up to 5 times).
 * Closes cleanly when scan is complete or component unmounts.
 */
export function useScanStream(
  scanId: string | null,
  options: UseScanStreamOptions = {}
) {
  const [progress,    setProgress]    = useState<ScanProgress | null>(null);
  const [connected,   setConnected]   = useState(false);
  const [error,       setError]       = useState<string | null>(null);
  const esRef         = useRef<EventSource | null>(null);
  const retryCount    = useRef(0);
  const MAX_RETRIES   = 5;

  const connect = useCallback(() => {
    if (!scanId) return;
    if (esRef.current) {
      esRef.current.close();
    }

    const es = new EventSource(`/api/scans/${scanId}/stream`);
    esRef.current = es;

    es.onopen = () => {
      setConnected(true);
      setError(null);
      retryCount.current = 0;
    };

    es.onmessage = (e: MessageEvent) => {
      try {
        const data = JSON.parse(e.data) as ScanProgress;
        setProgress(data);
      } catch { /* ignore malformed messages */ }
    };

    es.addEventListener("complete", (e: MessageEvent) => {
      try {
        const data = JSON.parse(e.data);
        options.onComplete?.(data.status);
      } catch { /* ignore */ }
      es.close();
      setConnected(false);
    });

    es.onerror = (e) => {
      setConnected(false);
      options.onError?.(e);

      if (retryCount.current < MAX_RETRIES) {
        retryCount.current++;
        const delay = Math.min(1000 * 2 ** retryCount.current, 30000);
        setTimeout(connect, delay);
      } else {
        setError("Lost connection to scan stream. Please refresh.");
        es.close();
      }
    };
  }, [scanId, options.onComplete, options.onError]);

  useEffect(() => {
    connect();
    return () => {
      esRef.current?.close();
      esRef.current = null;
    };
  }, [connect]);

  return { progress, connected, error };
}
