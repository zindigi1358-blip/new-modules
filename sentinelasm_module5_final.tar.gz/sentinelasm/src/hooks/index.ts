import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/utils";
import type { DashboardStats, FindingWithAsset, ScanWithStats } from "@/types";

// ─── Dashboard Stats ──────────────────────────────────────────────────────────

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboard", "stats"],
    queryFn:  () => apiRequest<DashboardStats>("/api/dashboard/stats"),
    refetchInterval: 60_000, // auto-refresh every minute
  });
}

// ─── Findings ─────────────────────────────────────────────────────────────────

interface FindingsParams {
  page?:      number;
  pageSize?:  number;
  severity?:  string;
  status?:    string;
  isKev?:     boolean;
  search?:    string;
  sortBy?:    string;
  sortDir?:   "asc" | "desc";
}

export function useFindings(params: FindingsParams = {}) {
  const sp = new URLSearchParams();
  if (params.page)     sp.set("page",     String(params.page));
  if (params.pageSize) sp.set("pageSize", String(params.pageSize));
  if (params.severity) sp.set("severity", params.severity);
  if (params.status)   sp.set("status",   params.status);
  if (params.isKev)    sp.set("isKev",    "true");
  if (params.search)   sp.set("search",   params.search);
  if (params.sortBy)   sp.set("sortBy",   params.sortBy);
  if (params.sortDir)  sp.set("sortDir",  params.sortDir);

  return useQuery({
    queryKey: ["findings", params],
    queryFn:  () => apiRequest<FindingWithAsset[]>(`/api/findings?${sp}`),
  });
}

export function useUpdateFinding() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ...data }: { id: string; status?: string; assignedTo?: string | null }) =>
      apiRequest(`/api/findings/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["findings"] });
      void qc.invalidateQueries({ queryKey: ["dashboard", "stats"] });
    },
  });
}

// ─── Scans ─────────────────────────────────────────────────────────────────────

export function useScans(status?: string) {
  const sp = status ? `?status=${status}` : "";
  return useQuery({
    queryKey:        ["scans", status],
    queryFn:         () => apiRequest<ScanWithStats[]>(`/api/scans${sp}`),
    refetchInterval: status === "RUNNING" ? 5_000 : false, // poll every 5s when running
  });
}

export function useStartScan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { domain: string; scanPorts: boolean; scanCloud: boolean; scanGithub: boolean }) =>
      apiRequest("/api/scans", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["scans"] });
    },
  });
}

export function useCancelScan() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      apiRequest(`/api/scans/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["scans"] });
    },
  });
}

// ─── Assets ──────────────────────────────────────────────────────────────────

interface AssetsParams {
  page?:      number;
  pageSize?:  number;
  search?:    string;
  isAlive?:   boolean;
  assetType?: string;
}

export function useAssets(params: AssetsParams = {}) {
  const sp = new URLSearchParams();
  if (params.page)      sp.set("page",      String(params.page));
  if (params.pageSize)  sp.set("pageSize",  String(params.pageSize));
  if (params.search)    sp.set("search",    params.search);
  if (params.isAlive !== undefined) sp.set("isAlive", String(params.isAlive));
  if (params.assetType) sp.set("assetType", params.assetType);

  return useQuery({
    queryKey: ["assets", params],
    queryFn:  () => apiRequest(`/api/assets?${sp}`),
  });
}

// ─── Notifications ────────────────────────────────────────────────────────────

export function useNotifications() {
  return useQuery({
    queryKey:        ["notifications"],
    queryFn:         () => apiRequest("/api/notifications"),
    refetchInterval: 30_000,
  });
}

export function useMarkAllRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () =>
      apiRequest("/api/notifications", { method: "PATCH", body: JSON.stringify({ markAllRead: true }) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["notifications"] });
    },
  });
}

// ─── Team ────────────────────────────────────────────────────────────────────

export function useTeamMembers() {
  return useQuery({
    queryKey: ["team", "members"],
    queryFn:  () => apiRequest("/api/team/members"),
  });
}

export function useUpdateMemberRole() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { userId: string; role: string }) =>
      apiRequest("/api/team/members", { method: "PATCH", body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["team"] });
    },
  });
}

export function useInviteMember() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { email: string; role: string }) =>
      apiRequest("/api/team/invite", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["team"] });
    },
  });
}

// ─── API Keys ────────────────────────────────────────────────────────────────

export function useApiKeys() {
  return useQuery({
    queryKey: ["api-keys"],
    queryFn:  () => apiRequest("/api/api-keys"),
  });
}

export function useCreateApiKey() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: { name: string; scopes: string[]; expiresAt: string | null }) =>
      apiRequest("/api/api-keys", { method: "POST", body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["api-keys"] });
    },
  });
}

export function useRevokeApiKey() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) =>
      apiRequest(`/api/api-keys/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["api-keys"] });
    },
  });
}
