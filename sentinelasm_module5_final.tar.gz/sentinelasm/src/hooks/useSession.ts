"use client";

import { useEffect, useState } from "react";
import type { SessionPayload } from "@/lib/auth";

interface UseSessionReturn {
  session:  SessionPayload | null;
  loading:  boolean;
}

/**
 * Client-side session hook — reads the current user session from the
 * /api/auth/me endpoint. Only use this in client components that
 * cannot receive session as a prop from their server parent.
 *
 * Prefer passing session as a prop from Server Components when possible.
 */
export function useSession(): UseSessionReturn {
  const [session, setSession] = useState<SessionPayload | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    fetch("/api/auth/me")
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!cancelled) {
          setSession(data?.data ?? null);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancelled) setLoading(false);
      });

    return () => { cancelled = true; };
  }, []);

  return { session, loading };
}
