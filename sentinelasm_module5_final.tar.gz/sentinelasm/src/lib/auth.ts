import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import type { MemberRole } from "@prisma/client";

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "development-secret-change-in-production"
);
const COOKIE_NAME = process.env.NEXT_PUBLIC_COOKIE_NAME ?? "sentinel_session";
const EXPIRY_SECONDS = Number(process.env.JWT_EXPIRY_SECONDS ?? "86400");

export interface SessionPayload {
  userId:         string;
  email:          string;
  name:           string;
  orgId:          string;
  orgSlug:        string;
  orgName:        string;
  role:           MemberRole;
  sessionId:      string;
  iat:            number;
  exp:            number;
}

// ─── Token creation ───────────────────────────────────────────────────────────

export async function createToken(payload: Omit<SessionPayload, "iat" | "exp">): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${EXPIRY_SECONDS}s`)
    .sign(JWT_SECRET);
}

// ─── Token verification ───────────────────────────────────────────────────────

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

// ─── Session from request (Server Components / Route Handlers) ────────────────

export async function getSession(): Promise<SessionPayload | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;
  if (!token) return null;
  return verifyToken(token);
}

// ─── Require authenticated session ────────────────────────────────────────────

export async function requireSession(): Promise<SessionPayload> {
  const session = await getSession();
  if (!session) {
    throw new Error("UNAUTHORIZED");
  }
  return session;
}

// ─── Permission checks ─────────────────────────────────────────────────────────

const ROLE_HIERARCHY: Record<MemberRole, number> = {
  OWNER:   4,
  ADMIN:   3,
  ANALYST: 2,
  VIEWER:  1,
};

export function hasRole(userRole: MemberRole, requiredRole: MemberRole): boolean {
  return ROLE_HIERARCHY[userRole] >= ROLE_HIERARCHY[requiredRole];
}

export function requireRole(userRole: MemberRole, requiredRole: MemberRole): void {
  if (!hasRole(userRole, requiredRole)) {
    throw new Error("FORBIDDEN");
  }
}

// ─── Set / clear session cookie ───────────────────────────────────────────────

export async function setSessionCookie(token: string): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly:  true,
    secure:    process.env.NODE_ENV === "production",
    sameSite:  "lax",
    maxAge:    EXPIRY_SECONDS,
    path:      "/",
  });
}

export async function clearSessionCookie(): Promise<void> {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAME);
}

// ─── Validate API key from request headers ────────────────────────────────────

import bcrypt from "bcryptjs";

export async function validateApiKey(rawKey: string): Promise<{
  organizationId: string;
  scopes: string[];
  keyId: string;
} | null> {
  if (!rawKey.startsWith("sk_live_") && !rawKey.startsWith("sk_test_")) {
    return null;
  }

  // Look up by prefix (first 16 chars after "sk_live_")
  const prefix = rawKey.slice(0, 24);
  const apiKey = await db.apiKey.findFirst({
    where: { keyPrefix: prefix, isActive: true },
  });

  if (!apiKey) return null;
  if (apiKey.expiresAt && apiKey.expiresAt < new Date()) return null;

  const valid = await bcrypt.compare(rawKey, apiKey.keyHash);
  if (!valid) return null;

  // Update last used (non-blocking)
  void db.apiKey.update({
    where: { id: apiKey.id },
    data:  { lastUsedAt: new Date() },
  }).catch(() => {});

  return {
    organizationId: apiKey.organizationId,
    scopes:         apiKey.scopes,
    keyId:          apiKey.id,
  };
}
