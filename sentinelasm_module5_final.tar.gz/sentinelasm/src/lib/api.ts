import { NextResponse } from "next/server";
import { ZodError } from "zod";

// ─── Standard API response envelope ──────────────────────────────────────────

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?:   T;
  error?:  string;
  errors?: Record<string, string[]>;
  meta?:   {
    page?:       number;
    pageSize?:   number;
    total?:      number;
    totalPages?: number;
  };
}

export function ok<T>(data: T, meta?: ApiResponse<T>["meta"], status = 200): NextResponse {
  return NextResponse.json<ApiResponse<T>>({ success: true, data, meta }, { status });
}

export function created<T>(data: T): NextResponse {
  return ok(data, undefined, 201);
}

export function noContent(): NextResponse {
  return new NextResponse(null, { status: 204 });
}

export function badRequest(message: string, errors?: Record<string, string[]>): NextResponse {
  return NextResponse.json<ApiResponse>(
    { success: false, error: message, errors },
    { status: 400 }
  );
}

export function unauthorized(message = "Unauthorized"): NextResponse {
  return NextResponse.json<ApiResponse>({ success: false, error: message }, { status: 401 });
}

export function forbidden(message = "Forbidden"): NextResponse {
  return NextResponse.json<ApiResponse>({ success: false, error: message }, { status: 403 });
}

export function notFound(resource = "Resource"): NextResponse {
  return NextResponse.json<ApiResponse>(
    { success: false, error: `${resource} not found` },
    { status: 404 }
  );
}

export function conflict(message: string): NextResponse {
  return NextResponse.json<ApiResponse>({ success: false, error: message }, { status: 409 });
}

export function tooManyRequests(retryAfter = 60): NextResponse {
  return NextResponse.json<ApiResponse>(
    { success: false, error: "Too many requests. Please try again later." },
    {
      status:  429,
      headers: { "Retry-After": String(retryAfter) },
    }
  );
}

export function internalError(message = "An unexpected error occurred"): NextResponse {
  return NextResponse.json<ApiResponse>({ success: false, error: message }, { status: 500 });
}

// ─── Error handler for route handlers ────────────────────────────────────────

export function handleRouteError(error: unknown): NextResponse {
  if (error instanceof ZodError) {
    const errors: Record<string, string[]> = {};
    for (const issue of error.issues) {
      const key = issue.path.join(".");
      if (!errors[key]) errors[key] = [];
      errors[key]!.push(issue.message);
    }
    return badRequest("Validation failed", errors);
  }

  if (error instanceof Error) {
    if (error.message === "UNAUTHORIZED") return unauthorized();
    if (error.message === "FORBIDDEN")    return forbidden();
    if (error.message === "NOT_FOUND")    return notFound();
  }

  console.error("[API Error]", error);
  return internalError();
}

// ─── In-memory rate limiter (for production: use Redis) ─────────────────────

interface RateLimitEntry {
  count:     number;
  resetTime: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();

export function checkRateLimit(
  key:        string,
  limit:      number,
  windowSecs: number
): { allowed: boolean; remaining: number; resetTime: number } {
  const now       = Date.now();
  const resetTime = now + windowSecs * 1000;
  const entry     = rateLimitStore.get(key);

  if (!entry || entry.resetTime < now) {
    rateLimitStore.set(key, { count: 1, resetTime });
    return { allowed: true, remaining: limit - 1, resetTime };
  }

  if (entry.count >= limit) {
    return { allowed: false, remaining: 0, resetTime: entry.resetTime };
  }

  entry.count++;
  return { allowed: true, remaining: limit - entry.count, resetTime: entry.resetTime };
}

// ─── Pagination helper ────────────────────────────────────────────────────────

export interface PaginationParams {
  page:     number;
  pageSize: number;
}

export function parsePagination(searchParams: URLSearchParams): PaginationParams {
  const page     = Math.max(1, Number(searchParams.get("page")     ?? "1"));
  const pageSize = Math.min(100, Math.max(1, Number(searchParams.get("pageSize") ?? "25")));
  return { page, pageSize };
}

export function paginationMeta(total: number, page: number, pageSize: number) {
  return {
    page,
    pageSize,
    total,
    totalPages: Math.ceil(total / pageSize),
  };
}
