import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  console.log("🌱 Seeding SentinelASM database…\n");

  // ── Clean slate ──────────────────────────────────────────────────────────
  await db.auditLog.deleteMany();
  await db.notification.deleteMany();
  await db.alertConfig.deleteMany();
  await db.finding.deleteMany();
  await db.asset.deleteMany();
  await db.scan.deleteMany();
  await db.apiKey.deleteMany();
  await db.invitation.deleteMany();
  await db.report.deleteMany();
  await db.monitoredDomain.deleteMany();
  await db.organizationMember.deleteMany();
  await db.organization.deleteMany();
  await db.session.deleteMany();
  await db.user.deleteMany();

  // ── Organization ──────────────────────────────────────────────────────────
  const org = await db.organization.create({
    data: {
      name:          "Acme Corp",
      slug:          "acme-corp",
      plan:          "PROFESSIONAL",
      maxAssets:     5000,
      maxScansMonth: 500,
      maxMembers:    25,
    },
  });
  console.log(`✓ Organization: ${org.name} (${org.plan})`);

  // ── Users ─────────────────────────────────────────────────────────────────
  const pw = await bcrypt.hash("password123", 12);

  const sara = await db.user.create({
    data: { name: "Sara Khan",    email: "sara@acmecorp.com",   passwordHash: pw },
  });
  const ali = await db.user.create({
    data: { name: "Ali Raza",     email: "ali@acmecorp.com",    passwordHash: pw },
  });
  const ahmed = await db.user.create({
    data: { name: "Ahmed Hassan", email: "ahmed@acmecorp.com",  passwordHash: pw },
  });

  console.log("✓ Users: sara@acmecorp.com / ali@acmecorp.com / ahmed@acmecorp.com (password: password123)");

  // ── Memberships ──────────────────────────────────────────────────────────
  await db.organizationMember.createMany({
    data: [
      { organizationId: org.id, userId: sara.id,  role: "OWNER"   },
      { organizationId: org.id, userId: ali.id,   role: "ANALYST" },
      { organizationId: org.id, userId: ahmed.id, role: "ADMIN"   },
    ],
  });
  console.log("✓ Memberships created");

  // ── Monitored Domain ──────────────────────────────────────────────────────
  const domain = await db.monitoredDomain.create({
    data: { organizationId: org.id, domain: "acmecorp.com" },
  });

  // ── Completed Scan ────────────────────────────────────────────────────────
  const scan = await db.scan.create({
    data: {
      organizationId: org.id,
      domainId:       domain.id,
      domain:         "acmecorp.com",
      status:         "COMPLETED",
      triggeredBy:    "scheduled",
      startedAt:      new Date(Date.now() - 30 * 60 * 1000),
      completedAt:    new Date(Date.now() - 25 * 60 * 1000),
      durationSecs:   287,
      progress:       100,
      totalAssets:    291,
      aliveAssets:    243,
      findingsCount:  23,
    },
  });
  console.log("✓ Scan created");

  // ── Assets ────────────────────────────────────────────────────────────────
  const assetData = [
    { subdomain: "admin.acmecorp.com",   ipAddress: "104.21.44.12", isAlive: true, httpsStatus: 200, openPorts: [80,443,3306], technologies: ["WordPress 5.8","PHP 7.4.3","jQuery 3.5.1","Missing HSTS"] },
    { subdomain: "api.acmecorp.com",     ipAddress: "104.21.44.18", isAlive: true, httpsStatus: 200, openPorts: [443,6379,27017], technologies: ["Express.js 4.17.1","Nginx 1.18.0","Node.js 14.17"] },
    { subdomain: "staging.acmecorp.com", ipAddress: "104.21.44.23", isAlive: true, httpsStatus: 200, openPorts: [443,9200], technologies: ["Django 3.1.4","Python 3.8","Nginx 1.14.0"] },
    { subdomain: "dev.acmecorp.com",     ipAddress: "104.21.44.31", isAlive: true, httpStatus:  200, openPorts: [22,80,27017], technologies: ["Apache 2.4.29","MongoDB"] },
    { subdomain: "old.acmecorp.com",     ipAddress: "104.21.44.44", isAlive: true, httpsStatus: 200, openPorts: [80,443,21], technologies: ["PHP 5.6.40","Apache 2.2.34","Missing HSTS"] },
    { subdomain: "www.acmecorp.com",     ipAddress: "104.21.44.8",  isAlive: true, httpsStatus: 200, openPorts: [80,443], technologies: ["React 17.0.2","Next.js 11.0.1","Nginx 1.20.1"] },
    { subdomain: "mail.acmecorp.com",    ipAddress: "104.21.44.52", isAlive: true, httpsStatus: 200, openPorts: [25,443,587,993], technologies: ["Roundcube 1.4.11"] },
    { subdomain: "monitor.acmecorp.com", ipAddress: "104.21.44.71", isAlive: true, httpsStatus: 200, openPorts: [443,3000], technologies: ["Grafana 7.3.1"] },
    { subdomain: "backup.acmecorp.com",  ipAddress: "104.21.44.82", isAlive: true, httpsStatus: 200, openPorts: [21,22,80,5900], technologies: ["Apache 2.4.18"] },
    { subdomain: "payment.acmecorp.com", ipAddress: "104.21.44.91", isAlive: true, httpsStatus: 200, openPorts: [443], technologies: ["Nginx 1.20.1","Vue.js 2.6.14"] },
  ];

  const assets = await Promise.all(
    assetData.map(a => db.asset.create({
      data: { organizationId: org.id, assetType: "SUBDOMAIN", ...a, lastSeenAt: new Date() },
    }))
  );

  // Cloud asset
  await db.asset.create({
    data: {
      organizationId: org.id,
      assetType:      "CLOUD_ASSET",
      url:            "https://acmecorp-backups.s3.amazonaws.com",
      cloudProvider:  "AWS",
      cloudAssetType: "S3 Bucket",
      isPublic:       true,
      isAlive:        true,
    },
  });
  console.log(`✓ ${assets.length + 1} assets created`);

  // ── Findings ──────────────────────────────────────────────────────────────
  const findingData = [
    { title: "AWS Access Key Leaked in GitHub",         severity: "CRITICAL", riskScore: 96, cvssScore: 9.9, isKev: false, category: "Credentials", affectedAsset: "github.com/acmecorp/infra", evidence: "AWS_ACCESS_KEY_ID found in terraform/backend.tf",                    remediation: "Rotate all AWS credentials immediately. Add .env to .gitignore. Use AWS Secrets Manager." },
    { title: "Exposed .git Directory",                  severity: "CRITICAL", riskScore: 91, cvssScore: 9.8, isKev: false, category: "Exposure",     affectedAsset: "dev.acmecorp.com",          evidence: "HTTP 200 on /.git/config — content contains [core] repositoryformatversion",             remediation: "Block web access to .git via nginx: location ~ /\\.git { deny all; return 404; }" },
    { title: "PHP 5.6.40 — Remote Code Execution",     severity: "CRITICAL", riskScore: 88, cvssScore: 9.8, isKev: true,  category: "CVE",          affectedAsset: "old.acmecorp.com",          evidence: "CVE-2019-11043 — PHP-FPM RCE via nginx fastcgi_split_path_info. CISA KEV confirmed.",   remediation: "Upgrade PHP to 8.1+ immediately. This is actively exploited in the wild." },
    { title: "MongoDB Port 27017 Exposed",              severity: "CRITICAL", riskScore: 88, cvssScore: 9.1, isKev: false, category: "Exposure",     affectedAsset: "api.acmecorp.com:27017",    evidence: "TCP connect to port 27017 succeeded. No authentication required.",                      remediation: "Restrict MongoDB to application server IPs via iptables. Enable auth." },
    { title: "S3 Bucket Publicly Readable",             severity: "CRITICAL", riskScore: 85, cvssScore: 8.6, isKev: false, category: "Cloud",        affectedAsset: "acmecorp-backups.s3.amazonaws.com", evidence: "ListBucket returns HTTP 200 — contains database dumps and backups",           remediation: "Set bucket ACL to private. Enable S3 Block Public Access. Rotate any exposed data." },
    { title: "WordPress 5.8 SQL Injection",             severity: "CRITICAL", riskScore: 91, cvssScore: 9.8, isKev: false, category: "CVE",          affectedAsset: "admin.acmecorp.com",        evidence: "CVE-2022-21661 — WP_Query SQL injection via crafted POST requests",                    remediation: "Update WordPress to 5.8.3+ or latest version immediately." },
    { title: "Express.js Open Redirect",                severity: "HIGH",     riskScore: 73, cvssScore: 7.5, isKev: false, category: "CVE",          affectedAsset: "api.acmecorp.com",          evidence: "CVE-2022-24999 — Host header manipulation allows redirect to attacker-controlled URLs",  remediation: "Update express to 4.18.2+" },
    { title: "Admin Panel Exposed to Public Internet",  severity: "HIGH",     riskScore: 68, cvssScore: 7.2, isKev: false, category: "Config",       affectedAsset: "admin.acmecorp.com",        evidence: "WordPress admin (/wp-admin) accessible from any IP without restriction",                  remediation: "Restrict /wp-admin to office IP via nginx allow/deny. Enable 2FA." },
    { title: "Grafana 7.3.1 Unauthenticated API",      severity: "HIGH",     riskScore: 67, cvssScore: 8.8, isKev: false, category: "CVE",          affectedAsset: "monitor.acmecorp.com",      evidence: "CVE-2021-27358 — snapshot API accessible without authentication",                       remediation: "Update Grafana to 7.5.15+ or 8.5.5+" },
    { title: "Missing HSTS Header",                     severity: "MEDIUM",   riskScore: 32, cvssScore: 5.4, isKev: false, category: "Config",       affectedAsset: "admin.acmecorp.com",        evidence: "Strict-Transport-Security header absent — allows TLS downgrade attacks",                  remediation: "Add: Strict-Transport-Security: max-age=31536000; includeSubDomains" },
    { title: "TLS Certificate Expiring Soon",           severity: "MEDIUM",   riskScore: 28, cvssScore: 0,   isKev: false, category: "Config",       affectedAsset: "mail.acmecorp.com",         evidence: "TLS certificate expires in 12 days",                                                    remediation: "Renew TLS certificate immediately. Configure auto-renewal via certbot." },
    { title: "Roundcube XSS (CVE-2021-44025)",         severity: "LOW",      riskScore: 22, cvssScore: 4.3, isKev: false, category: "CVE",          affectedAsset: "mail.acmecorp.com",         evidence: "CVE-2021-44025 — stored XSS via crafted HTML email",                                    remediation: "Update Roundcube to 1.4.13+ or 1.5.2+" },
  ];

  for (const f of findingData) {
    await db.finding.create({
      data: {
        organizationId: org.id,
        scanId:         scan.id,
        ...f,
        severity:       f.severity as any,
        status:         "OPEN",
        cveIds:         f.category === "CVE" ? [`CVE-2022-${Math.floor(Math.random()*99999)}`] : [],
        firstSeenAt:    new Date(Date.now() - Math.random() * 7 * 86400 * 1000),
      },
    });
  }
  console.log(`✓ ${findingData.length} findings created`);

  // ── Alert Config ──────────────────────────────────────────────────────────
  await db.alertConfig.createMany({
    data: [
      { organizationId: org.id, channel: "DISCORD", isEnabled: true,  minSeverity: "HIGH",   sendOnFindings: true, sendDailyDigest: true, sendWeeklyReport: true, sendOnScanDone: true, sendOnNewAsset: true },
      { organizationId: org.id, channel: "EMAIL",   isEnabled: true,  minSeverity: "MEDIUM", emailRecipients: ["ali@acmecorp.com"], sendOnFindings: true, sendDailyDigest: true, sendWeeklyReport: true, sendOnScanDone: true, sendOnNewAsset: false },
    ],
  });

  // ── Notifications ─────────────────────────────────────────────────────────
  await db.notification.createMany({
    data: [
      { organizationId: org.id, title: "AWS key leaked — GitHub",              body: "AWS_ACCESS_KEY found in terraform/backend.tf. Rotate immediately.", severity: "CRITICAL", isRead: false, linkTo: "/dashboard/findings" },
      { organizationId: org.id, title: "Scan completed — api.acmecorp.com",   body: "Scan finished in 4m 47s — 3 new findings, 1 critical.",             severity: "INFO",     isRead: false, linkTo: "/dashboard/scans" },
      { organizationId: org.id, title: "New subdomain discovered",             body: "staging-v2.acmecorp.com found via certificate transparency.",        severity: "INFO",     isRead: false, linkTo: "/dashboard/assets" },
      { organizationId: org.id, title: "TLS certificate expiring in 12 days", body: "mail.acmecorp.com certificate expires soon. Renew ASAP.",            severity: "HIGH",     isRead: false, linkTo: "/dashboard/assets" },
    ],
  });

  // ── Audit Logs ────────────────────────────────────────────────────────────
  await db.auditLog.createMany({
    data: [
      { organizationId: org.id, userId: ali.id,   action: "SCAN_STARTED",     target: `scan:${scan.id}`, ipAddress: "104.21.44.1",  createdAt: new Date(Date.now()-14*60*1000) },
      { organizationId: org.id, userId: sara.id,  action: "LOGIN",            target: null,              ipAddress: "203.0.113.5",  createdAt: new Date(Date.now()-2*3600*1000) },
      { organizationId: org.id, userId: ahmed.id, action: "API_KEY_CREATED",  target: "CI/CD Pipeline",  ipAddress: "198.51.100.3", createdAt: new Date(Date.now()-4*3600*1000) },
      { organizationId: org.id, userId: sara.id,  action: "BILLING_UPDATED",  target: "STARTER→PROFESSIONAL", ipAddress: "203.0.113.5", createdAt: new Date(Date.now()-30*86400*1000) },
    ],
  });

  console.log("\n✅ Seed complete!\n");
  console.log("─".repeat(50));
  console.log("Login credentials:");
  console.log("  Email:    ali@acmecorp.com");
  console.log("  Password: password123");
  console.log("  Role:     Analyst");
  console.log("");
  console.log("  Email:    sara@acmecorp.com");
  console.log("  Password: password123");
  console.log("  Role:     Owner");
  console.log("─".repeat(50));
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect());
