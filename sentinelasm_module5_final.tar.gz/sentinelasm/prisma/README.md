-- Migration: add password_reset_tokens table
-- Run: npx prisma migrate dev --name add_password_reset

-- This is handled by the existing sessions table using
-- the token prefix "reset_" pattern in the application code.
-- No additional migration needed.

-- To run all migrations in production:
-- npx prisma migrate deploy

-- To reset and re-seed development database:
-- npx prisma migrate reset
-- npx prisma db seed
